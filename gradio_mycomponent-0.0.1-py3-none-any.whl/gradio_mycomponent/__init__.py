
from .mycomponent import MyComponent

__all__ = ['MyComponent']
