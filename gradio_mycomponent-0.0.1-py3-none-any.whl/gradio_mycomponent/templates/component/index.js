var fc = Object.defineProperty;
var dc = (t, e, n) => e in t ? fc(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var Pe = (t, e, n) => (dc(t, typeof e != "symbol" ? e + "" : e, n), n), Sr = (t, e, n) => {
  if (!e.has(t))
    throw TypeError("Cannot " + n);
};
var M = (t, e, n) => (Sr(t, e, "read from private field"), n ? n.call(t) : e.get(t)), Lt = (t, e, n) => {
  if (e.has(t))
    throw TypeError("Cannot add the same private member more than once");
  e instanceof WeakSet ? e.add(t) : e.set(t, n);
}, Jn = (t, e, n, i) => (Sr(t, e, "write to private field"), i ? i.call(t, n) : e.set(t, n), n);
var Il = new Intl.Collator(0, { numeric: 1 }).compare;
function Tr(t, e, n) {
  return t = t.split("."), e = e.split("."), Il(t[0], e[0]) || Il(t[1], e[1]) || (e[2] = e.slice(2).join("."), n = /[.-]/.test(t[2] = t.slice(2).join(".")), n == /[.-]/.test(e[2]) ? Il(t[2], e[2]) : n ? -1 : 1);
}
function Hs(t, e, n) {
  return e.startsWith("http://") || e.startsWith("https://") ? n ? t : e : t + e;
}
function Hl(t) {
  if (t.startsWith("http")) {
    const { protocol: e, host: n } = new URL(t);
    return n.endsWith("hf.space") ? {
      ws_protocol: "wss",
      host: n,
      http_protocol: e
    } : {
      ws_protocol: e === "https:" ? "wss" : "ws",
      http_protocol: e,
      host: n
    };
  } else if (t.startsWith("file:"))
    return {
      ws_protocol: "ws",
      http_protocol: "http:",
      host: "lite.local"
      // Special fake hostname only used for this case. This matches the hostname allowed in `is_self_host()` in `js/wasm/network/host.ts`.
    };
  return {
    ws_protocol: "wss",
    http_protocol: "https:",
    host: t
  };
}
const Ps = /^[^\/]*\/[^\/]*$/, _c = /.*hf\.space\/{0,1}$/;
async function mc(t, e) {
  const n = {};
  e && (n.Authorization = `Bearer ${e}`);
  const i = t.trim();
  if (Ps.test(i))
    try {
      const l = await fetch(
        `https://huggingface.co/api/spaces/${i}/host`,
        { headers: n }
      );
      if (l.status !== 200)
        throw new Error("Space metadata could not be loaded.");
      const o = (await l.json()).host;
      return {
        space_id: t,
        ...Hl(o)
      };
    } catch (l) {
      throw new Error("Space metadata could not be loaded." + l.message);
    }
  if (_c.test(i)) {
    const { ws_protocol: l, http_protocol: o, host: r } = Hl(i);
    return {
      space_id: r.replace(".hf.space", ""),
      ws_protocol: l,
      http_protocol: o,
      host: r
    };
  }
  return {
    space_id: !1,
    ...Hl(i)
  };
}
function hc(t) {
  let e = {};
  return t.forEach(({ api_name: n }, i) => {
    n && (e[n] = i);
  }), e;
}
const pc = /^(?=[^]*\b[dD]iscussions{0,1}\b)(?=[^]*\b[dD]isabled\b)[^]*$/;
async function Cr(t) {
  try {
    const n = (await fetch(
      `https://huggingface.co/api/spaces/${t}/discussions`,
      {
        method: "HEAD"
      }
    )).headers.get("x-error-message");
    return !(n && pc.test(n));
  } catch {
    return !1;
  }
}
function gc(t, e, n, i) {
  if (e.length === 0) {
    if (n === "replace")
      return i;
    if (n === "append")
      return t + i;
    throw new Error(`Unsupported action: ${n}`);
  }
  let l = t;
  for (let r = 0; r < e.length - 1; r++)
    l = l[e[r]];
  const o = e[e.length - 1];
  switch (n) {
    case "replace":
      l[o] = i;
      break;
    case "append":
      l[o] += i;
      break;
    case "add":
      Array.isArray(l) ? l.splice(Number(o), 0, i) : l[o] = i;
      break;
    case "delete":
      Array.isArray(l) ? l.splice(Number(o), 1) : delete l[o];
      break;
    default:
      throw new Error(`Unknown action: ${n}`);
  }
  return t;
}
function bc(t, e) {
  return e.forEach(([n, i, l]) => {
    t = gc(t, i, n, l);
  }), t;
}
async function ir(t, e, n, i = wc) {
  let l = (Array.isArray(t) ? t : [t]).map(
    (o) => o.blob
  );
  return await Promise.all(
    await i(e, l, void 0, n).then(
      async (o) => {
        if (o.error)
          throw new Error(o.error);
        return o.files ? o.files.map((r, s) => new or({
          ...t[s],
          path: r,
          url: e + "/file=" + r
        })) : [];
      }
    )
  );
}
async function lr(t, e) {
  return t.map(
    (n, i) => new or({
      path: n.name,
      orig_name: n.name,
      blob: n,
      size: n.size,
      mime_type: n.type,
      is_stream: e
    })
  );
}
class or {
  constructor({
    path: e,
    url: n,
    orig_name: i,
    size: l,
    blob: o,
    is_stream: r,
    mime_type: s,
    alt_text: a
  }) {
    this.meta = { _type: "gradio.FileData" }, this.path = e, this.url = n, this.orig_name = i, this.size = l, this.blob = n ? void 0 : o, this.is_stream = r, this.mime_type = s, this.alt_text = a;
  }
}
const Rs = "This application is too busy. Keep trying!", Ft = "Connection errored out.";
let Os;
function vc(t, e) {
  return { post_data: n, upload_files: i, client: l, handle_blob: o };
  async function n(r, s, a) {
    const u = { "Content-Type": "application/json" };
    a && (u.Authorization = `Bearer ${a}`);
    try {
      var c = await t(r, {
        method: "POST",
        body: JSON.stringify(s),
        headers: u
      });
    } catch {
      return [{ error: Ft }, 500];
    }
    let f, d;
    try {
      f = await c.json(), d = c.status;
    } catch (_) {
      f = { error: `Could not parse server response: ${_}` }, d = 500;
    }
    return [f, d];
  }
  async function i(r, s, a, u) {
    const c = {};
    a && (c.Authorization = `Bearer ${a}`);
    const f = 1e3, d = [];
    for (let m = 0; m < s.length; m += f) {
      const h = s.slice(m, m + f), p = new FormData();
      h.forEach((y) => {
        p.append("files", y);
      });
      try {
        const y = u ? `${r}/upload?upload_id=${u}` : `${r}/upload`;
        var _ = await t(y, {
          method: "POST",
          body: p,
          headers: c
        });
      } catch {
        return { error: Ft };
      }
      const v = await _.json();
      d.push(...v);
    }
    return { files: d };
  }
  async function l(r, s = {}) {
    return new Promise(async (a) => {
      const { status_callback: u, hf_token: c } = s, f = {
        predict: re,
        submit: A,
        view_api: pe,
        component_server: S
      };
      if ((typeof window > "u" || !("WebSocket" in window)) && !global.Websocket) {
        const P = await import("./wrapper-6f348d45-19fa94bf.js");
        Os = (await import("./__vite-browser-external-2447137e.js")).Blob, global.WebSocket = P.WebSocket;
      }
      const { ws_protocol: d, http_protocol: _, host: m, space_id: h } = await mc(r, c), p = Math.random().toString(36).substring(2), v = {};
      let y = !1, w = {}, B = {}, k = null;
      const b = {}, C = /* @__PURE__ */ new Set();
      let H, R = {}, x = !1;
      c && h && (x = await kc(h, c));
      async function z(P) {
        if (H = P, window.location.protocol === "https:" && (H.root = H.root.replace("http://", "https://")), R = hc((P == null ? void 0 : P.dependencies) || []), H.auth_required)
          return {
            config: H,
            ...f
          };
        try {
          q = await pe(H);
        } catch (J) {
          console.error(`Could not get api details: ${J.message}`);
        }
        return {
          config: H,
          ...f
        };
      }
      let q;
      async function F(P) {
        if (u && u(P), P.status === "running")
          try {
            H = await Nr(
              t,
              `${_}//${m}`,
              c
            );
            const J = await z(H);
            a(J);
          } catch (J) {
            console.error(J), u && u({
              status: "error",
              message: "Could not load this space.",
              load_status: "error",
              detail: "NOT_FOUND"
            });
          }
      }
      try {
        H = await Nr(
          t,
          `${_}//${m}`,
          c
        );
        const P = await z(H);
        a(P);
      } catch (P) {
        console.error(P), h ? No(
          h,
          Ps.test(h) ? "space_name" : "subdomain",
          F
        ) : u && u({
          status: "error",
          message: "Could not load this space.",
          load_status: "error",
          detail: "NOT_FOUND"
        });
      }
      function re(P, J, Z) {
        let g = !1, E = !1, T;
        if (typeof P == "number")
          T = H.dependencies[P];
        else {
          const I = P.replace(/^\//, "");
          T = H.dependencies[R[I]];
        }
        if (T.types.continuous)
          throw new Error(
            "Cannot call predict on this function as it may run forever. Use submit instead"
          );
        return new Promise((I, K) => {
          const ue = A(P, J, Z);
          let j;
          ue.on("data", (He) => {
            E && (ue.destroy(), I(He)), g = !0, j = He;
          }).on("status", (He) => {
            He.stage === "error" && K(He), He.stage === "complete" && (E = !0, g && (ue.destroy(), I(j)));
          });
        });
      }
      function A(P, J, Z, g = null) {
        let E, T;
        if (typeof P == "number")
          E = P, T = q.unnamed_endpoints[E];
        else {
          const ne = P.replace(/^\//, "");
          E = R[ne], T = q.named_endpoints[P.trim()];
        }
        if (typeof E != "number")
          throw new Error(
            "There is no endpoint matching that name of fn_index matching that number."
          );
        let I, K, ue = H.protocol ?? "ws";
        const j = typeof P == "number" ? "/predict" : P;
        let He, ke = null, L = !1;
        const Ut = {};
        let st = "";
        typeof window < "u" && (st = new URLSearchParams(window.location.search).toString()), o(`${H.root}`, J, T, c).then(
          (ne) => {
            if (He = {
              data: ne || [],
              event_data: Z,
              fn_index: E,
              trigger_id: g
            }, Ec(E, H))
              X({
                type: "status",
                endpoint: j,
                stage: "pending",
                queue: !1,
                fn_index: E,
                time: /* @__PURE__ */ new Date()
              }), n(
                `${H.root}/run${j.startsWith("/") ? j : `/${j}`}${st ? "?" + st : ""}`,
                {
                  ...He,
                  session_hash: p
                },
                c
              ).then(([le, te]) => {
                const ge = le.data;
                te == 200 ? (X({
                  type: "data",
                  endpoint: j,
                  fn_index: E,
                  data: ge,
                  time: /* @__PURE__ */ new Date()
                }), X({
                  type: "status",
                  endpoint: j,
                  fn_index: E,
                  stage: "complete",
                  eta: le.average_duration,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                })) : X({
                  type: "status",
                  stage: "error",
                  endpoint: j,
                  fn_index: E,
                  message: le.error,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                });
              }).catch((le) => {
                X({
                  type: "status",
                  stage: "error",
                  message: le.message,
                  endpoint: j,
                  fn_index: E,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                });
              });
            else if (ue == "ws") {
              X({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: j,
                fn_index: E,
                time: /* @__PURE__ */ new Date()
              });
              let le = new URL(`${d}://${Hs(
                m,
                H.path,
                !0
              )}
							/queue/join${st ? "?" + st : ""}`);
              x && le.searchParams.set("__sign", x), I = new WebSocket(le), I.onclose = (te) => {
                te.wasClean || X({
                  type: "status",
                  stage: "error",
                  broken: !0,
                  message: Ft,
                  queue: !0,
                  endpoint: j,
                  fn_index: E,
                  time: /* @__PURE__ */ new Date()
                });
              }, I.onmessage = function(te) {
                const ge = JSON.parse(te.data), { type: de, status: Q, data: ee } = Pl(
                  ge,
                  v[E]
                );
                if (de === "update" && Q && !L)
                  X({
                    type: "status",
                    endpoint: j,
                    fn_index: E,
                    time: /* @__PURE__ */ new Date(),
                    ...Q
                  }), Q.stage === "error" && I.close();
                else if (de === "hash") {
                  I.send(JSON.stringify({ fn_index: E, session_hash: p }));
                  return;
                } else
                  de === "data" ? I.send(JSON.stringify({ ...He, session_hash: p })) : de === "complete" ? L = Q : de === "log" ? X({
                    type: "log",
                    log: ee.log,
                    level: ee.level,
                    endpoint: j,
                    fn_index: E
                  }) : de === "generating" && X({
                    type: "status",
                    time: /* @__PURE__ */ new Date(),
                    ...Q,
                    stage: Q == null ? void 0 : Q.stage,
                    queue: !0,
                    endpoint: j,
                    fn_index: E
                  });
                ee && (X({
                  type: "data",
                  time: /* @__PURE__ */ new Date(),
                  data: ee.data,
                  endpoint: j,
                  fn_index: E
                }), L && (X({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...L,
                  stage: Q == null ? void 0 : Q.stage,
                  queue: !0,
                  endpoint: j,
                  fn_index: E
                }), I.close()));
              }, Tr(H.version || "2.0.0", "3.6") < 0 && addEventListener(
                "open",
                () => I.send(JSON.stringify({ hash: p }))
              );
            } else if (ue == "sse") {
              X({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: j,
                fn_index: E,
                time: /* @__PURE__ */ new Date()
              });
              var Ee = new URLSearchParams({
                fn_index: E.toString(),
                session_hash: p
              }).toString();
              let le = new URL(
                `${H.root}/queue/join?${st ? st + "&" : ""}${Ee}`
              );
              K = e(le), K.onmessage = async function(te) {
                const ge = JSON.parse(te.data), { type: de, status: Q, data: ee } = Pl(
                  ge,
                  v[E]
                );
                if (de === "update" && Q && !L)
                  X({
                    type: "status",
                    endpoint: j,
                    fn_index: E,
                    time: /* @__PURE__ */ new Date(),
                    ...Q
                  }), Q.stage === "error" && K.close();
                else if (de === "data") {
                  ke = ge.event_id;
                  let [qt, cc] = await n(
                    `${H.root}/queue/data`,
                    {
                      ...He,
                      session_hash: p,
                      event_id: ke
                    },
                    c
                  );
                  cc !== 200 && (X({
                    type: "status",
                    stage: "error",
                    message: Ft,
                    queue: !0,
                    endpoint: j,
                    fn_index: E,
                    time: /* @__PURE__ */ new Date()
                  }), K.close());
                } else
                  de === "complete" ? L = Q : de === "log" ? X({
                    type: "log",
                    log: ee.log,
                    level: ee.level,
                    endpoint: j,
                    fn_index: E
                  }) : de === "generating" && X({
                    type: "status",
                    time: /* @__PURE__ */ new Date(),
                    ...Q,
                    stage: Q == null ? void 0 : Q.stage,
                    queue: !0,
                    endpoint: j,
                    fn_index: E
                  });
                ee && (X({
                  type: "data",
                  time: /* @__PURE__ */ new Date(),
                  data: ee.data,
                  endpoint: j,
                  fn_index: E
                }), L && (X({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...L,
                  stage: Q == null ? void 0 : Q.stage,
                  queue: !0,
                  endpoint: j,
                  fn_index: E
                }), K.close()));
              };
            } else
              (ue == "sse_v1" || ue == "sse_v2" || ue == "sse_v2.1" || ue == "sse_v3") && (X({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: j,
                fn_index: E,
                time: /* @__PURE__ */ new Date()
              }), n(
                `${H.root}/queue/join?${st}`,
                {
                  ...He,
                  session_hash: p
                },
                c
              ).then(([le, te]) => {
                if (te === 503)
                  X({
                    type: "status",
                    stage: "error",
                    message: Rs,
                    queue: !0,
                    endpoint: j,
                    fn_index: E,
                    time: /* @__PURE__ */ new Date()
                  });
                else if (te !== 200)
                  X({
                    type: "status",
                    stage: "error",
                    message: Ft,
                    queue: !0,
                    endpoint: j,
                    fn_index: E,
                    time: /* @__PURE__ */ new Date()
                  });
                else {
                  ke = le.event_id;
                  let ge = async function(de) {
                    try {
                      const { type: Q, status: ee, data: qt } = Pl(
                        de,
                        v[E]
                      );
                      if (Q == "heartbeat")
                        return;
                      if (Q === "update" && ee && !L)
                        X({
                          type: "status",
                          endpoint: j,
                          fn_index: E,
                          time: /* @__PURE__ */ new Date(),
                          ...ee
                        });
                      else if (Q === "complete")
                        L = ee;
                      else if (Q == "unexpected_error")
                        console.error("Unexpected error", ee == null ? void 0 : ee.message), X({
                          type: "status",
                          stage: "error",
                          message: (ee == null ? void 0 : ee.message) || "An Unexpected Error Occurred!",
                          queue: !0,
                          endpoint: j,
                          fn_index: E,
                          time: /* @__PURE__ */ new Date()
                        });
                      else if (Q === "log") {
                        X({
                          type: "log",
                          log: qt.log,
                          level: qt.level,
                          endpoint: j,
                          fn_index: E
                        });
                        return;
                      } else
                        Q === "generating" && (X({
                          type: "status",
                          time: /* @__PURE__ */ new Date(),
                          ...ee,
                          stage: ee == null ? void 0 : ee.stage,
                          queue: !0,
                          endpoint: j,
                          fn_index: E
                        }), qt && ["sse_v2", "sse_v2.1", "sse_v3"].includes(ue) && uc(ke, qt));
                      qt && (X({
                        type: "data",
                        time: /* @__PURE__ */ new Date(),
                        data: qt.data,
                        endpoint: j,
                        fn_index: E
                      }), L && X({
                        type: "status",
                        time: /* @__PURE__ */ new Date(),
                        ...L,
                        stage: ee == null ? void 0 : ee.stage,
                        queue: !0,
                        endpoint: j,
                        fn_index: E
                      })), ((ee == null ? void 0 : ee.stage) === "complete" || (ee == null ? void 0 : ee.stage) === "error") && (b[ke] && delete b[ke], ke in B && delete B[ke]);
                    } catch (Q) {
                      console.error("Unexpected client exception", Q), X({
                        type: "status",
                        stage: "error",
                        message: "An Unexpected Error Occurred!",
                        queue: !0,
                        endpoint: j,
                        fn_index: E,
                        time: /* @__PURE__ */ new Date()
                      }), ["sse_v2", "sse_v2.1"].includes(ue) && N();
                    }
                  };
                  ke in w && (w[ke].forEach(
                    (de) => ge(de)
                  ), delete w[ke]), b[ke] = ge, C.add(ke), y || ae();
                }
              }));
          }
        );
        function uc(ne, Ee) {
          !B[ne] ? (B[ne] = [], Ee.data.forEach((te, ge) => {
            B[ne][ge] = te;
          })) : Ee.data.forEach((te, ge) => {
            let de = bc(
              B[ne][ge],
              te
            );
            B[ne][ge] = de, Ee.data[ge] = de;
          });
        }
        function X(ne) {
          const le = Ut[ne.type] || [];
          le == null || le.forEach((te) => te(ne));
        }
        function Bl(ne, Ee) {
          const le = Ut, te = le[ne] || [];
          return le[ne] = te, te == null || te.push(Ee), { on: Bl, off: ki, cancel: Ll, destroy: Nl };
        }
        function ki(ne, Ee) {
          const le = Ut;
          let te = le[ne] || [];
          return te = te == null ? void 0 : te.filter((ge) => ge !== Ee), le[ne] = te, { on: Bl, off: ki, cancel: Ll, destroy: Nl };
        }
        async function Ll() {
          const ne = {
            stage: "complete",
            queue: !1,
            time: /* @__PURE__ */ new Date()
          };
          L = ne, X({
            ...ne,
            type: "status",
            endpoint: j,
            fn_index: E
          });
          let Ee = {};
          ue === "ws" ? (I && I.readyState === 0 ? I.addEventListener("open", () => {
            I.close();
          }) : I.close(), Ee = { fn_index: E, session_hash: p }) : (K.close(), Ee = { event_id: ke });
          try {
            await t(`${H.root}/reset`, {
              headers: { "Content-Type": "application/json" },
              method: "POST",
              body: JSON.stringify(Ee)
            });
          } catch {
            console.warn(
              "The `/reset` endpoint could not be called. Subsequent endpoint results may be unreliable."
            );
          }
        }
        function Nl() {
          for (const ne in Ut)
            Ut[ne].forEach((Ee) => {
              ki(ne, Ee);
            });
        }
        return {
          on: Bl,
          off: ki,
          cancel: Ll,
          destroy: Nl
        };
      }
      function ae() {
        y = !0;
        let P = new URLSearchParams({
          session_hash: p
        }).toString(), J = new URL(`${H.root}/queue/data?${P}`);
        k = e(J), k.onmessage = async function(Z) {
          let g = JSON.parse(Z.data);
          const E = g.event_id;
          if (!E)
            await Promise.all(
              Object.keys(b).map(
                (T) => b[T](g)
              )
            );
          else if (b[E]) {
            g.msg === "process_completed" && ["sse", "sse_v1", "sse_v2", "sse_v2.1"].includes(H.protocol) && (C.delete(E), C.size === 0 && N());
            let T = b[E];
            window.setTimeout(T, 0, g);
          } else
            w[E] || (w[E] = []), w[E].push(g);
          g.msg === "close_stream" && N();
        }, k.onerror = async function(Z) {
          await Promise.all(
            Object.keys(b).map(
              (g) => b[g]({
                msg: "unexpected_error",
                message: Ft
              })
            )
          ), N();
        };
      }
      function N() {
        y = !1, k == null || k.close();
      }
      async function S(P, J, Z) {
        var g;
        const E = { "Content-Type": "application/json" };
        c && (E.Authorization = `Bearer ${c}`);
        let T, I = H.components.find(
          (j) => j.id === P
        );
        (g = I == null ? void 0 : I.props) != null && g.root_url ? T = I.props.root_url : T = H.root;
        const K = await t(
          `${T}/component_server/`,
          {
            method: "POST",
            body: JSON.stringify({
              data: Z,
              component_id: P,
              fn_name: J,
              session_hash: p
            }),
            headers: E
          }
        );
        if (!K.ok)
          throw new Error(
            "Could not connect to component server: " + K.statusText
          );
        return await K.json();
      }
      async function pe(P) {
        if (q)
          return q;
        const J = { "Content-Type": "application/json" };
        c && (J.Authorization = `Bearer ${c}`);
        let Z;
        if (Tr(P.version || "2.0.0", "3.30") < 0 ? Z = await t(
          "https://gradio-space-api-fetcher-v2.hf.space/api",
          {
            method: "POST",
            body: JSON.stringify({
              serialize: !1,
              config: JSON.stringify(P)
            }),
            headers: J
          }
        ) : Z = await t(`${P.root}/info`, {
          headers: J
        }), !Z.ok)
          throw new Error(Ft);
        let g = await Z.json();
        return "api" in g && (g = g.api), g.named_endpoints["/predict"] && !g.unnamed_endpoints[0] && (g.unnamed_endpoints[0] = g.named_endpoints["/predict"]), yc(g, P, R);
      }
    });
  }
  async function o(r, s, a, u) {
    const c = await Lo(
      s,
      void 0,
      [],
      !0,
      a
    );
    return Promise.all(
      c.map(async ({ path: f, blob: d, type: _ }) => {
        if (d) {
          const m = (await i(r, [d], u)).files[0];
          return { path: f, file_url: m, type: _, name: d == null ? void 0 : d.name };
        }
        return { path: f, type: _ };
      })
    ).then((f) => (f.forEach(({ path: d, file_url: _, type: m, name: h }) => {
      if (m === "Gallery")
        Lr(s, _, d);
      else if (_) {
        const p = new or({ path: _, orig_name: h });
        Lr(s, p, d);
      }
    }), s));
  }
}
const { post_data: H2, upload_files: wc, client: P2, handle_blob: R2 } = vc(
  fetch,
  (...t) => new EventSource(...t)
);
function Ar(t, e, n, i) {
  switch (t.type) {
    case "string":
      return "string";
    case "boolean":
      return "boolean";
    case "number":
      return "number";
  }
  if (n === "JSONSerializable" || n === "StringSerializable")
    return "any";
  if (n === "ListStringSerializable")
    return "string[]";
  if (e === "Image")
    return i === "parameter" ? "Blob | File | Buffer" : "string";
  if (n === "FileSerializable")
    return (t == null ? void 0 : t.type) === "array" ? i === "parameter" ? "(Blob | File | Buffer)[]" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}[]" : i === "parameter" ? "Blob | File | Buffer" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}";
  if (n === "GallerySerializable")
    return i === "parameter" ? "[(Blob | File | Buffer), (string | null)][]" : "[{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}, (string | null))][]";
}
function Br(t, e) {
  return e === "GallerySerializable" ? "array of [file, label] tuples" : e === "ListStringSerializable" ? "array of strings" : e === "FileSerializable" ? "array of files or single file" : t.description;
}
function yc(t, e, n) {
  const i = {
    named_endpoints: {},
    unnamed_endpoints: {}
  };
  for (const l in t) {
    const o = t[l];
    for (const r in o) {
      const s = e.dependencies[r] ? r : n[r.replace("/", "")], a = o[r];
      i[l][r] = {}, i[l][r].parameters = {}, i[l][r].returns = {}, i[l][r].type = e.dependencies[s].types, i[l][r].parameters = a.parameters.map(
        ({ label: u, component: c, type: f, serializer: d }) => ({
          label: u,
          component: c,
          type: Ar(f, c, d, "parameter"),
          description: Br(f, d)
        })
      ), i[l][r].returns = a.returns.map(
        ({ label: u, component: c, type: f, serializer: d }) => ({
          label: u,
          component: c,
          type: Ar(f, c, d, "return"),
          description: Br(f, d)
        })
      );
    }
  }
  return i;
}
async function kc(t, e) {
  try {
    return (await (await fetch(`https://huggingface.co/api/spaces/${t}/jwt`, {
      headers: {
        Authorization: `Bearer ${e}`
      }
    })).json()).token || !1;
  } catch (n) {
    return console.error(n), !1;
  }
}
function Lr(t, e, n) {
  for (; n.length > 1; )
    t = t[n.shift()];
  t[n.shift()] = e;
}
async function Lo(t, e = void 0, n = [], i = !1, l = void 0) {
  if (Array.isArray(t)) {
    let o = [];
    return await Promise.all(
      t.map(async (r, s) => {
        var a;
        let u = n.slice();
        u.push(s);
        const c = await Lo(
          t[s],
          i ? ((a = l == null ? void 0 : l.parameters[s]) == null ? void 0 : a.component) || void 0 : e,
          u,
          !1,
          l
        );
        o = o.concat(c);
      })
    ), o;
  } else {
    if (globalThis.Buffer && t instanceof globalThis.Buffer)
      return [
        {
          path: n,
          blob: e === "Image" ? !1 : new Os([t]),
          type: e
        }
      ];
    if (typeof t == "object") {
      let o = [];
      for (let r in t)
        if (t.hasOwnProperty(r)) {
          let s = n.slice();
          s.push(r), o = o.concat(
            await Lo(
              t[r],
              void 0,
              s,
              !1,
              l
            )
          );
        }
      return o;
    }
  }
  return [];
}
function Ec(t, e) {
  var n, i, l, o;
  return !(((i = (n = e == null ? void 0 : e.dependencies) == null ? void 0 : n[t]) == null ? void 0 : i.queue) === null ? e.enable_queue : (o = (l = e == null ? void 0 : e.dependencies) == null ? void 0 : l[t]) != null && o.queue) || !1;
}
async function Nr(t, e, n) {
  const i = {};
  if (n && (i.Authorization = `Bearer ${n}`), typeof window < "u" && window.gradio_config && location.origin !== "http://localhost:9876" && !window.gradio_config.dev_mode) {
    const l = window.gradio_config.root, o = window.gradio_config;
    return o.root = Hs(e, o.root, !1), { ...o, path: l };
  } else if (e) {
    let l = await t(`${e}/config`, {
      headers: i
    });
    if (l.status === 200) {
      const o = await l.json();
      return o.path = o.path ?? "", o.root = e, o;
    }
    throw new Error("Could not get config.");
  }
  throw new Error("No config or app endpoint found");
}
async function No(t, e, n) {
  let i = e === "subdomain" ? `https://huggingface.co/api/spaces/by-subdomain/${t}` : `https://huggingface.co/api/spaces/${t}`, l, o;
  try {
    if (l = await fetch(i), o = l.status, o !== 200)
      throw new Error();
    l = await l.json();
  } catch {
    n({
      status: "error",
      load_status: "error",
      message: "Could not get space status",
      detail: "NOT_FOUND"
    });
    return;
  }
  if (!l || o !== 200)
    return;
  const {
    runtime: { stage: r },
    id: s
  } = l;
  switch (r) {
    case "STOPPED":
    case "SLEEPING":
      n({
        status: "sleeping",
        load_status: "pending",
        message: "Space is asleep. Waking it up...",
        detail: r
      }), setTimeout(() => {
        No(t, e, n);
      }, 1e3);
      break;
    case "PAUSED":
      n({
        status: "paused",
        load_status: "error",
        message: "This space has been paused by the author. If you would like to try this demo, consider duplicating the space.",
        detail: r,
        discussions_enabled: await Cr(s)
      });
      break;
    case "RUNNING":
    case "RUNNING_BUILDING":
      n({
        status: "running",
        load_status: "complete",
        message: "",
        detail: r
      });
      break;
    case "BUILDING":
      n({
        status: "building",
        load_status: "pending",
        message: "Space is building...",
        detail: r
      }), setTimeout(() => {
        No(t, e, n);
      }, 1e3);
      break;
    default:
      n({
        status: "space_error",
        load_status: "error",
        message: "This space is experiencing an issue.",
        detail: r,
        discussions_enabled: await Cr(s)
      });
      break;
  }
}
function Pl(t, e) {
  switch (t.msg) {
    case "send_data":
      return { type: "data" };
    case "send_hash":
      return { type: "hash" };
    case "queue_full":
      return {
        type: "update",
        status: {
          queue: !0,
          message: Rs,
          stage: "error",
          code: t.code,
          success: t.success
        }
      };
    case "heartbeat":
      return {
        type: "heartbeat"
      };
    case "unexpected_error":
      return {
        type: "unexpected_error",
        status: {
          queue: !0,
          message: t.message,
          stage: "error",
          success: !1
        }
      };
    case "estimation":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: e || "pending",
          code: t.code,
          size: t.queue_size,
          position: t.rank,
          eta: t.rank_eta,
          success: t.success
        }
      };
    case "progress":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: t.code,
          progress_data: t.progress_data,
          success: t.success
        }
      };
    case "log":
      return { type: "log", data: t };
    case "process_generating":
      return {
        type: "generating",
        status: {
          queue: !0,
          message: t.success ? null : t.output.error,
          stage: t.success ? "generating" : "error",
          code: t.code,
          progress_data: t.progress_data,
          eta: t.average_duration
        },
        data: t.success ? t.output : null
      };
    case "process_completed":
      return "error" in t.output ? {
        type: "update",
        status: {
          queue: !0,
          message: t.output.error,
          stage: "error",
          code: t.code,
          success: t.success
        }
      } : {
        type: "complete",
        status: {
          queue: !0,
          message: t.success ? void 0 : t.output.error,
          stage: t.success ? "complete" : "error",
          code: t.code,
          progress_data: t.progress_data
        },
        data: t.success ? t.output : null
      };
    case "process_starts":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: t.code,
          size: t.rank,
          position: 0,
          success: t.success,
          eta: t.eta
        }
      };
  }
  return { type: "none", status: { stage: "error", queue: !0 } };
}
function tn() {
}
const Sc = (t) => t;
function Tc(t) {
  return t();
}
function Cc(t) {
  t.forEach(Tc);
}
function Ac(t) {
  return typeof t == "function";
}
function Bc(t, e) {
  return t != t ? e == e : t !== e || t && typeof t == "object" || typeof t == "function";
}
function Lc(t, ...e) {
  if (t == null) {
    for (const i of e)
      i(void 0);
    return tn;
  }
  const n = t.subscribe(...e);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
const Ds = typeof window < "u";
let Ir = Ds ? () => window.performance.now() : () => Date.now(), js = Ds ? (t) => requestAnimationFrame(t) : tn;
const An = /* @__PURE__ */ new Set();
function Ms(t) {
  An.forEach((e) => {
    e.c(t) || (An.delete(e), e.f());
  }), An.size !== 0 && js(Ms);
}
function Nc(t) {
  let e;
  return An.size === 0 && js(Ms), {
    promise: new Promise((n) => {
      An.add(e = { c: t, f: n });
    }),
    abort() {
      An.delete(e);
    }
  };
}
function Ic(t, { delay: e = 0, duration: n = 400, easing: i = Sc } = {}) {
  const l = +getComputedStyle(t).opacity;
  return {
    delay: e,
    duration: n,
    easing: i,
    css: (o) => `opacity: ${o * l}`
  };
}
const _n = [];
function Hc(t, e) {
  return {
    subscribe: hi(t, e).subscribe
  };
}
function hi(t, e = tn) {
  let n;
  const i = /* @__PURE__ */ new Set();
  function l(s) {
    if (Bc(t, s) && (t = s, n)) {
      const a = !_n.length;
      for (const u of i)
        u[1](), _n.push(u, t);
      if (a) {
        for (let u = 0; u < _n.length; u += 2)
          _n[u][0](_n[u + 1]);
        _n.length = 0;
      }
    }
  }
  function o(s) {
    l(s(t));
  }
  function r(s, a = tn) {
    const u = [s, a];
    return i.add(u), i.size === 1 && (n = e(l, o) || tn), s(t), () => {
      i.delete(u), i.size === 0 && n && (n(), n = null);
    };
  }
  return { set: l, update: o, subscribe: r };
}
function Un(t, e, n) {
  const i = !Array.isArray(t), l = i ? [t] : t;
  if (!l.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const o = e.length < 2;
  return Hc(n, (r, s) => {
    let a = !1;
    const u = [];
    let c = 0, f = tn;
    const d = () => {
      if (c)
        return;
      f();
      const m = e(i ? u[0] : u, r, s);
      o ? r(m) : f = Ac(m) ? m : tn;
    }, _ = l.map(
      (m, h) => Lc(
        m,
        (p) => {
          u[h] = p, c &= ~(1 << h), a && d();
        },
        () => {
          c |= 1 << h;
        }
      )
    );
    return a = !0, d(), function() {
      Cc(_), f(), a = !1;
    };
  });
}
function Hr(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Io(t, e, n, i) {
  if (typeof n == "number" || Hr(n)) {
    const l = i - n, o = (n - e) / (t.dt || 1 / 60), r = t.opts.stiffness * l, s = t.opts.damping * o, a = (r - s) * t.inv_mass, u = (o + a) * t.dt;
    return Math.abs(u) < t.opts.precision && Math.abs(l) < t.opts.precision ? i : (t.settled = !1, Hr(n) ? new Date(n.getTime() + u) : n + u);
  } else {
    if (Array.isArray(n))
      return n.map(
        (l, o) => Io(t, e[o], n[o], i[o])
      );
    if (typeof n == "object") {
      const l = {};
      for (const o in n)
        l[o] = Io(t, e[o], n[o], i[o]);
      return l;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function Pr(t, e = {}) {
  const n = hi(t), { stiffness: i = 0.15, damping: l = 0.8, precision: o = 0.01 } = e;
  let r, s, a, u = t, c = t, f = 1, d = 0, _ = !1;
  function m(p, v = {}) {
    c = p;
    const y = a = {};
    return t == null || v.hard || h.stiffness >= 1 && h.damping >= 1 ? (_ = !0, r = Ir(), u = p, n.set(t = c), Promise.resolve()) : (v.soft && (d = 1 / ((v.soft === !0 ? 0.5 : +v.soft) * 60), f = 0), s || (r = Ir(), _ = !1, s = Nc((w) => {
      if (_)
        return _ = !1, s = null, !1;
      f = Math.min(f + d, 1);
      const B = {
        inv_mass: f,
        opts: h,
        settled: !0,
        dt: (w - r) * 60 / 1e3
      }, k = Io(B, u, t, c);
      return r = w, u = t, n.set(t = k), B.settled && (s = null), !B.settled;
    })), new Promise((w) => {
      s.promise.then(() => {
        y === a && w();
      });
    }));
  }
  const h = {
    set: m,
    update: (p, v) => m(p(c, t), v),
    subscribe: n.subscribe,
    stiffness: i,
    damping: l,
    precision: o
  };
  return h;
}
function Pc(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var Rc = function(e) {
  return Oc(e) && !Dc(e);
};
function Oc(t) {
  return !!t && typeof t == "object";
}
function Dc(t) {
  var e = Object.prototype.toString.call(t);
  return e === "[object RegExp]" || e === "[object Date]" || xc(t);
}
var jc = typeof Symbol == "function" && Symbol.for, Mc = jc ? Symbol.for("react.element") : 60103;
function xc(t) {
  return t.$$typeof === Mc;
}
function Uc(t) {
  return Array.isArray(t) ? [] : {};
}
function fi(t, e) {
  return e.clone !== !1 && e.isMergeableObject(t) ? Bn(Uc(t), t, e) : t;
}
function qc(t, e, n) {
  return t.concat(e).map(function(i) {
    return fi(i, n);
  });
}
function Fc(t, e) {
  if (!e.customMerge)
    return Bn;
  var n = e.customMerge(t);
  return typeof n == "function" ? n : Bn;
}
function Gc(t) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(t).filter(function(e) {
    return Object.propertyIsEnumerable.call(t, e);
  }) : [];
}
function Rr(t) {
  return Object.keys(t).concat(Gc(t));
}
function xs(t, e) {
  try {
    return e in t;
  } catch {
    return !1;
  }
}
function Vc(t, e) {
  return xs(t, e) && !(Object.hasOwnProperty.call(t, e) && Object.propertyIsEnumerable.call(t, e));
}
function zc(t, e, n) {
  var i = {};
  return n.isMergeableObject(t) && Rr(t).forEach(function(l) {
    i[l] = fi(t[l], n);
  }), Rr(e).forEach(function(l) {
    Vc(t, l) || (xs(t, l) && n.isMergeableObject(e[l]) ? i[l] = Fc(l, n)(t[l], e[l], n) : i[l] = fi(e[l], n));
  }), i;
}
function Bn(t, e, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || qc, n.isMergeableObject = n.isMergeableObject || Rc, n.cloneUnlessOtherwiseSpecified = fi;
  var i = Array.isArray(e), l = Array.isArray(t), o = i === l;
  return o ? i ? n.arrayMerge(t, e, n) : zc(t, e, n) : fi(e, n);
}
Bn.all = function(e, n) {
  if (!Array.isArray(e))
    throw new Error("first argument should be an array");
  return e.reduce(function(i, l) {
    return Bn(i, l, n);
  }, {});
};
var Xc = Bn, Wc = Xc;
const Zc = /* @__PURE__ */ Pc(Wc);
var Ho = function(t, e) {
  return Ho = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, i) {
    n.__proto__ = i;
  } || function(n, i) {
    for (var l in i)
      Object.prototype.hasOwnProperty.call(i, l) && (n[l] = i[l]);
  }, Ho(t, e);
};
function ul(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  Ho(t, e);
  function n() {
    this.constructor = t;
  }
  t.prototype = e === null ? Object.create(e) : (n.prototype = e.prototype, new n());
}
var W = function() {
  return W = Object.assign || function(e) {
    for (var n, i = 1, l = arguments.length; i < l; i++) {
      n = arguments[i];
      for (var o in n)
        Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
    }
    return e;
  }, W.apply(this, arguments);
};
function Rl(t, e, n) {
  if (n || arguments.length === 2)
    for (var i = 0, l = e.length, o; i < l; i++)
      (o || !(i in e)) && (o || (o = Array.prototype.slice.call(e, 0, i)), o[i] = e[i]);
  return t.concat(o || Array.prototype.slice.call(e));
}
var U;
(function(t) {
  t[t.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", t[t.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", t[t.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", t[t.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", t[t.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", t[t.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", t[t.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", t[t.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", t[t.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", t[t.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", t[t.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", t[t.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", t[t.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", t[t.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", t[t.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", t[t.INVALID_TAG = 23] = "INVALID_TAG", t[t.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", t[t.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", t[t.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(U || (U = {}));
var ie;
(function(t) {
  t[t.literal = 0] = "literal", t[t.argument = 1] = "argument", t[t.number = 2] = "number", t[t.date = 3] = "date", t[t.time = 4] = "time", t[t.select = 5] = "select", t[t.plural = 6] = "plural", t[t.pound = 7] = "pound", t[t.tag = 8] = "tag";
})(ie || (ie = {}));
var Ln;
(function(t) {
  t[t.number = 0] = "number", t[t.dateTime = 1] = "dateTime";
})(Ln || (Ln = {}));
function Or(t) {
  return t.type === ie.literal;
}
function Jc(t) {
  return t.type === ie.argument;
}
function Us(t) {
  return t.type === ie.number;
}
function qs(t) {
  return t.type === ie.date;
}
function Fs(t) {
  return t.type === ie.time;
}
function Gs(t) {
  return t.type === ie.select;
}
function Vs(t) {
  return t.type === ie.plural;
}
function Qc(t) {
  return t.type === ie.pound;
}
function zs(t) {
  return t.type === ie.tag;
}
function Xs(t) {
  return !!(t && typeof t == "object" && t.type === Ln.number);
}
function Po(t) {
  return !!(t && typeof t == "object" && t.type === Ln.dateTime);
}
var Ws = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, Yc = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function Kc(t) {
  var e = {};
  return t.replace(Yc, function(n) {
    var i = n.length;
    switch (n[0]) {
      case "G":
        e.era = i === 4 ? "long" : i === 5 ? "narrow" : "short";
        break;
      case "y":
        e.year = i === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        e.month = ["numeric", "2-digit", "short", "long", "narrow"][i - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        e.day = ["numeric", "2-digit"][i - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        e.weekday = i === 4 ? "short" : i === 5 ? "narrow" : "short";
        break;
      case "e":
        if (i < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "c":
        if (i < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "a":
        e.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        e.hourCycle = "h12", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "H":
        e.hourCycle = "h23", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "K":
        e.hourCycle = "h11", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "k":
        e.hourCycle = "h24", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        e.minute = ["numeric", "2-digit"][i - 1];
        break;
      case "s":
        e.second = ["numeric", "2-digit"][i - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        e.timeZoneName = i < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), e;
}
var $c = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function ef(t) {
  if (t.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var e = t.split($c).filter(function(d) {
    return d.length > 0;
  }), n = [], i = 0, l = e; i < l.length; i++) {
    var o = l[i], r = o.split("/");
    if (r.length === 0)
      throw new Error("Invalid number skeleton");
    for (var s = r[0], a = r.slice(1), u = 0, c = a; u < c.length; u++) {
      var f = c[u];
      if (f.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: s, options: a });
  }
  return n;
}
function tf(t) {
  return t.replace(/^(.*?)-/, "");
}
var Dr = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, Zs = /^(@+)?(\+|#+)?[rs]?$/g, nf = /(\*)(0+)|(#+)(0+)|(0+)/g, Js = /^(0+)$/;
function jr(t) {
  var e = {};
  return t[t.length - 1] === "r" ? e.roundingPriority = "morePrecision" : t[t.length - 1] === "s" && (e.roundingPriority = "lessPrecision"), t.replace(Zs, function(n, i, l) {
    return typeof l != "string" ? (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length) : l === "+" ? e.minimumSignificantDigits = i.length : i[0] === "#" ? e.maximumSignificantDigits = i.length : (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length + (typeof l == "string" ? l.length : 0)), "";
  }), e;
}
function Qs(t) {
  switch (t) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function lf(t) {
  var e;
  if (t[0] === "E" && t[1] === "E" ? (e = {
    notation: "engineering"
  }, t = t.slice(2)) : t[0] === "E" && (e = {
    notation: "scientific"
  }, t = t.slice(1)), e) {
    var n = t.slice(0, 2);
    if (n === "+!" ? (e.signDisplay = "always", t = t.slice(2)) : n === "+?" && (e.signDisplay = "exceptZero", t = t.slice(2)), !Js.test(t))
      throw new Error("Malformed concise eng/scientific notation");
    e.minimumIntegerDigits = t.length;
  }
  return e;
}
function Mr(t) {
  var e = {}, n = Qs(t);
  return n || e;
}
function of(t) {
  for (var e = {}, n = 0, i = t; n < i.length; n++) {
    var l = i[n];
    switch (l.stem) {
      case "percent":
      case "%":
        e.style = "percent";
        continue;
      case "%x100":
        e.style = "percent", e.scale = 100;
        continue;
      case "currency":
        e.style = "currency", e.currency = l.options[0];
        continue;
      case "group-off":
      case ",_":
        e.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        e.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        e.style = "unit", e.unit = tf(l.options[0]);
        continue;
      case "compact-short":
      case "K":
        e.notation = "compact", e.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        e.notation = "compact", e.compactDisplay = "long";
        continue;
      case "scientific":
        e = W(W(W({}, e), { notation: "scientific" }), l.options.reduce(function(a, u) {
          return W(W({}, a), Mr(u));
        }, {}));
        continue;
      case "engineering":
        e = W(W(W({}, e), { notation: "engineering" }), l.options.reduce(function(a, u) {
          return W(W({}, a), Mr(u));
        }, {}));
        continue;
      case "notation-simple":
        e.notation = "standard";
        continue;
      case "unit-width-narrow":
        e.currencyDisplay = "narrowSymbol", e.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        e.currencyDisplay = "code", e.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        e.currencyDisplay = "name", e.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        e.currencyDisplay = "symbol";
        continue;
      case "scale":
        e.scale = parseFloat(l.options[0]);
        continue;
      case "integer-width":
        if (l.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        l.options[0].replace(nf, function(a, u, c, f, d, _) {
          if (u)
            e.minimumIntegerDigits = c.length;
          else {
            if (f && d)
              throw new Error("We currently do not support maximum integer digits");
            if (_)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (Js.test(l.stem)) {
      e.minimumIntegerDigits = l.stem.length;
      continue;
    }
    if (Dr.test(l.stem)) {
      if (l.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      l.stem.replace(Dr, function(a, u, c, f, d, _) {
        return c === "*" ? e.minimumFractionDigits = u.length : f && f[0] === "#" ? e.maximumFractionDigits = f.length : d && _ ? (e.minimumFractionDigits = d.length, e.maximumFractionDigits = d.length + _.length) : (e.minimumFractionDigits = u.length, e.maximumFractionDigits = u.length), "";
      });
      var o = l.options[0];
      o === "w" ? e = W(W({}, e), { trailingZeroDisplay: "stripIfInteger" }) : o && (e = W(W({}, e), jr(o)));
      continue;
    }
    if (Zs.test(l.stem)) {
      e = W(W({}, e), jr(l.stem));
      continue;
    }
    var r = Qs(l.stem);
    r && (e = W(W({}, e), r));
    var s = lf(l.stem);
    s && (e = W(W({}, e), s));
  }
  return e;
}
var Ei = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function rf(t, e) {
  for (var n = "", i = 0; i < t.length; i++) {
    var l = t.charAt(i);
    if (l === "j") {
      for (var o = 0; i + 1 < t.length && t.charAt(i + 1) === l; )
        o++, i++;
      var r = 1 + (o & 1), s = o < 2 ? 1 : 3 + (o >> 1), a = "a", u = af(e);
      for ((u == "H" || u == "k") && (s = 0); s-- > 0; )
        n += a;
      for (; r-- > 0; )
        n = u + n;
    } else
      l === "J" ? n += "H" : n += l;
  }
  return n;
}
function af(t) {
  var e = t.hourCycle;
  if (e === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  t.hourCycles && // @ts-ignore
  t.hourCycles.length && (e = t.hourCycles[0]), e)
    switch (e) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = t.language, i;
  n !== "root" && (i = t.maximize().region);
  var l = Ei[i || ""] || Ei[n || ""] || Ei["".concat(n, "-001")] || Ei["001"];
  return l[0];
}
var Ol, sf = new RegExp("^".concat(Ws.source, "*")), uf = new RegExp("".concat(Ws.source, "*$"));
function G(t, e) {
  return { start: t, end: e };
}
var cf = !!String.prototype.startsWith, ff = !!String.fromCodePoint, df = !!Object.fromEntries, _f = !!String.prototype.codePointAt, mf = !!String.prototype.trimStart, hf = !!String.prototype.trimEnd, pf = !!Number.isSafeInteger, gf = pf ? Number.isSafeInteger : function(t) {
  return typeof t == "number" && isFinite(t) && Math.floor(t) === t && Math.abs(t) <= 9007199254740991;
}, Ro = !0;
try {
  var bf = Ks("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Ro = ((Ol = bf.exec("a")) === null || Ol === void 0 ? void 0 : Ol[0]) === "a";
} catch {
  Ro = !1;
}
var xr = cf ? (
  // Native
  function(e, n, i) {
    return e.startsWith(n, i);
  }
) : (
  // For IE11
  function(e, n, i) {
    return e.slice(i, i + n.length) === n;
  }
), Oo = ff ? String.fromCodePoint : (
  // IE11
  function() {
    for (var e = [], n = 0; n < arguments.length; n++)
      e[n] = arguments[n];
    for (var i = "", l = e.length, o = 0, r; l > o; ) {
      if (r = e[o++], r > 1114111)
        throw RangeError(r + " is not a valid code point");
      i += r < 65536 ? String.fromCharCode(r) : String.fromCharCode(((r -= 65536) >> 10) + 55296, r % 1024 + 56320);
    }
    return i;
  }
), Ur = (
  // native
  df ? Object.fromEntries : (
    // Ponyfill
    function(e) {
      for (var n = {}, i = 0, l = e; i < l.length; i++) {
        var o = l[i], r = o[0], s = o[1];
        n[r] = s;
      }
      return n;
    }
  )
), Ys = _f ? (
  // Native
  function(e, n) {
    return e.codePointAt(n);
  }
) : (
  // IE 11
  function(e, n) {
    var i = e.length;
    if (!(n < 0 || n >= i)) {
      var l = e.charCodeAt(n), o;
      return l < 55296 || l > 56319 || n + 1 === i || (o = e.charCodeAt(n + 1)) < 56320 || o > 57343 ? l : (l - 55296 << 10) + (o - 56320) + 65536;
    }
  }
), vf = mf ? (
  // Native
  function(e) {
    return e.trimStart();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(sf, "");
  }
), wf = hf ? (
  // Native
  function(e) {
    return e.trimEnd();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(uf, "");
  }
);
function Ks(t, e) {
  return new RegExp(t, e);
}
var Do;
if (Ro) {
  var qr = Ks("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Do = function(e, n) {
    var i;
    qr.lastIndex = n;
    var l = qr.exec(e);
    return (i = l[1]) !== null && i !== void 0 ? i : "";
  };
} else
  Do = function(e, n) {
    for (var i = []; ; ) {
      var l = Ys(e, n);
      if (l === void 0 || $s(l) || Sf(l))
        break;
      i.push(l), n += l >= 65536 ? 2 : 1;
    }
    return Oo.apply(void 0, i);
  };
var yf = (
  /** @class */
  function() {
    function t(e, n) {
      n === void 0 && (n = {}), this.message = e, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return t.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, t.prototype.parseMessage = function(e, n, i) {
      for (var l = []; !this.isEOF(); ) {
        var o = this.char();
        if (o === 123) {
          var r = this.parseArgument(e, i);
          if (r.err)
            return r;
          l.push(r.val);
        } else {
          if (o === 125 && e > 0)
            break;
          if (o === 35 && (n === "plural" || n === "selectordinal")) {
            var s = this.clonePosition();
            this.bump(), l.push({
              type: ie.pound,
              location: G(s, this.clonePosition())
            });
          } else if (o === 60 && !this.ignoreTag && this.peek() === 47) {
            if (i)
              break;
            return this.error(U.UNMATCHED_CLOSING_TAG, G(this.clonePosition(), this.clonePosition()));
          } else if (o === 60 && !this.ignoreTag && jo(this.peek() || 0)) {
            var r = this.parseTag(e, n);
            if (r.err)
              return r;
            l.push(r.val);
          } else {
            var r = this.parseLiteral(e, n);
            if (r.err)
              return r;
            l.push(r.val);
          }
        }
      }
      return { val: l, err: null };
    }, t.prototype.parseTag = function(e, n) {
      var i = this.clonePosition();
      this.bump();
      var l = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: ie.literal,
            value: "<".concat(l, "/>"),
            location: G(i, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var o = this.parseMessage(e + 1, n, !0);
        if (o.err)
          return o;
        var r = o.val, s = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !jo(this.char()))
            return this.error(U.INVALID_TAG, G(s, this.clonePosition()));
          var a = this.clonePosition(), u = this.parseTagName();
          return l !== u ? this.error(U.UNMATCHED_CLOSING_TAG, G(a, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: ie.tag,
              value: l,
              children: r,
              location: G(i, this.clonePosition())
            },
            err: null
          } : this.error(U.INVALID_TAG, G(s, this.clonePosition())));
        } else
          return this.error(U.UNCLOSED_TAG, G(i, this.clonePosition()));
      } else
        return this.error(U.INVALID_TAG, G(i, this.clonePosition()));
    }, t.prototype.parseTagName = function() {
      var e = this.offset();
      for (this.bump(); !this.isEOF() && Ef(this.char()); )
        this.bump();
      return this.message.slice(e, this.offset());
    }, t.prototype.parseLiteral = function(e, n) {
      for (var i = this.clonePosition(), l = ""; ; ) {
        var o = this.tryParseQuote(n);
        if (o) {
          l += o;
          continue;
        }
        var r = this.tryParseUnquoted(e, n);
        if (r) {
          l += r;
          continue;
        }
        var s = this.tryParseLeftAngleBracket();
        if (s) {
          l += s;
          continue;
        }
        break;
      }
      var a = G(i, this.clonePosition());
      return {
        val: { type: ie.literal, value: l, location: a },
        err: null
      };
    }, t.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !kf(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, t.prototype.tryParseQuote = function(e) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (e === "plural" || e === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var i = this.char();
        if (i === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(i);
        this.bump();
      }
      return Oo.apply(void 0, n);
    }, t.prototype.tryParseUnquoted = function(e, n) {
      if (this.isEOF())
        return null;
      var i = this.char();
      return i === 60 || i === 123 || i === 35 && (n === "plural" || n === "selectordinal") || i === 125 && e > 0 ? null : (this.bump(), Oo(i));
    }, t.prototype.parseArgument = function(e, n) {
      var i = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(U.EXPECT_ARGUMENT_CLOSING_BRACE, G(i, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(U.EMPTY_ARGUMENT, G(i, this.clonePosition()));
      var l = this.parseIdentifierIfPossible().value;
      if (!l)
        return this.error(U.MALFORMED_ARGUMENT, G(i, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(U.EXPECT_ARGUMENT_CLOSING_BRACE, G(i, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: ie.argument,
              // value does not include the opening and closing braces.
              value: l,
              location: G(i, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(U.EXPECT_ARGUMENT_CLOSING_BRACE, G(i, this.clonePosition())) : this.parseArgumentOptions(e, n, l, i);
        default:
          return this.error(U.MALFORMED_ARGUMENT, G(i, this.clonePosition()));
      }
    }, t.prototype.parseIdentifierIfPossible = function() {
      var e = this.clonePosition(), n = this.offset(), i = Do(this.message, n), l = n + i.length;
      this.bumpTo(l);
      var o = this.clonePosition(), r = G(e, o);
      return { value: i, location: r };
    }, t.prototype.parseArgumentOptions = function(e, n, i, l) {
      var o, r = this.clonePosition(), s = this.parseIdentifierIfPossible().value, a = this.clonePosition();
      switch (s) {
        case "":
          return this.error(U.EXPECT_ARGUMENT_TYPE, G(r, a));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var u = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var c = this.clonePosition(), f = this.parseSimpleArgStyleIfPossible();
            if (f.err)
              return f;
            var d = wf(f.val);
            if (d.length === 0)
              return this.error(U.EXPECT_ARGUMENT_STYLE, G(this.clonePosition(), this.clonePosition()));
            var _ = G(c, this.clonePosition());
            u = { style: d, styleLocation: _ };
          }
          var m = this.tryParseArgumentClose(l);
          if (m.err)
            return m;
          var h = G(l, this.clonePosition());
          if (u && xr(u == null ? void 0 : u.style, "::", 0)) {
            var p = vf(u.style.slice(2));
            if (s === "number") {
              var f = this.parseNumberSkeletonFromString(p, u.styleLocation);
              return f.err ? f : {
                val: { type: ie.number, value: i, location: h, style: f.val },
                err: null
              };
            } else {
              if (p.length === 0)
                return this.error(U.EXPECT_DATE_TIME_SKELETON, h);
              var v = p;
              this.locale && (v = rf(p, this.locale));
              var d = {
                type: Ln.dateTime,
                pattern: v,
                location: u.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? Kc(v) : {}
              }, y = s === "date" ? ie.date : ie.time;
              return {
                val: { type: y, value: i, location: h, style: d },
                err: null
              };
            }
          }
          return {
            val: {
              type: s === "number" ? ie.number : s === "date" ? ie.date : ie.time,
              value: i,
              location: h,
              style: (o = u == null ? void 0 : u.style) !== null && o !== void 0 ? o : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var w = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(U.EXPECT_SELECT_ARGUMENT_OPTIONS, G(w, W({}, w)));
          this.bumpSpace();
          var B = this.parseIdentifierIfPossible(), k = 0;
          if (s !== "select" && B.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(U.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, G(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var f = this.tryParseDecimalInteger(U.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, U.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (f.err)
              return f;
            this.bumpSpace(), B = this.parseIdentifierIfPossible(), k = f.val;
          }
          var b = this.tryParsePluralOrSelectOptions(e, s, n, B);
          if (b.err)
            return b;
          var m = this.tryParseArgumentClose(l);
          if (m.err)
            return m;
          var C = G(l, this.clonePosition());
          return s === "select" ? {
            val: {
              type: ie.select,
              value: i,
              options: Ur(b.val),
              location: C
            },
            err: null
          } : {
            val: {
              type: ie.plural,
              value: i,
              options: Ur(b.val),
              offset: k,
              pluralType: s === "plural" ? "cardinal" : "ordinal",
              location: C
            },
            err: null
          };
        }
        default:
          return this.error(U.INVALID_ARGUMENT_TYPE, G(r, a));
      }
    }, t.prototype.tryParseArgumentClose = function(e) {
      return this.isEOF() || this.char() !== 125 ? this.error(U.EXPECT_ARGUMENT_CLOSING_BRACE, G(e, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, t.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var e = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var i = this.char();
        switch (i) {
          case 39: {
            this.bump();
            var l = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(U.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, G(l, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            e += 1, this.bump();
            break;
          }
          case 125: {
            if (e > 0)
              e -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, t.prototype.parseNumberSkeletonFromString = function(e, n) {
      var i = [];
      try {
        i = ef(e);
      } catch {
        return this.error(U.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: Ln.number,
          tokens: i,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? of(i) : {}
        },
        err: null
      };
    }, t.prototype.tryParsePluralOrSelectOptions = function(e, n, i, l) {
      for (var o, r = !1, s = [], a = /* @__PURE__ */ new Set(), u = l.value, c = l.location; ; ) {
        if (u.length === 0) {
          var f = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var d = this.tryParseDecimalInteger(U.EXPECT_PLURAL_ARGUMENT_SELECTOR, U.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (d.err)
              return d;
            c = G(f, this.clonePosition()), u = this.message.slice(f.offset, this.offset());
          } else
            break;
        }
        if (a.has(u))
          return this.error(n === "select" ? U.DUPLICATE_SELECT_ARGUMENT_SELECTOR : U.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, c);
        u === "other" && (r = !0), this.bumpSpace();
        var _ = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? U.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : U.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, G(this.clonePosition(), this.clonePosition()));
        var m = this.parseMessage(e + 1, n, i);
        if (m.err)
          return m;
        var h = this.tryParseArgumentClose(_);
        if (h.err)
          return h;
        s.push([
          u,
          {
            value: m.val,
            location: G(_, this.clonePosition())
          }
        ]), a.add(u), this.bumpSpace(), o = this.parseIdentifierIfPossible(), u = o.value, c = o.location;
      }
      return s.length === 0 ? this.error(n === "select" ? U.EXPECT_SELECT_ARGUMENT_SELECTOR : U.EXPECT_PLURAL_ARGUMENT_SELECTOR, G(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !r ? this.error(U.MISSING_OTHER_CLAUSE, G(this.clonePosition(), this.clonePosition())) : { val: s, err: null };
    }, t.prototype.tryParseDecimalInteger = function(e, n) {
      var i = 1, l = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (i = -1);
      for (var o = !1, r = 0; !this.isEOF(); ) {
        var s = this.char();
        if (s >= 48 && s <= 57)
          o = !0, r = r * 10 + (s - 48), this.bump();
        else
          break;
      }
      var a = G(l, this.clonePosition());
      return o ? (r *= i, gf(r) ? { val: r, err: null } : this.error(n, a)) : this.error(e, a);
    }, t.prototype.offset = function() {
      return this.position.offset;
    }, t.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, t.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, t.prototype.char = function() {
      var e = this.position.offset;
      if (e >= this.message.length)
        throw Error("out of bound");
      var n = Ys(this.message, e);
      if (n === void 0)
        throw Error("Offset ".concat(e, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, t.prototype.error = function(e, n) {
      return {
        val: null,
        err: {
          kind: e,
          message: this.message,
          location: n
        }
      };
    }, t.prototype.bump = function() {
      if (!this.isEOF()) {
        var e = this.char();
        e === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2);
      }
    }, t.prototype.bumpIf = function(e) {
      if (xr(this.message, e, this.offset())) {
        for (var n = 0; n < e.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, t.prototype.bumpUntil = function(e) {
      var n = this.offset(), i = this.message.indexOf(e, n);
      return i >= 0 ? (this.bumpTo(i), !0) : (this.bumpTo(this.message.length), !1);
    }, t.prototype.bumpTo = function(e) {
      if (this.offset() > e)
        throw Error("targetOffset ".concat(e, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (e = Math.min(e, this.message.length); ; ) {
        var n = this.offset();
        if (n === e)
          break;
        if (n > e)
          throw Error("targetOffset ".concat(e, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, t.prototype.bumpSpace = function() {
      for (; !this.isEOF() && $s(this.char()); )
        this.bump();
    }, t.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var e = this.char(), n = this.offset(), i = this.message.charCodeAt(n + (e >= 65536 ? 2 : 1));
      return i ?? null;
    }, t;
  }()
);
function jo(t) {
  return t >= 97 && t <= 122 || t >= 65 && t <= 90;
}
function kf(t) {
  return jo(t) || t === 47;
}
function Ef(t) {
  return t === 45 || t === 46 || t >= 48 && t <= 57 || t === 95 || t >= 97 && t <= 122 || t >= 65 && t <= 90 || t == 183 || t >= 192 && t <= 214 || t >= 216 && t <= 246 || t >= 248 && t <= 893 || t >= 895 && t <= 8191 || t >= 8204 && t <= 8205 || t >= 8255 && t <= 8256 || t >= 8304 && t <= 8591 || t >= 11264 && t <= 12271 || t >= 12289 && t <= 55295 || t >= 63744 && t <= 64975 || t >= 65008 && t <= 65533 || t >= 65536 && t <= 983039;
}
function $s(t) {
  return t >= 9 && t <= 13 || t === 32 || t === 133 || t >= 8206 && t <= 8207 || t === 8232 || t === 8233;
}
function Sf(t) {
  return t >= 33 && t <= 35 || t === 36 || t >= 37 && t <= 39 || t === 40 || t === 41 || t === 42 || t === 43 || t === 44 || t === 45 || t >= 46 && t <= 47 || t >= 58 && t <= 59 || t >= 60 && t <= 62 || t >= 63 && t <= 64 || t === 91 || t === 92 || t === 93 || t === 94 || t === 96 || t === 123 || t === 124 || t === 125 || t === 126 || t === 161 || t >= 162 && t <= 165 || t === 166 || t === 167 || t === 169 || t === 171 || t === 172 || t === 174 || t === 176 || t === 177 || t === 182 || t === 187 || t === 191 || t === 215 || t === 247 || t >= 8208 && t <= 8213 || t >= 8214 && t <= 8215 || t === 8216 || t === 8217 || t === 8218 || t >= 8219 && t <= 8220 || t === 8221 || t === 8222 || t === 8223 || t >= 8224 && t <= 8231 || t >= 8240 && t <= 8248 || t === 8249 || t === 8250 || t >= 8251 && t <= 8254 || t >= 8257 && t <= 8259 || t === 8260 || t === 8261 || t === 8262 || t >= 8263 && t <= 8273 || t === 8274 || t === 8275 || t >= 8277 && t <= 8286 || t >= 8592 && t <= 8596 || t >= 8597 && t <= 8601 || t >= 8602 && t <= 8603 || t >= 8604 && t <= 8607 || t === 8608 || t >= 8609 && t <= 8610 || t === 8611 || t >= 8612 && t <= 8613 || t === 8614 || t >= 8615 && t <= 8621 || t === 8622 || t >= 8623 && t <= 8653 || t >= 8654 && t <= 8655 || t >= 8656 && t <= 8657 || t === 8658 || t === 8659 || t === 8660 || t >= 8661 && t <= 8691 || t >= 8692 && t <= 8959 || t >= 8960 && t <= 8967 || t === 8968 || t === 8969 || t === 8970 || t === 8971 || t >= 8972 && t <= 8991 || t >= 8992 && t <= 8993 || t >= 8994 && t <= 9e3 || t === 9001 || t === 9002 || t >= 9003 && t <= 9083 || t === 9084 || t >= 9085 && t <= 9114 || t >= 9115 && t <= 9139 || t >= 9140 && t <= 9179 || t >= 9180 && t <= 9185 || t >= 9186 && t <= 9254 || t >= 9255 && t <= 9279 || t >= 9280 && t <= 9290 || t >= 9291 && t <= 9311 || t >= 9472 && t <= 9654 || t === 9655 || t >= 9656 && t <= 9664 || t === 9665 || t >= 9666 && t <= 9719 || t >= 9720 && t <= 9727 || t >= 9728 && t <= 9838 || t === 9839 || t >= 9840 && t <= 10087 || t === 10088 || t === 10089 || t === 10090 || t === 10091 || t === 10092 || t === 10093 || t === 10094 || t === 10095 || t === 10096 || t === 10097 || t === 10098 || t === 10099 || t === 10100 || t === 10101 || t >= 10132 && t <= 10175 || t >= 10176 && t <= 10180 || t === 10181 || t === 10182 || t >= 10183 && t <= 10213 || t === 10214 || t === 10215 || t === 10216 || t === 10217 || t === 10218 || t === 10219 || t === 10220 || t === 10221 || t === 10222 || t === 10223 || t >= 10224 && t <= 10239 || t >= 10240 && t <= 10495 || t >= 10496 && t <= 10626 || t === 10627 || t === 10628 || t === 10629 || t === 10630 || t === 10631 || t === 10632 || t === 10633 || t === 10634 || t === 10635 || t === 10636 || t === 10637 || t === 10638 || t === 10639 || t === 10640 || t === 10641 || t === 10642 || t === 10643 || t === 10644 || t === 10645 || t === 10646 || t === 10647 || t === 10648 || t >= 10649 && t <= 10711 || t === 10712 || t === 10713 || t === 10714 || t === 10715 || t >= 10716 && t <= 10747 || t === 10748 || t === 10749 || t >= 10750 && t <= 11007 || t >= 11008 && t <= 11055 || t >= 11056 && t <= 11076 || t >= 11077 && t <= 11078 || t >= 11079 && t <= 11084 || t >= 11085 && t <= 11123 || t >= 11124 && t <= 11125 || t >= 11126 && t <= 11157 || t === 11158 || t >= 11159 && t <= 11263 || t >= 11776 && t <= 11777 || t === 11778 || t === 11779 || t === 11780 || t === 11781 || t >= 11782 && t <= 11784 || t === 11785 || t === 11786 || t === 11787 || t === 11788 || t === 11789 || t >= 11790 && t <= 11798 || t === 11799 || t >= 11800 && t <= 11801 || t === 11802 || t === 11803 || t === 11804 || t === 11805 || t >= 11806 && t <= 11807 || t === 11808 || t === 11809 || t === 11810 || t === 11811 || t === 11812 || t === 11813 || t === 11814 || t === 11815 || t === 11816 || t === 11817 || t >= 11818 && t <= 11822 || t === 11823 || t >= 11824 && t <= 11833 || t >= 11834 && t <= 11835 || t >= 11836 && t <= 11839 || t === 11840 || t === 11841 || t === 11842 || t >= 11843 && t <= 11855 || t >= 11856 && t <= 11857 || t === 11858 || t >= 11859 && t <= 11903 || t >= 12289 && t <= 12291 || t === 12296 || t === 12297 || t === 12298 || t === 12299 || t === 12300 || t === 12301 || t === 12302 || t === 12303 || t === 12304 || t === 12305 || t >= 12306 && t <= 12307 || t === 12308 || t === 12309 || t === 12310 || t === 12311 || t === 12312 || t === 12313 || t === 12314 || t === 12315 || t === 12316 || t === 12317 || t >= 12318 && t <= 12319 || t === 12320 || t === 12336 || t === 64830 || t === 64831 || t >= 65093 && t <= 65094;
}
function Mo(t) {
  t.forEach(function(e) {
    if (delete e.location, Gs(e) || Vs(e))
      for (var n in e.options)
        delete e.options[n].location, Mo(e.options[n].value);
    else
      Us(e) && Xs(e.style) || (qs(e) || Fs(e)) && Po(e.style) ? delete e.style.location : zs(e) && Mo(e.children);
  });
}
function Tf(t, e) {
  e === void 0 && (e = {}), e = W({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, e);
  var n = new yf(t, e).parse();
  if (n.err) {
    var i = SyntaxError(U[n.err.kind]);
    throw i.location = n.err.location, i.originalMessage = n.err.message, i;
  }
  return e != null && e.captureLocation || Mo(n.val), n.val;
}
function Dl(t, e) {
  var n = e && e.cache ? e.cache : If, i = e && e.serializer ? e.serializer : Nf, l = e && e.strategy ? e.strategy : Af;
  return l(t, {
    cache: n,
    serializer: i
  });
}
function Cf(t) {
  return t == null || typeof t == "number" || typeof t == "boolean";
}
function eu(t, e, n, i) {
  var l = Cf(i) ? i : n(i), o = e.get(l);
  return typeof o > "u" && (o = t.call(this, i), e.set(l, o)), o;
}
function tu(t, e, n) {
  var i = Array.prototype.slice.call(arguments, 3), l = n(i), o = e.get(l);
  return typeof o > "u" && (o = t.apply(this, i), e.set(l, o)), o;
}
function rr(t, e, n, i, l) {
  return n.bind(e, t, i, l);
}
function Af(t, e) {
  var n = t.length === 1 ? eu : tu;
  return rr(t, this, n, e.cache.create(), e.serializer);
}
function Bf(t, e) {
  return rr(t, this, tu, e.cache.create(), e.serializer);
}
function Lf(t, e) {
  return rr(t, this, eu, e.cache.create(), e.serializer);
}
var Nf = function() {
  return JSON.stringify(arguments);
};
function ar() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
ar.prototype.get = function(t) {
  return this.cache[t];
};
ar.prototype.set = function(t, e) {
  this.cache[t] = e;
};
var If = {
  create: function() {
    return new ar();
  }
}, jl = {
  variadic: Bf,
  monadic: Lf
}, Nn;
(function(t) {
  t.MISSING_VALUE = "MISSING_VALUE", t.INVALID_VALUE = "INVALID_VALUE", t.MISSING_INTL_API = "MISSING_INTL_API";
})(Nn || (Nn = {}));
var cl = (
  /** @class */
  function(t) {
    ul(e, t);
    function e(n, i, l) {
      var o = t.call(this, n) || this;
      return o.code = i, o.originalMessage = l, o;
    }
    return e.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, e;
  }(Error)
), Fr = (
  /** @class */
  function(t) {
    ul(e, t);
    function e(n, i, l, o) {
      return t.call(this, 'Invalid values for "'.concat(n, '": "').concat(i, '". Options are "').concat(Object.keys(l).join('", "'), '"'), Nn.INVALID_VALUE, o) || this;
    }
    return e;
  }(cl)
), Hf = (
  /** @class */
  function(t) {
    ul(e, t);
    function e(n, i, l) {
      return t.call(this, 'Value for "'.concat(n, '" must be of type ').concat(i), Nn.INVALID_VALUE, l) || this;
    }
    return e;
  }(cl)
), Pf = (
  /** @class */
  function(t) {
    ul(e, t);
    function e(n, i) {
      return t.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(i, '"'), Nn.MISSING_VALUE, i) || this;
    }
    return e;
  }(cl)
), Ae;
(function(t) {
  t[t.literal = 0] = "literal", t[t.object = 1] = "object";
})(Ae || (Ae = {}));
function Rf(t) {
  return t.length < 2 ? t : t.reduce(function(e, n) {
    var i = e[e.length - 1];
    return !i || i.type !== Ae.literal || n.type !== Ae.literal ? e.push(n) : i.value += n.value, e;
  }, []);
}
function Of(t) {
  return typeof t == "function";
}
function Di(t, e, n, i, l, o, r) {
  if (t.length === 1 && Or(t[0]))
    return [
      {
        type: Ae.literal,
        value: t[0].value
      }
    ];
  for (var s = [], a = 0, u = t; a < u.length; a++) {
    var c = u[a];
    if (Or(c)) {
      s.push({
        type: Ae.literal,
        value: c.value
      });
      continue;
    }
    if (Qc(c)) {
      typeof o == "number" && s.push({
        type: Ae.literal,
        value: n.getNumberFormat(e).format(o)
      });
      continue;
    }
    var f = c.value;
    if (!(l && f in l))
      throw new Pf(f, r);
    var d = l[f];
    if (Jc(c)) {
      (!d || typeof d == "string" || typeof d == "number") && (d = typeof d == "string" || typeof d == "number" ? String(d) : ""), s.push({
        type: typeof d == "string" ? Ae.literal : Ae.object,
        value: d
      });
      continue;
    }
    if (qs(c)) {
      var _ = typeof c.style == "string" ? i.date[c.style] : Po(c.style) ? c.style.parsedOptions : void 0;
      s.push({
        type: Ae.literal,
        value: n.getDateTimeFormat(e, _).format(d)
      });
      continue;
    }
    if (Fs(c)) {
      var _ = typeof c.style == "string" ? i.time[c.style] : Po(c.style) ? c.style.parsedOptions : i.time.medium;
      s.push({
        type: Ae.literal,
        value: n.getDateTimeFormat(e, _).format(d)
      });
      continue;
    }
    if (Us(c)) {
      var _ = typeof c.style == "string" ? i.number[c.style] : Xs(c.style) ? c.style.parsedOptions : void 0;
      _ && _.scale && (d = d * (_.scale || 1)), s.push({
        type: Ae.literal,
        value: n.getNumberFormat(e, _).format(d)
      });
      continue;
    }
    if (zs(c)) {
      var m = c.children, h = c.value, p = l[h];
      if (!Of(p))
        throw new Hf(h, "function", r);
      var v = Di(m, e, n, i, l, o), y = p(v.map(function(k) {
        return k.value;
      }));
      Array.isArray(y) || (y = [y]), s.push.apply(s, y.map(function(k) {
        return {
          type: typeof k == "string" ? Ae.literal : Ae.object,
          value: k
        };
      }));
    }
    if (Gs(c)) {
      var w = c.options[d] || c.options.other;
      if (!w)
        throw new Fr(c.value, d, Object.keys(c.options), r);
      s.push.apply(s, Di(w.value, e, n, i, l));
      continue;
    }
    if (Vs(c)) {
      var w = c.options["=".concat(d)];
      if (!w) {
        if (!Intl.PluralRules)
          throw new cl(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, Nn.MISSING_INTL_API, r);
        var B = n.getPluralRules(e, { type: c.pluralType }).select(d - (c.offset || 0));
        w = c.options[B] || c.options.other;
      }
      if (!w)
        throw new Fr(c.value, d, Object.keys(c.options), r);
      s.push.apply(s, Di(w.value, e, n, i, l, d - (c.offset || 0)));
      continue;
    }
  }
  return Rf(s);
}
function Df(t, e) {
  return e ? W(W(W({}, t || {}), e || {}), Object.keys(t).reduce(function(n, i) {
    return n[i] = W(W({}, t[i]), e[i] || {}), n;
  }, {})) : t;
}
function jf(t, e) {
  return e ? Object.keys(t).reduce(function(n, i) {
    return n[i] = Df(t[i], e[i]), n;
  }, W({}, t)) : t;
}
function Ml(t) {
  return {
    create: function() {
      return {
        get: function(e) {
          return t[e];
        },
        set: function(e, n) {
          t[e] = n;
        }
      };
    }
  };
}
function Mf(t) {
  return t === void 0 && (t = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: Dl(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.NumberFormat).bind.apply(e, Rl([void 0], n, !1)))();
    }, {
      cache: Ml(t.number),
      strategy: jl.variadic
    }),
    getDateTimeFormat: Dl(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.DateTimeFormat).bind.apply(e, Rl([void 0], n, !1)))();
    }, {
      cache: Ml(t.dateTime),
      strategy: jl.variadic
    }),
    getPluralRules: Dl(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.PluralRules).bind.apply(e, Rl([void 0], n, !1)))();
    }, {
      cache: Ml(t.pluralRules),
      strategy: jl.variadic
    })
  };
}
var xf = (
  /** @class */
  function() {
    function t(e, n, i, l) {
      var o = this;
      if (n === void 0 && (n = t.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(r) {
        var s = o.formatToParts(r);
        if (s.length === 1)
          return s[0].value;
        var a = s.reduce(function(u, c) {
          return !u.length || c.type !== Ae.literal || typeof u[u.length - 1] != "string" ? u.push(c.value) : u[u.length - 1] += c.value, u;
        }, []);
        return a.length <= 1 ? a[0] || "" : a;
      }, this.formatToParts = function(r) {
        return Di(o.ast, o.locales, o.formatters, o.formats, r, void 0, o.message);
      }, this.resolvedOptions = function() {
        return {
          locale: o.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return o.ast;
      }, this.locales = n, this.resolvedLocale = t.resolveLocale(n), typeof e == "string") {
        if (this.message = e, !t.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = t.__parse(e, {
          ignoreTag: l == null ? void 0 : l.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = e;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = jf(t.formats, i), this.formatters = l && l.formatters || Mf(this.formatterCache);
    }
    return Object.defineProperty(t, "defaultLocale", {
      get: function() {
        return t.memoizedDefaultLocale || (t.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), t.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), t.memoizedDefaultLocale = null, t.resolveLocale = function(e) {
      var n = Intl.NumberFormat.supportedLocalesOf(e);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
    }, t.__parse = Tf, t.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, t;
  }()
);
function Uf(t, e) {
  if (e == null)
    return;
  if (e in t)
    return t[e];
  const n = e.split(".");
  let i = t;
  for (let l = 0; l < n.length; l++)
    if (typeof i == "object") {
      if (l > 0) {
        const o = n.slice(l, n.length).join(".");
        if (o in i) {
          i = i[o];
          break;
        }
      }
      i = i[n[l]];
    } else
      i = void 0;
  return i;
}
const Dt = {}, qf = (t, e, n) => n && (e in Dt || (Dt[e] = {}), t in Dt[e] || (Dt[e][t] = n), n), nu = (t, e) => {
  if (e == null)
    return;
  if (e in Dt && t in Dt[e])
    return Dt[e][t];
  const n = fl(e);
  for (let i = 0; i < n.length; i++) {
    const l = n[i], o = Gf(l, t);
    if (o)
      return qf(t, e, o);
  }
};
let sr;
const pi = hi({});
function Ff(t) {
  return sr[t] || null;
}
function iu(t) {
  return t in sr;
}
function Gf(t, e) {
  if (!iu(t))
    return null;
  const n = Ff(t);
  return Uf(n, e);
}
function Vf(t) {
  if (t == null)
    return;
  const e = fl(t);
  for (let n = 0; n < e.length; n++) {
    const i = e[n];
    if (iu(i))
      return i;
  }
}
function zf(t, ...e) {
  delete Dt[t], pi.update((n) => (n[t] = Zc.all([n[t] || {}, ...e]), n));
}
Un(
  [pi],
  ([t]) => Object.keys(t)
);
pi.subscribe((t) => sr = t);
const ji = {};
function Xf(t, e) {
  ji[t].delete(e), ji[t].size === 0 && delete ji[t];
}
function lu(t) {
  return ji[t];
}
function Wf(t) {
  return fl(t).map((e) => {
    const n = lu(e);
    return [e, n ? [...n] : []];
  }).filter(([, e]) => e.length > 0);
}
function xo(t) {
  return t == null ? !1 : fl(t).some(
    (e) => {
      var n;
      return (n = lu(e)) == null ? void 0 : n.size;
    }
  );
}
function Zf(t, e) {
  return Promise.all(
    e.map((i) => (Xf(t, i), i().then((l) => l.default || l)))
  ).then((i) => zf(t, ...i));
}
const Qn = {};
function ou(t) {
  if (!xo(t))
    return t in Qn ? Qn[t] : Promise.resolve();
  const e = Wf(t);
  return Qn[t] = Promise.all(
    e.map(
      ([n, i]) => Zf(n, i)
    )
  ).then(() => {
    if (xo(t))
      return ou(t);
    delete Qn[t];
  }), Qn[t];
}
const Jf = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, Qf = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: Jf,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, Yf = Qf;
function In() {
  return Yf;
}
const xl = hi(!1);
var Kf = Object.defineProperty, $f = Object.defineProperties, ed = Object.getOwnPropertyDescriptors, Gr = Object.getOwnPropertySymbols, td = Object.prototype.hasOwnProperty, nd = Object.prototype.propertyIsEnumerable, Vr = (t, e, n) => e in t ? Kf(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, id = (t, e) => {
  for (var n in e || (e = {}))
    td.call(e, n) && Vr(t, n, e[n]);
  if (Gr)
    for (var n of Gr(e))
      nd.call(e, n) && Vr(t, n, e[n]);
  return t;
}, ld = (t, e) => $f(t, ed(e));
let Uo;
const Zi = hi(null);
function zr(t) {
  return t.split("-").map((e, n, i) => i.slice(0, n + 1).join("-")).reverse();
}
function fl(t, e = In().fallbackLocale) {
  const n = zr(t);
  return e ? [.../* @__PURE__ */ new Set([...n, ...zr(e)])] : n;
}
function un() {
  return Uo ?? void 0;
}
Zi.subscribe((t) => {
  Uo = t ?? void 0, typeof window < "u" && t != null && document.documentElement.setAttribute("lang", t);
});
const od = (t) => {
  if (t && Vf(t) && xo(t)) {
    const { loadingDelay: e } = In();
    let n;
    return typeof window < "u" && un() != null && e ? n = window.setTimeout(
      () => xl.set(!0),
      e
    ) : xl.set(!0), ou(t).then(() => {
      Zi.set(t);
    }).finally(() => {
      clearTimeout(n), xl.set(!1);
    });
  }
  return Zi.set(t);
}, gi = ld(id({}, Zi), {
  set: od
}), dl = (t) => {
  const e = /* @__PURE__ */ Object.create(null);
  return (i) => {
    const l = JSON.stringify(i);
    return l in e ? e[l] : e[l] = t(i);
  };
};
var rd = Object.defineProperty, Ji = Object.getOwnPropertySymbols, ru = Object.prototype.hasOwnProperty, au = Object.prototype.propertyIsEnumerable, Xr = (t, e, n) => e in t ? rd(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, ur = (t, e) => {
  for (var n in e || (e = {}))
    ru.call(e, n) && Xr(t, n, e[n]);
  if (Ji)
    for (var n of Ji(e))
      au.call(e, n) && Xr(t, n, e[n]);
  return t;
}, qn = (t, e) => {
  var n = {};
  for (var i in t)
    ru.call(t, i) && e.indexOf(i) < 0 && (n[i] = t[i]);
  if (t != null && Ji)
    for (var i of Ji(t))
      e.indexOf(i) < 0 && au.call(t, i) && (n[i] = t[i]);
  return n;
};
const di = (t, e) => {
  const { formats: n } = In();
  if (t in n && e in n[t])
    return n[t][e];
  throw new Error(`[svelte-i18n] Unknown "${e}" ${t} format.`);
}, ad = dl(
  (t) => {
    var e = t, { locale: n, format: i } = e, l = qn(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return i && (l = di("number", i)), new Intl.NumberFormat(n, l);
  }
), sd = dl(
  (t) => {
    var e = t, { locale: n, format: i } = e, l = qn(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return i ? l = di("date", i) : Object.keys(l).length === 0 && (l = di("date", "short")), new Intl.DateTimeFormat(n, l);
  }
), ud = dl(
  (t) => {
    var e = t, { locale: n, format: i } = e, l = qn(e, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return i ? l = di("time", i) : Object.keys(l).length === 0 && (l = di("time", "short")), new Intl.DateTimeFormat(n, l);
  }
), cd = (t = {}) => {
  var e = t, {
    locale: n = un()
  } = e, i = qn(e, [
    "locale"
  ]);
  return ad(ur({ locale: n }, i));
}, fd = (t = {}) => {
  var e = t, {
    locale: n = un()
  } = e, i = qn(e, [
    "locale"
  ]);
  return sd(ur({ locale: n }, i));
}, dd = (t = {}) => {
  var e = t, {
    locale: n = un()
  } = e, i = qn(e, [
    "locale"
  ]);
  return ud(ur({ locale: n }, i));
}, _d = dl(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (t, e = un()) => new xf(t, e, In().formats, {
    ignoreTag: In().ignoreTag
  })
), md = (t, e = {}) => {
  var n, i, l, o;
  let r = e;
  typeof t == "object" && (r = t, t = r.id);
  const {
    values: s,
    locale: a = un(),
    default: u
  } = r;
  if (a == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let c = nu(t, a);
  if (!c)
    c = (o = (l = (i = (n = In()).handleMissingMessage) == null ? void 0 : i.call(n, { locale: a, id: t, defaultValue: u })) != null ? l : u) != null ? o : t;
  else if (typeof c != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${t}" must be of type "string", found: "${typeof c}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), c;
  if (!s)
    return c;
  let f = c;
  try {
    f = _d(c, a).format(s);
  } catch (d) {
    d instanceof Error && console.warn(
      `[svelte-i18n] Message "${t}" has syntax error:`,
      d.message
    );
  }
  return f;
}, hd = (t, e) => dd(e).format(t), pd = (t, e) => fd(e).format(t), gd = (t, e) => cd(e).format(t), bd = (t, e = un()) => nu(t, e);
Un([gi, pi], () => md);
Un([gi], () => hd);
Un([gi], () => pd);
Un([gi], () => gd);
Un([gi, pi], () => bd);
const {
  SvelteComponent: vd,
  append: qe,
  attr: Zt,
  detach: su,
  element: Jt,
  init: wd,
  insert: uu,
  noop: Wr,
  safe_not_equal: yd,
  set_data: Qi,
  set_style: Ul,
  space: qo,
  text: En,
  toggle_class: Zr
} = window.__gradio__svelte__internal, { onMount: kd, createEventDispatcher: Ed, getContext: Sd } = window.__gradio__svelte__internal;
function Jr(t) {
  let e, n, i, l, o = ti(
    /*file_to_display*/
    t[2]
  ) + "", r, s, a, u, c = (
    /*file_to_display*/
    t[2].orig_name + ""
  ), f;
  return {
    c() {
      e = Jt("div"), n = Jt("span"), i = Jt("div"), l = Jt("progress"), r = En(o), a = qo(), u = Jt("span"), f = En(c), Ul(l, "visibility", "hidden"), Ul(l, "height", "0"), Ul(l, "width", "0"), l.value = s = ti(
        /*file_to_display*/
        t[2]
      ), Zt(l, "max", "100"), Zt(l, "class", "svelte-cr2edf"), Zt(i, "class", "progress-bar svelte-cr2edf"), Zt(u, "class", "file-name svelte-cr2edf"), Zt(e, "class", "file svelte-cr2edf");
    },
    m(d, _) {
      uu(d, e, _), qe(e, n), qe(n, i), qe(i, l), qe(l, r), qe(e, a), qe(e, u), qe(u, f);
    },
    p(d, _) {
      _ & /*file_to_display*/
      4 && o !== (o = ti(
        /*file_to_display*/
        d[2]
      ) + "") && Qi(r, o), _ & /*file_to_display*/
      4 && s !== (s = ti(
        /*file_to_display*/
        d[2]
      )) && (l.value = s), _ & /*file_to_display*/
      4 && c !== (c = /*file_to_display*/
      d[2].orig_name + "") && Qi(f, c);
    },
    d(d) {
      d && su(e);
    }
  };
}
function Td(t) {
  let e, n, i, l = (
    /*files_with_progress*/
    t[0].length + ""
  ), o, r, s = (
    /*files_with_progress*/
    t[0].length > 1 ? "files" : "file"
  ), a, u, c, f = (
    /*file_to_display*/
    t[2] && Jr(t)
  );
  return {
    c() {
      e = Jt("div"), n = Jt("span"), i = En("Uploading "), o = En(l), r = qo(), a = En(s), u = En("..."), c = qo(), f && f.c(), Zt(n, "class", "uploading svelte-cr2edf"), Zt(e, "class", "wrap svelte-cr2edf"), Zr(
        e,
        "progress",
        /*progress*/
        t[1]
      );
    },
    m(d, _) {
      uu(d, e, _), qe(e, n), qe(n, i), qe(n, o), qe(n, r), qe(n, a), qe(n, u), qe(e, c), f && f.m(e, null);
    },
    p(d, [_]) {
      _ & /*files_with_progress*/
      1 && l !== (l = /*files_with_progress*/
      d[0].length + "") && Qi(o, l), _ & /*files_with_progress*/
      1 && s !== (s = /*files_with_progress*/
      d[0].length > 1 ? "files" : "file") && Qi(a, s), /*file_to_display*/
      d[2] ? f ? f.p(d, _) : (f = Jr(d), f.c(), f.m(e, null)) : f && (f.d(1), f = null), _ & /*progress*/
      2 && Zr(
        e,
        "progress",
        /*progress*/
        d[1]
      );
    },
    i: Wr,
    o: Wr,
    d(d) {
      d && su(e), f && f.d();
    }
  };
}
function ti(t) {
  return t.progress * 100 / (t.size || 0) || 0;
}
function Cd(t) {
  let e = 0;
  return t.forEach((n) => {
    e += ti(n);
  }), document.documentElement.style.setProperty("--upload-progress-width", (e / t.length).toFixed(2) + "%"), e / t.length;
}
function Ad(t, e, n) {
  let { upload_id: i } = e, { root: l } = e, { files: o } = e, r, s = !1, a, u, c = o.map((m) => ({ ...m, progress: 0 }));
  const f = Ed();
  function d(m, h) {
    n(0, c = c.map((p) => (p.orig_name === m && (p.progress += h), p)));
  }
  const _ = Sd("EventSource_factory");
  return kd(() => {
    r = _(new URL(`${l}/upload_progress?upload_id=${i}`)), r.onmessage = async function(m) {
      const h = JSON.parse(m.data);
      s || n(1, s = !0), h.msg === "done" ? (r.close(), f("done")) : (n(6, a = h), d(h.orig_name, h.chunk_size));
    };
  }), t.$$set = (m) => {
    "upload_id" in m && n(3, i = m.upload_id), "root" in m && n(4, l = m.root), "files" in m && n(5, o = m.files);
  }, t.$$.update = () => {
    t.$$.dirty & /*files_with_progress*/
    1 && Cd(c), t.$$.dirty & /*current_file_upload, files_with_progress*/
    65 && n(2, u = a || c[0]);
  }, [
    c,
    s,
    u,
    i,
    l,
    o,
    a
  ];
}
class Bd extends vd {
  constructor(e) {
    super(), wd(this, e, Ad, Td, yd, { upload_id: 3, root: 4, files: 5 });
  }
}
const {
  SvelteComponent: Ld,
  append: Qr,
  attr: Te,
  binding_callbacks: Nd,
  bubble: Gt,
  check_outros: cu,
  create_component: Id,
  create_slot: fu,
  destroy_component: Hd,
  detach: _l,
  element: Fo,
  empty: du,
  get_all_dirty_from_scope: _u,
  get_slot_changes: mu,
  group_outros: hu,
  init: Pd,
  insert: ml,
  listen: We,
  mount_component: Rd,
  prevent_default: Vt,
  run_all: Od,
  safe_not_equal: Dd,
  set_style: pu,
  space: jd,
  stop_propagation: zt,
  toggle_class: me,
  transition_in: Mt,
  transition_out: nn,
  update_slot_base: gu
} = window.__gradio__svelte__internal, { createEventDispatcher: Md, tick: xd, getContext: Ud } = window.__gradio__svelte__internal;
function qd(t) {
  let e, n, i, l, o, r, s, a, u, c, f;
  const d = (
    /*#slots*/
    t[22].default
  ), _ = fu(
    d,
    t,
    /*$$scope*/
    t[21],
    null
  );
  return {
    c() {
      e = Fo("button"), _ && _.c(), n = jd(), i = Fo("input"), Te(i, "aria-label", "file upload"), Te(i, "data-testid", "file-upload"), Te(i, "type", "file"), Te(i, "accept", l = /*accept_file_types*/
      t[14] || void 0), i.multiple = o = /*file_count*/
      t[6] === "multiple" || void 0, Te(i, "webkitdirectory", r = /*file_count*/
      t[6] === "directory" || void 0), Te(i, "mozdirectory", s = /*file_count*/
      t[6] === "directory" || void 0), Te(i, "class", "svelte-1s26xmt"), Te(e, "tabindex", a = /*hidden*/
      t[9] ? -1 : 0), Te(e, "class", "svelte-1s26xmt"), me(
        e,
        "hidden",
        /*hidden*/
        t[9]
      ), me(
        e,
        "center",
        /*center*/
        t[4]
      ), me(
        e,
        "boundedheight",
        /*boundedheight*/
        t[3]
      ), me(
        e,
        "flex",
        /*flex*/
        t[5]
      ), me(
        e,
        "disable_click",
        /*disable_click*/
        t[7]
      ), pu(e, "height", "100%");
    },
    m(m, h) {
      ml(m, e, h), _ && _.m(e, null), Qr(e, n), Qr(e, i), t[30](i), u = !0, c || (f = [
        We(
          i,
          "change",
          /*load_files_from_upload*/
          t[16]
        ),
        We(e, "drag", zt(Vt(
          /*drag_handler*/
          t[23]
        ))),
        We(e, "dragstart", zt(Vt(
          /*dragstart_handler*/
          t[24]
        ))),
        We(e, "dragend", zt(Vt(
          /*dragend_handler*/
          t[25]
        ))),
        We(e, "dragover", zt(Vt(
          /*dragover_handler*/
          t[26]
        ))),
        We(e, "dragenter", zt(Vt(
          /*dragenter_handler*/
          t[27]
        ))),
        We(e, "dragleave", zt(Vt(
          /*dragleave_handler*/
          t[28]
        ))),
        We(e, "drop", zt(Vt(
          /*drop_handler*/
          t[29]
        ))),
        We(
          e,
          "click",
          /*open_file_upload*/
          t[11]
        ),
        We(
          e,
          "drop",
          /*loadFilesFromDrop*/
          t[17]
        ),
        We(
          e,
          "dragenter",
          /*updateDragging*/
          t[15]
        ),
        We(
          e,
          "dragleave",
          /*updateDragging*/
          t[15]
        )
      ], c = !0);
    },
    p(m, h) {
      _ && _.p && (!u || h[0] & /*$$scope*/
      2097152) && gu(
        _,
        d,
        m,
        /*$$scope*/
        m[21],
        u ? mu(
          d,
          /*$$scope*/
          m[21],
          h,
          null
        ) : _u(
          /*$$scope*/
          m[21]
        ),
        null
      ), (!u || h[0] & /*accept_file_types*/
      16384 && l !== (l = /*accept_file_types*/
      m[14] || void 0)) && Te(i, "accept", l), (!u || h[0] & /*file_count*/
      64 && o !== (o = /*file_count*/
      m[6] === "multiple" || void 0)) && (i.multiple = o), (!u || h[0] & /*file_count*/
      64 && r !== (r = /*file_count*/
      m[6] === "directory" || void 0)) && Te(i, "webkitdirectory", r), (!u || h[0] & /*file_count*/
      64 && s !== (s = /*file_count*/
      m[6] === "directory" || void 0)) && Te(i, "mozdirectory", s), (!u || h[0] & /*hidden*/
      512 && a !== (a = /*hidden*/
      m[9] ? -1 : 0)) && Te(e, "tabindex", a), (!u || h[0] & /*hidden*/
      512) && me(
        e,
        "hidden",
        /*hidden*/
        m[9]
      ), (!u || h[0] & /*center*/
      16) && me(
        e,
        "center",
        /*center*/
        m[4]
      ), (!u || h[0] & /*boundedheight*/
      8) && me(
        e,
        "boundedheight",
        /*boundedheight*/
        m[3]
      ), (!u || h[0] & /*flex*/
      32) && me(
        e,
        "flex",
        /*flex*/
        m[5]
      ), (!u || h[0] & /*disable_click*/
      128) && me(
        e,
        "disable_click",
        /*disable_click*/
        m[7]
      );
    },
    i(m) {
      u || (Mt(_, m), u = !0);
    },
    o(m) {
      nn(_, m), u = !1;
    },
    d(m) {
      m && _l(e), _ && _.d(m), t[30](null), c = !1, Od(f);
    }
  };
}
function Fd(t) {
  let e, n, i = !/*hidden*/
  t[9] && Yr(t);
  return {
    c() {
      i && i.c(), e = du();
    },
    m(l, o) {
      i && i.m(l, o), ml(l, e, o), n = !0;
    },
    p(l, o) {
      /*hidden*/
      l[9] ? i && (hu(), nn(i, 1, 1, () => {
        i = null;
      }), cu()) : i ? (i.p(l, o), o[0] & /*hidden*/
      512 && Mt(i, 1)) : (i = Yr(l), i.c(), Mt(i, 1), i.m(e.parentNode, e));
    },
    i(l) {
      n || (Mt(i), n = !0);
    },
    o(l) {
      nn(i), n = !1;
    },
    d(l) {
      l && _l(e), i && i.d(l);
    }
  };
}
function Gd(t) {
  let e, n, i, l, o;
  const r = (
    /*#slots*/
    t[22].default
  ), s = fu(
    r,
    t,
    /*$$scope*/
    t[21],
    null
  );
  return {
    c() {
      e = Fo("button"), s && s.c(), Te(e, "tabindex", n = /*hidden*/
      t[9] ? -1 : 0), Te(e, "class", "svelte-1s26xmt"), me(
        e,
        "hidden",
        /*hidden*/
        t[9]
      ), me(
        e,
        "center",
        /*center*/
        t[4]
      ), me(
        e,
        "boundedheight",
        /*boundedheight*/
        t[3]
      ), me(
        e,
        "flex",
        /*flex*/
        t[5]
      ), pu(e, "height", "100%");
    },
    m(a, u) {
      ml(a, e, u), s && s.m(e, null), i = !0, l || (o = We(
        e,
        "click",
        /*paste_clipboard*/
        t[10]
      ), l = !0);
    },
    p(a, u) {
      s && s.p && (!i || u[0] & /*$$scope*/
      2097152) && gu(
        s,
        r,
        a,
        /*$$scope*/
        a[21],
        i ? mu(
          r,
          /*$$scope*/
          a[21],
          u,
          null
        ) : _u(
          /*$$scope*/
          a[21]
        ),
        null
      ), (!i || u[0] & /*hidden*/
      512 && n !== (n = /*hidden*/
      a[9] ? -1 : 0)) && Te(e, "tabindex", n), (!i || u[0] & /*hidden*/
      512) && me(
        e,
        "hidden",
        /*hidden*/
        a[9]
      ), (!i || u[0] & /*center*/
      16) && me(
        e,
        "center",
        /*center*/
        a[4]
      ), (!i || u[0] & /*boundedheight*/
      8) && me(
        e,
        "boundedheight",
        /*boundedheight*/
        a[3]
      ), (!i || u[0] & /*flex*/
      32) && me(
        e,
        "flex",
        /*flex*/
        a[5]
      );
    },
    i(a) {
      i || (Mt(s, a), i = !0);
    },
    o(a) {
      nn(s, a), i = !1;
    },
    d(a) {
      a && _l(e), s && s.d(a), l = !1, o();
    }
  };
}
function Yr(t) {
  let e, n;
  return e = new Bd({
    props: {
      root: (
        /*root*/
        t[8]
      ),
      upload_id: (
        /*upload_id*/
        t[12]
      ),
      files: (
        /*file_data*/
        t[13]
      )
    }
  }), {
    c() {
      Id(e.$$.fragment);
    },
    m(i, l) {
      Rd(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*root*/
      256 && (o.root = /*root*/
      i[8]), l[0] & /*upload_id*/
      4096 && (o.upload_id = /*upload_id*/
      i[12]), l[0] & /*file_data*/
      8192 && (o.files = /*file_data*/
      i[13]), e.$set(o);
    },
    i(i) {
      n || (Mt(e.$$.fragment, i), n = !0);
    },
    o(i) {
      nn(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Hd(e, i);
    }
  };
}
function Vd(t) {
  let e, n, i, l;
  const o = [Gd, Fd, qd], r = [];
  function s(a, u) {
    return (
      /*filetype*/
      a[0] === "clipboard" ? 0 : (
        /*uploading*/
        a[1] ? 1 : 2
      )
    );
  }
  return e = s(t), n = r[e] = o[e](t), {
    c() {
      n.c(), i = du();
    },
    m(a, u) {
      r[e].m(a, u), ml(a, i, u), l = !0;
    },
    p(a, u) {
      let c = e;
      e = s(a), e === c ? r[e].p(a, u) : (hu(), nn(r[c], 1, 1, () => {
        r[c] = null;
      }), cu(), n = r[e], n ? n.p(a, u) : (n = r[e] = o[e](a), n.c()), Mt(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (Mt(n), l = !0);
    },
    o(a) {
      nn(n), l = !1;
    },
    d(a) {
      a && _l(i), r[e].d(a);
    }
  };
}
function Kr(t) {
  let e, n = t[0], i = 1;
  for (; i < t.length; ) {
    const l = t[i], o = t[i + 1];
    if (i += 2, (l === "optionalAccess" || l === "optionalCall") && n == null)
      return;
    l === "access" || l === "optionalAccess" ? (e = n, n = o(n)) : (l === "call" || l === "optionalCall") && (n = o((...r) => n.call(e, ...r)), e = void 0);
  }
  return n;
}
function zd(t, e, n) {
  if (!t || t === "*" || t === "file/*" || Array.isArray(t) && t.some((l) => l === "*" || l === "file/*"))
    return !0;
  let i;
  if (typeof t == "string")
    i = t.split(",").map((l) => l.trim());
  else if (Array.isArray(t))
    i = t;
  else
    return !1;
  return i.includes(e) || i.some((l) => {
    const [o] = l.split("/").map((r) => r.trim());
    return l.endsWith("/*") && n.startsWith(o + "/");
  });
}
function Xd(t, e, n) {
  let { $$slots: i = {}, $$scope: l } = e, { filetype: o = null } = e, { dragging: r = !1 } = e, { boundedheight: s = !0 } = e, { center: a = !0 } = e, { flex: u = !0 } = e, { file_count: c = "single" } = e, { disable_click: f = !1 } = e, { root: d } = e, { hidden: _ = !1 } = e, { format: m = "file" } = e, { uploading: h = !1 } = e, { hidden_upload: p = null } = e, v, y, w;
  const B = Ud("upload_files"), k = Md(), b = ["image", "video", "audio", "text", "file"], C = (g) => g.startsWith(".") || g.endsWith("/*") ? g : b.includes(g) ? g + "/*" : "." + g;
  function H() {
    n(18, r = !r);
  }
  function R() {
    navigator.clipboard.read().then(async (g) => {
      for (let E = 0; E < g.length; E++) {
        const T = g[E].types.find((I) => I.startsWith("image/"));
        if (T) {
          g[E].getType(T).then(async (I) => {
            const K = new File([I], `clipboard.${T.replace("image/", "")}`);
            await q([K]);
          });
          break;
        }
      }
    });
  }
  function x() {
    f || p && (n(2, p.value = "", p), p.click());
  }
  async function z(g) {
    await xd(), n(12, v = Math.random().toString(36).substring(2, 15)), n(1, h = !0);
    const E = await ir(g, d, v, B);
    return k("load", c === "single" ? Kr([E, "optionalAccess", (T) => T[0]]) : E), n(1, h = !1), E || [];
  }
  async function q(g) {
    if (!g.length)
      return;
    let E = g.map((T) => new File([T], T.name, { type: T.type }));
    return n(13, y = await lr(E)), await z(y);
  }
  async function F(g) {
    const E = g.target;
    if (E.files)
      if (m != "blob")
        await q(Array.from(E.files));
      else {
        if (c === "single") {
          k("load", E.files[0]);
          return;
        }
        k("load", E.files);
      }
  }
  async function re(g) {
    if (n(18, r = !1), !Kr([g, "access", (T) => T.dataTransfer, "optionalAccess", (T) => T.files]))
      return;
    const E = Array.from(g.dataTransfer.files).filter((T) => {
      const I = "." + T.name.split(".").pop();
      return I && zd(w, I, T.type) || (I && Array.isArray(o) ? o.includes(I) : I === o) ? !0 : (k("error", `Invalid file type only ${o} allowed.`), !1);
    });
    await q(E);
  }
  function A(g) {
    Gt.call(this, t, g);
  }
  function ae(g) {
    Gt.call(this, t, g);
  }
  function N(g) {
    Gt.call(this, t, g);
  }
  function S(g) {
    Gt.call(this, t, g);
  }
  function pe(g) {
    Gt.call(this, t, g);
  }
  function P(g) {
    Gt.call(this, t, g);
  }
  function J(g) {
    Gt.call(this, t, g);
  }
  function Z(g) {
    Nd[g ? "unshift" : "push"](() => {
      p = g, n(2, p);
    });
  }
  return t.$$set = (g) => {
    "filetype" in g && n(0, o = g.filetype), "dragging" in g && n(18, r = g.dragging), "boundedheight" in g && n(3, s = g.boundedheight), "center" in g && n(4, a = g.center), "flex" in g && n(5, u = g.flex), "file_count" in g && n(6, c = g.file_count), "disable_click" in g && n(7, f = g.disable_click), "root" in g && n(8, d = g.root), "hidden" in g && n(9, _ = g.hidden), "format" in g && n(19, m = g.format), "uploading" in g && n(1, h = g.uploading), "hidden_upload" in g && n(2, p = g.hidden_upload), "$$scope" in g && n(21, l = g.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*filetype*/
    1 && (o == null ? n(14, w = null) : typeof o == "string" ? n(14, w = C(o)) : (n(0, o = o.map(C)), n(14, w = o.join(", "))));
  }, [
    o,
    h,
    p,
    s,
    a,
    u,
    c,
    f,
    d,
    _,
    R,
    x,
    v,
    y,
    w,
    H,
    F,
    re,
    r,
    m,
    q,
    l,
    i,
    A,
    ae,
    N,
    S,
    pe,
    P,
    J,
    Z
  ];
}
let Wd = class extends Ld {
  constructor(e) {
    super(), Pd(
      this,
      e,
      Xd,
      Vd,
      Dd,
      {
        filetype: 0,
        dragging: 18,
        boundedheight: 3,
        center: 4,
        flex: 5,
        file_count: 6,
        disable_click: 7,
        root: 8,
        hidden: 9,
        format: 19,
        uploading: 1,
        hidden_upload: 2,
        paste_clipboard: 10,
        open_file_upload: 11,
        load_files: 20
      },
      null,
      [-1, -1]
    );
  }
  get paste_clipboard() {
    return this.$$.ctx[10];
  }
  get open_file_upload() {
    return this.$$.ctx[11];
  }
  get load_files() {
    return this.$$.ctx[20];
  }
};
const {
  SvelteComponent: Zd,
  assign: Jd,
  create_slot: Qd,
  detach: Yd,
  element: Kd,
  get_all_dirty_from_scope: $d,
  get_slot_changes: e_,
  get_spread_update: t_,
  init: n_,
  insert: i_,
  safe_not_equal: l_,
  set_dynamic_element_data: $r,
  set_style: ze,
  toggle_class: ut,
  transition_in: bu,
  transition_out: vu,
  update_slot_base: o_
} = window.__gradio__svelte__internal;
function r_(t) {
  let e, n, i;
  const l = (
    /*#slots*/
    t[18].default
  ), o = Qd(
    l,
    t,
    /*$$scope*/
    t[17],
    null
  );
  let r = [
    { "data-testid": (
      /*test_id*/
      t[7]
    ) },
    { id: (
      /*elem_id*/
      t[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      t[3].join(" ") + " svelte-nl1om8"
    }
  ], s = {};
  for (let a = 0; a < r.length; a += 1)
    s = Jd(s, r[a]);
  return {
    c() {
      e = Kd(
        /*tag*/
        t[14]
      ), o && o.c(), $r(
        /*tag*/
        t[14]
      )(e, s), ut(
        e,
        "hidden",
        /*visible*/
        t[10] === !1
      ), ut(
        e,
        "padded",
        /*padding*/
        t[6]
      ), ut(
        e,
        "border_focus",
        /*border_mode*/
        t[5] === "focus"
      ), ut(
        e,
        "border_contrast",
        /*border_mode*/
        t[5] === "contrast"
      ), ut(e, "hide-container", !/*explicit_call*/
      t[8] && !/*container*/
      t[9]), ze(
        e,
        "height",
        /*get_dimension*/
        t[15](
          /*height*/
          t[0]
        )
      ), ze(e, "width", typeof /*width*/
      t[1] == "number" ? `calc(min(${/*width*/
      t[1]}px, 100%))` : (
        /*get_dimension*/
        t[15](
          /*width*/
          t[1]
        )
      )), ze(
        e,
        "border-style",
        /*variant*/
        t[4]
      ), ze(
        e,
        "overflow",
        /*allow_overflow*/
        t[11] ? "visible" : "hidden"
      ), ze(
        e,
        "flex-grow",
        /*scale*/
        t[12]
      ), ze(e, "min-width", `calc(min(${/*min_width*/
      t[13]}px, 100%))`), ze(e, "border-width", "var(--block-border-width)");
    },
    m(a, u) {
      i_(a, e, u), o && o.m(e, null), i = !0;
    },
    p(a, u) {
      o && o.p && (!i || u & /*$$scope*/
      131072) && o_(
        o,
        l,
        a,
        /*$$scope*/
        a[17],
        i ? e_(
          l,
          /*$$scope*/
          a[17],
          u,
          null
        ) : $d(
          /*$$scope*/
          a[17]
        ),
        null
      ), $r(
        /*tag*/
        a[14]
      )(e, s = t_(r, [
        (!i || u & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          a[7]
        ) },
        (!i || u & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          a[2]
        ) },
        (!i || u & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        a[3].join(" ") + " svelte-nl1om8")) && { class: n }
      ])), ut(
        e,
        "hidden",
        /*visible*/
        a[10] === !1
      ), ut(
        e,
        "padded",
        /*padding*/
        a[6]
      ), ut(
        e,
        "border_focus",
        /*border_mode*/
        a[5] === "focus"
      ), ut(
        e,
        "border_contrast",
        /*border_mode*/
        a[5] === "contrast"
      ), ut(e, "hide-container", !/*explicit_call*/
      a[8] && !/*container*/
      a[9]), u & /*height*/
      1 && ze(
        e,
        "height",
        /*get_dimension*/
        a[15](
          /*height*/
          a[0]
        )
      ), u & /*width*/
      2 && ze(e, "width", typeof /*width*/
      a[1] == "number" ? `calc(min(${/*width*/
      a[1]}px, 100%))` : (
        /*get_dimension*/
        a[15](
          /*width*/
          a[1]
        )
      )), u & /*variant*/
      16 && ze(
        e,
        "border-style",
        /*variant*/
        a[4]
      ), u & /*allow_overflow*/
      2048 && ze(
        e,
        "overflow",
        /*allow_overflow*/
        a[11] ? "visible" : "hidden"
      ), u & /*scale*/
      4096 && ze(
        e,
        "flex-grow",
        /*scale*/
        a[12]
      ), u & /*min_width*/
      8192 && ze(e, "min-width", `calc(min(${/*min_width*/
      a[13]}px, 100%))`);
    },
    i(a) {
      i || (bu(o, a), i = !0);
    },
    o(a) {
      vu(o, a), i = !1;
    },
    d(a) {
      a && Yd(e), o && o.d(a);
    }
  };
}
function a_(t) {
  let e, n = (
    /*tag*/
    t[14] && r_(t)
  );
  return {
    c() {
      n && n.c();
    },
    m(i, l) {
      n && n.m(i, l), e = !0;
    },
    p(i, [l]) {
      /*tag*/
      i[14] && n.p(i, l);
    },
    i(i) {
      e || (bu(n, i), e = !0);
    },
    o(i) {
      vu(n, i), e = !1;
    },
    d(i) {
      n && n.d(i);
    }
  };
}
function s_(t, e, n) {
  let { $$slots: i = {}, $$scope: l } = e, { height: o = void 0 } = e, { width: r = void 0 } = e, { elem_id: s = "" } = e, { elem_classes: a = [] } = e, { variant: u = "solid" } = e, { border_mode: c = "base" } = e, { padding: f = !0 } = e, { type: d = "normal" } = e, { test_id: _ = void 0 } = e, { explicit_call: m = !1 } = e, { container: h = !0 } = e, { visible: p = !0 } = e, { allow_overflow: v = !0 } = e, { scale: y = null } = e, { min_width: w = 0 } = e, B = d === "fieldset" ? "fieldset" : "div";
  const k = (b) => {
    if (b !== void 0) {
      if (typeof b == "number")
        return b + "px";
      if (typeof b == "string")
        return b;
    }
  };
  return t.$$set = (b) => {
    "height" in b && n(0, o = b.height), "width" in b && n(1, r = b.width), "elem_id" in b && n(2, s = b.elem_id), "elem_classes" in b && n(3, a = b.elem_classes), "variant" in b && n(4, u = b.variant), "border_mode" in b && n(5, c = b.border_mode), "padding" in b && n(6, f = b.padding), "type" in b && n(16, d = b.type), "test_id" in b && n(7, _ = b.test_id), "explicit_call" in b && n(8, m = b.explicit_call), "container" in b && n(9, h = b.container), "visible" in b && n(10, p = b.visible), "allow_overflow" in b && n(11, v = b.allow_overflow), "scale" in b && n(12, y = b.scale), "min_width" in b && n(13, w = b.min_width), "$$scope" in b && n(17, l = b.$$scope);
  }, [
    o,
    r,
    s,
    a,
    u,
    c,
    f,
    _,
    m,
    h,
    p,
    v,
    y,
    w,
    B,
    k,
    d,
    l,
    i
  ];
}
class wu extends Zd {
  constructor(e) {
    super(), n_(this, e, s_, a_, l_, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: u_,
  append: ql,
  attr: Si,
  create_component: c_,
  destroy_component: f_,
  detach: d_,
  element: ea,
  init: __,
  insert: m_,
  mount_component: h_,
  safe_not_equal: p_,
  set_data: g_,
  space: b_,
  text: v_,
  toggle_class: Nt,
  transition_in: w_,
  transition_out: y_
} = window.__gradio__svelte__internal;
function k_(t) {
  let e, n, i, l, o, r;
  return i = new /*Icon*/
  t[1]({}), {
    c() {
      e = ea("label"), n = ea("span"), c_(i.$$.fragment), l = b_(), o = v_(
        /*label*/
        t[0]
      ), Si(n, "class", "svelte-9gxdi0"), Si(e, "for", ""), Si(e, "data-testid", "block-label"), Si(e, "class", "svelte-9gxdi0"), Nt(e, "hide", !/*show_label*/
      t[2]), Nt(e, "sr-only", !/*show_label*/
      t[2]), Nt(
        e,
        "float",
        /*float*/
        t[4]
      ), Nt(
        e,
        "hide-label",
        /*disable*/
        t[3]
      );
    },
    m(s, a) {
      m_(s, e, a), ql(e, n), h_(i, n, null), ql(e, l), ql(e, o), r = !0;
    },
    p(s, [a]) {
      (!r || a & /*label*/
      1) && g_(
        o,
        /*label*/
        s[0]
      ), (!r || a & /*show_label*/
      4) && Nt(e, "hide", !/*show_label*/
      s[2]), (!r || a & /*show_label*/
      4) && Nt(e, "sr-only", !/*show_label*/
      s[2]), (!r || a & /*float*/
      16) && Nt(
        e,
        "float",
        /*float*/
        s[4]
      ), (!r || a & /*disable*/
      8) && Nt(
        e,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      r || (w_(i.$$.fragment, s), r = !0);
    },
    o(s) {
      y_(i.$$.fragment, s), r = !1;
    },
    d(s) {
      s && d_(e), f_(i);
    }
  };
}
function E_(t, e, n) {
  let { label: i = null } = e, { Icon: l } = e, { show_label: o = !0 } = e, { disable: r = !1 } = e, { float: s = !0 } = e;
  return t.$$set = (a) => {
    "label" in a && n(0, i = a.label), "Icon" in a && n(1, l = a.Icon), "show_label" in a && n(2, o = a.show_label), "disable" in a && n(3, r = a.disable), "float" in a && n(4, s = a.float);
  }, [i, l, o, r, s];
}
class yu extends u_ {
  constructor(e) {
    super(), __(this, e, E_, k_, p_, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: S_,
  append: Go,
  attr: wt,
  bubble: T_,
  create_component: C_,
  destroy_component: A_,
  detach: ku,
  element: Vo,
  init: B_,
  insert: Eu,
  listen: L_,
  mount_component: N_,
  safe_not_equal: I_,
  set_data: H_,
  set_style: Ti,
  space: P_,
  text: R_,
  toggle_class: Qe,
  transition_in: O_,
  transition_out: D_
} = window.__gradio__svelte__internal;
function ta(t) {
  let e, n;
  return {
    c() {
      e = Vo("span"), n = R_(
        /*label*/
        t[1]
      ), wt(e, "class", "svelte-lpi64a");
    },
    m(i, l) {
      Eu(i, e, l), Go(e, n);
    },
    p(i, l) {
      l & /*label*/
      2 && H_(
        n,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && ku(e);
    }
  };
}
function j_(t) {
  let e, n, i, l, o, r, s, a = (
    /*show_label*/
    t[2] && ta(t)
  );
  return l = new /*Icon*/
  t[0]({}), {
    c() {
      e = Vo("button"), a && a.c(), n = P_(), i = Vo("div"), C_(l.$$.fragment), wt(i, "class", "svelte-lpi64a"), Qe(
        i,
        "small",
        /*size*/
        t[4] === "small"
      ), Qe(
        i,
        "large",
        /*size*/
        t[4] === "large"
      ), e.disabled = /*disabled*/
      t[7], wt(
        e,
        "aria-label",
        /*label*/
        t[1]
      ), wt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        t[8]
      ), wt(
        e,
        "title",
        /*label*/
        t[1]
      ), wt(e, "class", "svelte-lpi64a"), Qe(
        e,
        "pending",
        /*pending*/
        t[3]
      ), Qe(
        e,
        "padded",
        /*padded*/
        t[5]
      ), Qe(
        e,
        "highlight",
        /*highlight*/
        t[6]
      ), Qe(
        e,
        "transparent",
        /*transparent*/
        t[9]
      ), Ti(e, "color", !/*disabled*/
      t[7] && /*_color*/
      t[11] ? (
        /*_color*/
        t[11]
      ) : "var(--block-label-text-color)"), Ti(e, "--bg-color", /*disabled*/
      t[7] ? "auto" : (
        /*background*/
        t[10]
      ));
    },
    m(u, c) {
      Eu(u, e, c), a && a.m(e, null), Go(e, n), Go(e, i), N_(l, i, null), o = !0, r || (s = L_(
        e,
        "click",
        /*click_handler*/
        t[13]
      ), r = !0);
    },
    p(u, [c]) {
      /*show_label*/
      u[2] ? a ? a.p(u, c) : (a = ta(u), a.c(), a.m(e, n)) : a && (a.d(1), a = null), (!o || c & /*size*/
      16) && Qe(
        i,
        "small",
        /*size*/
        u[4] === "small"
      ), (!o || c & /*size*/
      16) && Qe(
        i,
        "large",
        /*size*/
        u[4] === "large"
      ), (!o || c & /*disabled*/
      128) && (e.disabled = /*disabled*/
      u[7]), (!o || c & /*label*/
      2) && wt(
        e,
        "aria-label",
        /*label*/
        u[1]
      ), (!o || c & /*hasPopup*/
      256) && wt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        u[8]
      ), (!o || c & /*label*/
      2) && wt(
        e,
        "title",
        /*label*/
        u[1]
      ), (!o || c & /*pending*/
      8) && Qe(
        e,
        "pending",
        /*pending*/
        u[3]
      ), (!o || c & /*padded*/
      32) && Qe(
        e,
        "padded",
        /*padded*/
        u[5]
      ), (!o || c & /*highlight*/
      64) && Qe(
        e,
        "highlight",
        /*highlight*/
        u[6]
      ), (!o || c & /*transparent*/
      512) && Qe(
        e,
        "transparent",
        /*transparent*/
        u[9]
      ), c & /*disabled, _color*/
      2176 && Ti(e, "color", !/*disabled*/
      u[7] && /*_color*/
      u[11] ? (
        /*_color*/
        u[11]
      ) : "var(--block-label-text-color)"), c & /*disabled, background*/
      1152 && Ti(e, "--bg-color", /*disabled*/
      u[7] ? "auto" : (
        /*background*/
        u[10]
      ));
    },
    i(u) {
      o || (O_(l.$$.fragment, u), o = !0);
    },
    o(u) {
      D_(l.$$.fragment, u), o = !1;
    },
    d(u) {
      u && ku(e), a && a.d(), A_(l), r = !1, s();
    }
  };
}
function M_(t, e, n) {
  let i, { Icon: l } = e, { label: o = "" } = e, { show_label: r = !1 } = e, { pending: s = !1 } = e, { size: a = "small" } = e, { padded: u = !0 } = e, { highlight: c = !1 } = e, { disabled: f = !1 } = e, { hasPopup: d = !1 } = e, { color: _ = "var(--block-label-text-color)" } = e, { transparent: m = !1 } = e, { background: h = "var(--background-fill-primary)" } = e;
  function p(v) {
    T_.call(this, t, v);
  }
  return t.$$set = (v) => {
    "Icon" in v && n(0, l = v.Icon), "label" in v && n(1, o = v.label), "show_label" in v && n(2, r = v.show_label), "pending" in v && n(3, s = v.pending), "size" in v && n(4, a = v.size), "padded" in v && n(5, u = v.padded), "highlight" in v && n(6, c = v.highlight), "disabled" in v && n(7, f = v.disabled), "hasPopup" in v && n(8, d = v.hasPopup), "color" in v && n(12, _ = v.color), "transparent" in v && n(9, m = v.transparent), "background" in v && n(10, h = v.background);
  }, t.$$.update = () => {
    t.$$.dirty & /*highlight, color*/
    4160 && n(11, i = c ? "var(--color-accent)" : _);
  }, [
    l,
    o,
    r,
    s,
    a,
    u,
    c,
    f,
    d,
    m,
    h,
    i,
    _,
    p
  ];
}
class Fn extends S_ {
  constructor(e) {
    super(), B_(this, e, M_, j_, I_, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: x_,
  append: U_,
  attr: Fl,
  binding_callbacks: q_,
  create_slot: F_,
  detach: G_,
  element: na,
  get_all_dirty_from_scope: V_,
  get_slot_changes: z_,
  init: X_,
  insert: W_,
  safe_not_equal: Z_,
  toggle_class: It,
  transition_in: J_,
  transition_out: Q_,
  update_slot_base: Y_
} = window.__gradio__svelte__internal;
function K_(t) {
  let e, n, i;
  const l = (
    /*#slots*/
    t[5].default
  ), o = F_(
    l,
    t,
    /*$$scope*/
    t[4],
    null
  );
  return {
    c() {
      e = na("div"), n = na("div"), o && o.c(), Fl(n, "class", "icon svelte-3w3rth"), Fl(e, "class", "empty svelte-3w3rth"), Fl(e, "aria-label", "Empty value"), It(
        e,
        "small",
        /*size*/
        t[0] === "small"
      ), It(
        e,
        "large",
        /*size*/
        t[0] === "large"
      ), It(
        e,
        "unpadded_box",
        /*unpadded_box*/
        t[1]
      ), It(
        e,
        "small_parent",
        /*parent_height*/
        t[3]
      );
    },
    m(r, s) {
      W_(r, e, s), U_(e, n), o && o.m(n, null), t[6](e), i = !0;
    },
    p(r, [s]) {
      o && o.p && (!i || s & /*$$scope*/
      16) && Y_(
        o,
        l,
        r,
        /*$$scope*/
        r[4],
        i ? z_(
          l,
          /*$$scope*/
          r[4],
          s,
          null
        ) : V_(
          /*$$scope*/
          r[4]
        ),
        null
      ), (!i || s & /*size*/
      1) && It(
        e,
        "small",
        /*size*/
        r[0] === "small"
      ), (!i || s & /*size*/
      1) && It(
        e,
        "large",
        /*size*/
        r[0] === "large"
      ), (!i || s & /*unpadded_box*/
      2) && It(
        e,
        "unpadded_box",
        /*unpadded_box*/
        r[1]
      ), (!i || s & /*parent_height*/
      8) && It(
        e,
        "small_parent",
        /*parent_height*/
        r[3]
      );
    },
    i(r) {
      i || (J_(o, r), i = !0);
    },
    o(r) {
      Q_(o, r), i = !1;
    },
    d(r) {
      r && G_(e), o && o.d(r), t[6](null);
    }
  };
}
function $_(t) {
  let e, n = t[0], i = 1;
  for (; i < t.length; ) {
    const l = t[i], o = t[i + 1];
    if (i += 2, (l === "optionalAccess" || l === "optionalCall") && n == null)
      return;
    l === "access" || l === "optionalAccess" ? (e = n, n = o(n)) : (l === "call" || l === "optionalCall") && (n = o((...r) => n.call(e, ...r)), e = void 0);
  }
  return n;
}
function em(t, e, n) {
  let i, { $$slots: l = {}, $$scope: o } = e, { size: r = "small" } = e, { unpadded_box: s = !1 } = e, a;
  function u(f) {
    if (!f)
      return !1;
    const { height: d } = f.getBoundingClientRect(), { height: _ } = $_([
      f,
      "access",
      (m) => m.parentElement,
      "optionalAccess",
      (m) => m.getBoundingClientRect,
      "call",
      (m) => m()
    ]) || { height: d };
    return d > _ + 2;
  }
  function c(f) {
    q_[f ? "unshift" : "push"](() => {
      a = f, n(2, a);
    });
  }
  return t.$$set = (f) => {
    "size" in f && n(0, r = f.size), "unpadded_box" in f && n(1, s = f.unpadded_box), "$$scope" in f && n(4, o = f.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*el*/
    4 && n(3, i = u(a));
  }, [r, s, a, i, o, l, c];
}
class tm extends x_ {
  constructor(e) {
    super(), X_(this, e, em, K_, Z_, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: nm,
  append: ia,
  attr: Re,
  detach: im,
  init: lm,
  insert: om,
  noop: Gl,
  safe_not_equal: rm,
  svg_element: Vl
} = window.__gradio__svelte__internal;
function am(t) {
  let e, n, i;
  return {
    c() {
      e = Vl("svg"), n = Vl("path"), i = Vl("circle"), Re(n, "d", "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"), Re(i, "cx", "12"), Re(i, "cy", "13"), Re(i, "r", "4"), Re(e, "xmlns", "http://www.w3.org/2000/svg"), Re(e, "width", "100%"), Re(e, "height", "100%"), Re(e, "viewBox", "0 0 24 24"), Re(e, "fill", "none"), Re(e, "stroke", "currentColor"), Re(e, "stroke-width", "1.5"), Re(e, "stroke-linecap", "round"), Re(e, "stroke-linejoin", "round"), Re(e, "class", "feather feather-camera");
    },
    m(l, o) {
      om(l, e, o), ia(e, n), ia(e, i);
    },
    p: Gl,
    i: Gl,
    o: Gl,
    d(l) {
      l && im(e);
    }
  };
}
class sm extends nm {
  constructor(e) {
    super(), lm(this, e, null, am, rm, {});
  }
}
const {
  SvelteComponent: um,
  append: cm,
  attr: et,
  detach: fm,
  init: dm,
  insert: _m,
  noop: zl,
  safe_not_equal: mm,
  svg_element: la
} = window.__gradio__svelte__internal;
function hm(t) {
  let e, n;
  return {
    c() {
      e = la("svg"), n = la("circle"), et(n, "cx", "12"), et(n, "cy", "12"), et(n, "r", "10"), et(e, "xmlns", "http://www.w3.org/2000/svg"), et(e, "width", "100%"), et(e, "height", "100%"), et(e, "viewBox", "0 0 24 24"), et(e, "stroke-width", "1.5"), et(e, "stroke-linecap", "round"), et(e, "stroke-linejoin", "round"), et(e, "class", "feather feather-circle");
    },
    m(i, l) {
      _m(i, e, l), cm(e, n);
    },
    p: zl,
    i: zl,
    o: zl,
    d(i) {
      i && fm(e);
    }
  };
}
class pm extends um {
  constructor(e) {
    super(), dm(this, e, null, hm, mm, {});
  }
}
const {
  SvelteComponent: gm,
  append: Xl,
  attr: tt,
  detach: bm,
  init: vm,
  insert: wm,
  noop: Wl,
  safe_not_equal: ym,
  set_style: ct,
  svg_element: Ci
} = window.__gradio__svelte__internal;
function km(t) {
  let e, n, i, l;
  return {
    c() {
      e = Ci("svg"), n = Ci("g"), i = Ci("path"), l = Ci("path"), tt(i, "d", "M18,6L6.087,17.913"), ct(i, "fill", "none"), ct(i, "fill-rule", "nonzero"), ct(i, "stroke-width", "2px"), tt(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), tt(l, "d", "M4.364,4.364L19.636,19.636"), ct(l, "fill", "none"), ct(l, "fill-rule", "nonzero"), ct(l, "stroke-width", "2px"), tt(e, "width", "100%"), tt(e, "height", "100%"), tt(e, "viewBox", "0 0 24 24"), tt(e, "version", "1.1"), tt(e, "xmlns", "http://www.w3.org/2000/svg"), tt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), tt(e, "xml:space", "preserve"), tt(e, "stroke", "currentColor"), ct(e, "fill-rule", "evenodd"), ct(e, "clip-rule", "evenodd"), ct(e, "stroke-linecap", "round"), ct(e, "stroke-linejoin", "round");
    },
    m(o, r) {
      wm(o, e, r), Xl(e, n), Xl(n, i), Xl(e, l);
    },
    p: Wl,
    i: Wl,
    o: Wl,
    d(o) {
      o && bm(e);
    }
  };
}
class Em extends gm {
  constructor(e) {
    super(), vm(this, e, null, km, ym, {});
  }
}
const {
  SvelteComponent: Sm,
  append: Tm,
  attr: Yn,
  detach: Cm,
  init: Am,
  insert: Bm,
  noop: Zl,
  safe_not_equal: Lm,
  svg_element: oa
} = window.__gradio__svelte__internal;
function Nm(t) {
  let e, n;
  return {
    c() {
      e = oa("svg"), n = oa("path"), Yn(n, "d", "M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z"), Yn(n, "fill", "currentColor"), Yn(e, "id", "icon"), Yn(e, "xmlns", "http://www.w3.org/2000/svg"), Yn(e, "viewBox", "0 0 32 32");
    },
    m(i, l) {
      Bm(i, e, l), Tm(e, n);
    },
    p: Zl,
    i: Zl,
    o: Zl,
    d(i) {
      i && Cm(e);
    }
  };
}
class Im extends Sm {
  constructor(e) {
    super(), Am(this, e, null, Nm, Lm, {});
  }
}
const {
  SvelteComponent: Hm,
  append: Pm,
  attr: mn,
  detach: Rm,
  init: Om,
  insert: Dm,
  noop: Jl,
  safe_not_equal: jm,
  svg_element: ra
} = window.__gradio__svelte__internal;
function Mm(t) {
  let e, n;
  return {
    c() {
      e = ra("svg"), n = ra("path"), mn(n, "fill", "currentColor"), mn(n, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), mn(e, "xmlns", "http://www.w3.org/2000/svg"), mn(e, "width", "100%"), mn(e, "height", "100%"), mn(e, "viewBox", "0 0 32 32");
    },
    m(i, l) {
      Dm(i, e, l), Pm(e, n);
    },
    p: Jl,
    i: Jl,
    o: Jl,
    d(i) {
      i && Rm(e);
    }
  };
}
class Su extends Hm {
  constructor(e) {
    super(), Om(this, e, null, Mm, jm, {});
  }
}
const {
  SvelteComponent: xm,
  append: Um,
  attr: hn,
  detach: qm,
  init: Fm,
  insert: Gm,
  noop: Ql,
  safe_not_equal: Vm,
  svg_element: aa
} = window.__gradio__svelte__internal;
function zm(t) {
  let e, n;
  return {
    c() {
      e = aa("svg"), n = aa("path"), hn(n, "d", "M5 8l4 4 4-4z"), hn(e, "class", "dropdown-arrow svelte-145leq6"), hn(e, "xmlns", "http://www.w3.org/2000/svg"), hn(e, "width", "100%"), hn(e, "height", "100%"), hn(e, "viewBox", "0 0 18 18");
    },
    m(i, l) {
      Gm(i, e, l), Um(e, n);
    },
    p: Ql,
    i: Ql,
    o: Ql,
    d(i) {
      i && qm(e);
    }
  };
}
class Tu extends xm {
  constructor(e) {
    super(), Fm(this, e, null, zm, Vm, {});
  }
}
const {
  SvelteComponent: Xm,
  append: Wm,
  attr: nt,
  detach: Zm,
  init: Jm,
  insert: Qm,
  noop: Yl,
  safe_not_equal: Ym,
  svg_element: sa
} = window.__gradio__svelte__internal;
function Km(t) {
  let e, n;
  return {
    c() {
      e = sa("svg"), n = sa("path"), nt(n, "d", "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"), nt(e, "xmlns", "http://www.w3.org/2000/svg"), nt(e, "width", "100%"), nt(e, "height", "100%"), nt(e, "viewBox", "0 0 24 24"), nt(e, "fill", "none"), nt(e, "stroke", "currentColor"), nt(e, "stroke-width", "1.5"), nt(e, "stroke-linecap", "round"), nt(e, "stroke-linejoin", "round"), nt(e, "class", "feather feather-edit-2");
    },
    m(i, l) {
      Qm(i, e, l), Wm(e, n);
    },
    p: Yl,
    i: Yl,
    o: Yl,
    d(i) {
      i && Zm(e);
    }
  };
}
class $m extends Xm {
  constructor(e) {
    super(), Jm(this, e, null, Km, Ym, {});
  }
}
const {
  SvelteComponent: eh,
  append: th,
  attr: pn,
  detach: nh,
  init: ih,
  insert: lh,
  noop: Kl,
  safe_not_equal: oh,
  svg_element: ua
} = window.__gradio__svelte__internal;
function rh(t) {
  let e, n;
  return {
    c() {
      e = ua("svg"), n = ua("path"), pn(n, "fill", "currentColor"), pn(n, "d", "M13.75 2a2.25 2.25 0 0 1 2.236 2.002V4h1.764A2.25 2.25 0 0 1 20 6.25V11h-1.5V6.25a.75.75 0 0 0-.75-.75h-2.129c-.404.603-1.091 1-1.871 1h-3.5c-.78 0-1.467-.397-1.871-1H6.25a.75.75 0 0 0-.75.75v13.5c0 .414.336.75.75.75h4.78a3.99 3.99 0 0 0 .505 1.5H6.25A2.25 2.25 0 0 1 4 19.75V6.25A2.25 2.25 0 0 1 6.25 4h1.764a2.25 2.25 0 0 1 2.236-2h3.5Zm2.245 2.096L16 4.25c0-.052-.002-.103-.005-.154ZM13.75 3.5h-3.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5ZM15 12a3 3 0 0 0-3 3v5c0 .556.151 1.077.415 1.524l3.494-3.494a2.25 2.25 0 0 1 3.182 0l3.494 3.494c.264-.447.415-.968.415-1.524v-5a3 3 0 0 0-3-3h-5Zm0 11a2.985 2.985 0 0 1-1.524-.415l3.494-3.494a.75.75 0 0 1 1.06 0l3.494 3.494A2.985 2.985 0 0 1 20 23h-5Zm5-7a1 1 0 1 1 0-2a1 1 0 0 1 0 2Z"), pn(e, "xmlns", "http://www.w3.org/2000/svg"), pn(e, "width", "100%"), pn(e, "height", "100%"), pn(e, "viewBox", "0 0 24 24");
    },
    m(i, l) {
      lh(i, e, l), th(e, n);
    },
    p: Kl,
    i: Kl,
    o: Kl,
    d(i) {
      i && nh(e);
    }
  };
}
class Cu extends eh {
  constructor(e) {
    super(), ih(this, e, null, rh, oh, {});
  }
}
const {
  SvelteComponent: ah,
  append: sh,
  attr: ft,
  detach: uh,
  init: ch,
  insert: fh,
  noop: $l,
  safe_not_equal: dh,
  svg_element: ca
} = window.__gradio__svelte__internal;
function _h(t) {
  let e, n;
  return {
    c() {
      e = ca("svg"), n = ca("path"), ft(n, "d", "M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"), ft(e, "xmlns", "http://www.w3.org/2000/svg"), ft(e, "width", "100%"), ft(e, "height", "100%"), ft(e, "viewBox", "0 0 24 24"), ft(e, "fill", "none"), ft(e, "stroke", "currentColor"), ft(e, "stroke-width", "1.5"), ft(e, "stroke-linecap", "round"), ft(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      fh(i, e, l), sh(e, n);
    },
    p: $l,
    i: $l,
    o: $l,
    d(i) {
      i && uh(e);
    }
  };
}
class mh extends ah {
  constructor(e) {
    super(), ch(this, e, null, _h, dh, {});
  }
}
const {
  SvelteComponent: hh,
  append: Ai,
  attr: ce,
  detach: ph,
  init: gh,
  insert: bh,
  noop: eo,
  safe_not_equal: vh,
  svg_element: Kn
} = window.__gradio__svelte__internal;
function wh(t) {
  let e, n, i, l, o;
  return {
    c() {
      e = Kn("svg"), n = Kn("path"), i = Kn("path"), l = Kn("line"), o = Kn("line"), ce(n, "d", "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"), ce(i, "d", "M19 10v2a7 7 0 0 1-14 0v-2"), ce(l, "x1", "12"), ce(l, "y1", "19"), ce(l, "x2", "12"), ce(l, "y2", "23"), ce(o, "x1", "8"), ce(o, "y1", "23"), ce(o, "x2", "16"), ce(o, "y2", "23"), ce(e, "xmlns", "http://www.w3.org/2000/svg"), ce(e, "width", "100%"), ce(e, "height", "100%"), ce(e, "viewBox", "0 0 24 24"), ce(e, "fill", "none"), ce(e, "stroke", "currentColor"), ce(e, "stroke-width", "2"), ce(e, "stroke-linecap", "round"), ce(e, "stroke-linejoin", "round"), ce(e, "class", "feather feather-mic");
    },
    m(r, s) {
      bh(r, e, s), Ai(e, n), Ai(e, i), Ai(e, l), Ai(e, o);
    },
    p: eo,
    i: eo,
    o: eo,
    d(r) {
      r && ph(e);
    }
  };
}
class yh extends hh {
  constructor(e) {
    super(), gh(this, e, null, wh, vh, {});
  }
}
const {
  SvelteComponent: kh,
  append: fa,
  attr: be,
  detach: Eh,
  init: Sh,
  insert: Th,
  noop: to,
  safe_not_equal: Ch,
  svg_element: no
} = window.__gradio__svelte__internal;
function Ah(t) {
  let e, n, i;
  return {
    c() {
      e = no("svg"), n = no("rect"), i = no("rect"), be(n, "x", "6"), be(n, "y", "4"), be(n, "width", "4"), be(n, "height", "16"), be(i, "x", "14"), be(i, "y", "4"), be(i, "width", "4"), be(i, "height", "16"), be(e, "xmlns", "http://www.w3.org/2000/svg"), be(e, "width", "100%"), be(e, "height", "100%"), be(e, "viewBox", "0 0 24 24"), be(e, "fill", "currentColor"), be(e, "stroke", "currentColor"), be(e, "stroke-width", "1.5"), be(e, "stroke-linecap", "round"), be(e, "stroke-linejoin", "round");
    },
    m(l, o) {
      Th(l, e, o), fa(e, n), fa(e, i);
    },
    p: to,
    i: to,
    o: to,
    d(l) {
      l && Eh(e);
    }
  };
}
class Bh extends kh {
  constructor(e) {
    super(), Sh(this, e, null, Ah, Ch, {});
  }
}
const {
  SvelteComponent: Lh,
  append: Nh,
  attr: dt,
  detach: Ih,
  init: Hh,
  insert: Ph,
  noop: io,
  safe_not_equal: Rh,
  svg_element: da
} = window.__gradio__svelte__internal;
function Oh(t) {
  let e, n;
  return {
    c() {
      e = da("svg"), n = da("polygon"), dt(n, "points", "5 3 19 12 5 21 5 3"), dt(e, "xmlns", "http://www.w3.org/2000/svg"), dt(e, "width", "100%"), dt(e, "height", "100%"), dt(e, "viewBox", "0 0 24 24"), dt(e, "fill", "currentColor"), dt(e, "stroke", "currentColor"), dt(e, "stroke-width", "1.5"), dt(e, "stroke-linecap", "round"), dt(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      Ph(i, e, l), Nh(e, n);
    },
    p: io,
    i: io,
    o: io,
    d(i) {
      i && Ih(e);
    }
  };
}
class Dh extends Lh {
  constructor(e) {
    super(), Hh(this, e, null, Oh, Rh, {});
  }
}
const {
  SvelteComponent: jh,
  append: Mh,
  attr: Oe,
  detach: xh,
  init: Uh,
  insert: qh,
  noop: lo,
  safe_not_equal: Fh,
  svg_element: _a
} = window.__gradio__svelte__internal;
function Gh(t) {
  let e, n;
  return {
    c() {
      e = _a("svg"), n = _a("rect"), Oe(n, "x", "3"), Oe(n, "y", "3"), Oe(n, "width", "18"), Oe(n, "height", "18"), Oe(n, "rx", "2"), Oe(n, "ry", "2"), Oe(e, "xmlns", "http://www.w3.org/2000/svg"), Oe(e, "width", "100%"), Oe(e, "height", "100%"), Oe(e, "viewBox", "0 0 24 24"), Oe(e, "stroke-width", "1.5"), Oe(e, "stroke-linecap", "round"), Oe(e, "stroke-linejoin", "round"), Oe(e, "class", "feather feather-square");
    },
    m(i, l) {
      qh(i, e, l), Mh(e, n);
    },
    p: lo,
    i: lo,
    o: lo,
    d(i) {
      i && xh(e);
    }
  };
}
class Vh extends jh {
  constructor(e) {
    super(), Uh(this, e, null, Gh, Fh, {});
  }
}
const {
  SvelteComponent: zh,
  append: $n,
  attr: Y,
  detach: Xh,
  init: Wh,
  insert: Zh,
  noop: oo,
  safe_not_equal: Jh,
  svg_element: gn
} = window.__gradio__svelte__internal;
function Qh(t) {
  let e, n, i, l, o, r;
  return {
    c() {
      e = gn("svg"), n = gn("circle"), i = gn("circle"), l = gn("line"), o = gn("line"), r = gn("line"), Y(n, "cx", "6"), Y(n, "cy", "6"), Y(n, "r", "3"), Y(i, "cx", "6"), Y(i, "cy", "18"), Y(i, "r", "3"), Y(l, "x1", "20"), Y(l, "y1", "4"), Y(l, "x2", "8.12"), Y(l, "y2", "15.88"), Y(o, "x1", "14.47"), Y(o, "y1", "14.48"), Y(o, "x2", "20"), Y(o, "y2", "20"), Y(r, "x1", "8.12"), Y(r, "y1", "8.12"), Y(r, "x2", "12"), Y(r, "y2", "12"), Y(e, "xmlns", "http://www.w3.org/2000/svg"), Y(e, "width", "100%"), Y(e, "height", "100%"), Y(e, "viewBox", "0 0 24 24"), Y(e, "fill", "none"), Y(e, "stroke", "currentColor"), Y(e, "stroke-width", "2"), Y(e, "stroke-linecap", "round"), Y(e, "stroke-linejoin", "round"), Y(e, "class", "feather feather-scissors");
    },
    m(s, a) {
      Zh(s, e, a), $n(e, n), $n(e, i), $n(e, l), $n(e, o), $n(e, r);
    },
    p: oo,
    i: oo,
    o: oo,
    d(s) {
      s && Xh(e);
    }
  };
}
class Yh extends zh {
  constructor(e) {
    super(), Wh(this, e, null, Qh, Jh, {});
  }
}
const {
  SvelteComponent: Kh,
  append: ma,
  attr: Ye,
  detach: $h,
  init: ep,
  insert: tp,
  noop: ro,
  safe_not_equal: np,
  svg_element: ao
} = window.__gradio__svelte__internal;
function ip(t) {
  let e, n, i;
  return {
    c() {
      e = ao("svg"), n = ao("polyline"), i = ao("path"), Ye(n, "points", "1 4 1 10 7 10"), Ye(i, "d", "M3.51 15a9 9 0 1 0 2.13-9.36L1 10"), Ye(e, "xmlns", "http://www.w3.org/2000/svg"), Ye(e, "width", "100%"), Ye(e, "height", "100%"), Ye(e, "viewBox", "0 0 24 24"), Ye(e, "fill", "none"), Ye(e, "stroke", "currentColor"), Ye(e, "stroke-width", "2"), Ye(e, "stroke-linecap", "round"), Ye(e, "stroke-linejoin", "round"), Ye(e, "class", "feather feather-rotate-ccw");
    },
    m(l, o) {
      tp(l, e, o), ma(e, n), ma(e, i);
    },
    p: ro,
    i: ro,
    o: ro,
    d(l) {
      l && $h(e);
    }
  };
}
class cr extends Kh {
  constructor(e) {
    super(), ep(this, e, null, ip, np, {});
  }
}
const {
  SvelteComponent: lp,
  append: so,
  attr: Se,
  detach: op,
  init: rp,
  insert: ap,
  noop: uo,
  safe_not_equal: sp,
  svg_element: Bi
} = window.__gradio__svelte__internal;
function up(t) {
  let e, n, i, l;
  return {
    c() {
      e = Bi("svg"), n = Bi("path"), i = Bi("polyline"), l = Bi("line"), Se(n, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), Se(i, "points", "17 8 12 3 7 8"), Se(l, "x1", "12"), Se(l, "y1", "3"), Se(l, "x2", "12"), Se(l, "y2", "15"), Se(e, "xmlns", "http://www.w3.org/2000/svg"), Se(e, "width", "90%"), Se(e, "height", "90%"), Se(e, "viewBox", "0 0 24 24"), Se(e, "fill", "none"), Se(e, "stroke", "currentColor"), Se(e, "stroke-width", "2"), Se(e, "stroke-linecap", "round"), Se(e, "stroke-linejoin", "round"), Se(e, "class", "feather feather-upload");
    },
    m(o, r) {
      ap(o, e, r), so(e, n), so(e, i), so(e, l);
    },
    p: uo,
    i: uo,
    o: uo,
    d(o) {
      o && op(e);
    }
  };
}
class Au extends lp {
  constructor(e) {
    super(), rp(this, e, null, up, sp, {});
  }
}
const {
  SvelteComponent: cp,
  append: ha,
  attr: ve,
  detach: fp,
  init: dp,
  insert: _p,
  noop: co,
  safe_not_equal: mp,
  svg_element: fo
} = window.__gradio__svelte__internal;
function hp(t) {
  let e, n, i;
  return {
    c() {
      e = fo("svg"), n = fo("polygon"), i = fo("rect"), ve(n, "points", "23 7 16 12 23 17 23 7"), ve(i, "x", "1"), ve(i, "y", "5"), ve(i, "width", "15"), ve(i, "height", "14"), ve(i, "rx", "2"), ve(i, "ry", "2"), ve(e, "xmlns", "http://www.w3.org/2000/svg"), ve(e, "width", "100%"), ve(e, "height", "100%"), ve(e, "viewBox", "0 0 24 24"), ve(e, "fill", "none"), ve(e, "stroke", "currentColor"), ve(e, "stroke-width", "1.5"), ve(e, "stroke-linecap", "round"), ve(e, "stroke-linejoin", "round"), ve(e, "class", "feather feather-video");
    },
    m(l, o) {
      _p(l, e, o), ha(e, n), ha(e, i);
    },
    p: co,
    i: co,
    o: co,
    d(l) {
      l && fp(e);
    }
  };
}
let fr = class extends cp {
  constructor(e) {
    super(), dp(this, e, null, hp, mp, {});
  }
};
const {
  SvelteComponent: pp,
  append: pa,
  attr: Ht,
  detach: gp,
  init: bp,
  insert: vp,
  noop: _o,
  safe_not_equal: wp,
  svg_element: mo
} = window.__gradio__svelte__internal;
function yp(t) {
  let e, n, i;
  return {
    c() {
      e = mo("svg"), n = mo("path"), i = mo("path"), Ht(n, "fill", "currentColor"), Ht(n, "d", "M12 2c-4.963 0-9 4.038-9 9c0 3.328 1.82 6.232 4.513 7.79l-2.067 1.378A1 1 0 0 0 6 22h12a1 1 0 0 0 .555-1.832l-2.067-1.378C19.18 17.232 21 14.328 21 11c0-4.962-4.037-9-9-9zm0 16c-3.859 0-7-3.141-7-7c0-3.86 3.141-7 7-7s7 3.14 7 7c0 3.859-3.141 7-7 7z"), Ht(i, "fill", "currentColor"), Ht(i, "d", "M12 6c-2.757 0-5 2.243-5 5s2.243 5 5 5s5-2.243 5-5s-2.243-5-5-5zm0 8c-1.654 0-3-1.346-3-3s1.346-3 3-3s3 1.346 3 3s-1.346 3-3 3z"), Ht(e, "xmlns", "http://www.w3.org/2000/svg"), Ht(e, "width", "100%"), Ht(e, "height", "100%"), Ht(e, "viewBox", "0 0 24 24");
    },
    m(l, o) {
      vp(l, e, o), pa(e, n), pa(e, i);
    },
    p: _o,
    i: _o,
    o: _o,
    d(l) {
      l && gp(e);
    }
  };
}
let Bu = class extends pp {
  constructor(e) {
    super(), bp(this, e, null, yp, wp, {});
  }
};
const kp = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ga = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
kp.reduce(
  (t, { color: e, primary: n, secondary: i }) => ({
    ...t,
    [e]: {
      primary: ga[e][n],
      secondary: ga[e][i]
    }
  }),
  {}
);
function Ep(t) {
  let e, n = t[0], i = 1;
  for (; i < t.length; ) {
    const l = t[i], o = t[i + 1];
    if (i += 2, (l === "optionalAccess" || l === "optionalCall") && n == null)
      return;
    l === "access" || l === "optionalAccess" ? (e = n, n = o(n)) : (l === "call" || l === "optionalCall") && (n = o((...r) => n.call(e, ...r)), e = void 0);
  }
  return n;
}
class Mi extends Error {
  constructor(e) {
    super(e), this.name = "ShareError";
  }
}
async function Sp(t, e) {
  if (window.__gradio_space__ == null)
    throw new Mi("Must be on Spaces to share.");
  let n, i, l;
  if (e === "url") {
    const a = await fetch(t);
    n = await a.blob(), i = a.headers.get("content-type") || "", l = a.headers.get("content-disposition") || "";
  } else
    n = Tp(t), i = t.split(";")[0].split(":")[1], l = "file" + i.split("/")[1];
  const o = new File([n], l, { type: i }), r = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: o,
    headers: {
      "Content-Type": o.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!r.ok) {
    if (Ep([r, "access", (a) => a.headers, "access", (a) => a.get, "call", (a) => a("content-type"), "optionalAccess", (a) => a.includes, "call", (a) => a("application/json")])) {
      const a = await r.json();
      throw new Mi(`Upload failed: ${a.error}`);
    }
    throw new Mi("Upload failed.");
  }
  return await r.text();
}
function Tp(t) {
  for (var e = t.split(","), n = e[0].match(/:(.*?);/)[1], i = atob(e[1]), l = i.length, o = new Uint8Array(l); l--; )
    o[l] = i.charCodeAt(l);
  return new Blob([o], { type: n });
}
const Sn = (t) => {
  const e = Math.floor(t / 3600), n = Math.floor(t % 3600 / 60), i = Math.round(t) % 60, l = `${n < 10 ? "0" : ""}${n}`, o = `${i < 10 ? "0" : ""}${i}`;
  return e > 0 ? `${e}:${l}:${o}` : `${n}:${o}`;
}, {
  SvelteComponent: Cp,
  create_component: Ap,
  destroy_component: Bp,
  init: Lp,
  mount_component: Np,
  safe_not_equal: Ip,
  transition_in: Hp,
  transition_out: Pp
} = window.__gradio__svelte__internal, { createEventDispatcher: Rp } = window.__gradio__svelte__internal;
function Op(t) {
  let e, n;
  return e = new Fn({
    props: {
      Icon: Im,
      label: (
        /*i18n*/
        t[2]("common.share")
      ),
      pending: (
        /*pending*/
        t[3]
      )
    }
  }), e.$on(
    "click",
    /*click_handler*/
    t[5]
  ), {
    c() {
      Ap(e.$$.fragment);
    },
    m(i, l) {
      Np(e, i, l), n = !0;
    },
    p(i, [l]) {
      const o = {};
      l & /*i18n*/
      4 && (o.label = /*i18n*/
      i[2]("common.share")), l & /*pending*/
      8 && (o.pending = /*pending*/
      i[3]), e.$set(o);
    },
    i(i) {
      n || (Hp(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Pp(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Bp(e, i);
    }
  };
}
function Dp(t, e, n) {
  const i = Rp();
  let { formatter: l } = e, { value: o } = e, { i18n: r } = e, s = !1;
  const a = async () => {
    try {
      n(3, s = !0);
      const u = await l(o);
      i("share", { description: u });
    } catch (u) {
      console.error(u);
      let c = u instanceof Mi ? u.message : "Share failed.";
      i("error", c);
    } finally {
      n(3, s = !1);
    }
  };
  return t.$$set = (u) => {
    "formatter" in u && n(0, l = u.formatter), "value" in u && n(1, o = u.value), "i18n" in u && n(2, r = u.i18n);
  }, [l, o, r, s, i, a];
}
class jp extends Cp {
  constructor(e) {
    super(), Lp(this, e, Dp, Op, Ip, { formatter: 0, value: 1, i18n: 2 });
  }
}
const {
  SvelteComponent: Mp,
  append: Qt,
  attr: zo,
  check_outros: xp,
  create_component: Lu,
  destroy_component: Nu,
  detach: xi,
  element: Xo,
  group_outros: Up,
  init: qp,
  insert: Ui,
  mount_component: Iu,
  safe_not_equal: Fp,
  set_data: Wo,
  space: Zo,
  text: ni,
  toggle_class: ba,
  transition_in: Yi,
  transition_out: Ki
} = window.__gradio__svelte__internal;
function Gp(t) {
  let e, n;
  return e = new Au({}), {
    c() {
      Lu(e.$$.fragment);
    },
    m(i, l) {
      Iu(e, i, l), n = !0;
    },
    i(i) {
      n || (Yi(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Ki(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Nu(e, i);
    }
  };
}
function Vp(t) {
  let e, n;
  return e = new Cu({}), {
    c() {
      Lu(e.$$.fragment);
    },
    m(i, l) {
      Iu(e, i, l), n = !0;
    },
    i(i) {
      n || (Yi(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Ki(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Nu(e, i);
    }
  };
}
function va(t) {
  let e, n, i = (
    /*i18n*/
    t[1]("common.or") + ""
  ), l, o, r, s = (
    /*message*/
    (t[2] || /*i18n*/
    t[1]("upload_text.click_to_upload")) + ""
  ), a;
  return {
    c() {
      e = Xo("span"), n = ni("- "), l = ni(i), o = ni(" -"), r = Zo(), a = ni(s), zo(e, "class", "or svelte-kzcjhc");
    },
    m(u, c) {
      Ui(u, e, c), Qt(e, n), Qt(e, l), Qt(e, o), Ui(u, r, c), Ui(u, a, c);
    },
    p(u, c) {
      c & /*i18n*/
      2 && i !== (i = /*i18n*/
      u[1]("common.or") + "") && Wo(l, i), c & /*message, i18n*/
      6 && s !== (s = /*message*/
      (u[2] || /*i18n*/
      u[1]("upload_text.click_to_upload")) + "") && Wo(a, s);
    },
    d(u) {
      u && (xi(e), xi(r), xi(a));
    }
  };
}
function zp(t) {
  let e, n, i, l, o, r = (
    /*i18n*/
    t[1](
      /*defs*/
      t[5][
        /*type*/
        t[0]
      ] || /*defs*/
      t[5].file
    ) + ""
  ), s, a, u;
  const c = [Vp, Gp], f = [];
  function d(m, h) {
    return (
      /*type*/
      m[0] === "clipboard" ? 0 : 1
    );
  }
  i = d(t), l = f[i] = c[i](t);
  let _ = (
    /*mode*/
    t[3] !== "short" && va(t)
  );
  return {
    c() {
      e = Xo("div"), n = Xo("span"), l.c(), o = Zo(), s = ni(r), a = Zo(), _ && _.c(), zo(n, "class", "icon-wrap svelte-kzcjhc"), ba(
        n,
        "hovered",
        /*hovered*/
        t[4]
      ), zo(e, "class", "wrap svelte-kzcjhc");
    },
    m(m, h) {
      Ui(m, e, h), Qt(e, n), f[i].m(n, null), Qt(e, o), Qt(e, s), Qt(e, a), _ && _.m(e, null), u = !0;
    },
    p(m, [h]) {
      let p = i;
      i = d(m), i !== p && (Up(), Ki(f[p], 1, 1, () => {
        f[p] = null;
      }), xp(), l = f[i], l || (l = f[i] = c[i](m), l.c()), Yi(l, 1), l.m(n, null)), (!u || h & /*hovered*/
      16) && ba(
        n,
        "hovered",
        /*hovered*/
        m[4]
      ), (!u || h & /*i18n, type*/
      3) && r !== (r = /*i18n*/
      m[1](
        /*defs*/
        m[5][
          /*type*/
          m[0]
        ] || /*defs*/
        m[5].file
      ) + "") && Wo(s, r), /*mode*/
      m[3] !== "short" ? _ ? _.p(m, h) : (_ = va(m), _.c(), _.m(e, null)) : _ && (_.d(1), _ = null);
    },
    i(m) {
      u || (Yi(l), u = !0);
    },
    o(m) {
      Ki(l), u = !1;
    },
    d(m) {
      m && xi(e), f[i].d(), _ && _.d();
    }
  };
}
function Xp(t, e, n) {
  let { type: i = "file" } = e, { i18n: l } = e, { message: o = void 0 } = e, { mode: r = "full" } = e, { hovered: s = !1 } = e;
  const a = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return t.$$set = (u) => {
    "type" in u && n(0, i = u.type), "i18n" in u && n(1, l = u.i18n), "message" in u && n(2, o = u.message), "mode" in u && n(3, r = u.mode), "hovered" in u && n(4, s = u.hovered);
  }, [i, l, o, r, s, a];
}
class Wp extends Mp {
  constructor(e) {
    super(), qp(this, e, Xp, zp, Fp, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4
    });
  }
}
const {
  SvelteComponent: Zp,
  append: ho,
  attr: vt,
  check_outros: ii,
  create_component: hl,
  destroy_component: pl,
  detach: Gn,
  element: bi,
  empty: Jp,
  group_outros: li,
  init: Qp,
  insert: Vn,
  listen: gl,
  mount_component: bl,
  safe_not_equal: Yp,
  space: po,
  toggle_class: xt,
  transition_in: _e,
  transition_out: Ue
} = window.__gradio__svelte__internal;
function wa(t) {
  let e, n = (
    /*sources*/
    t[1].includes("upload")
  ), i, l = (
    /*sources*/
    t[1].includes("microphone")
  ), o, r = (
    /*sources*/
    t[1].includes("webcam")
  ), s, a = (
    /*sources*/
    t[1].includes("clipboard")
  ), u, c = n && ya(t), f = l && ka(t), d = r && Ea(t), _ = a && Sa(t);
  return {
    c() {
      e = bi("span"), c && c.c(), i = po(), f && f.c(), o = po(), d && d.c(), s = po(), _ && _.c(), vt(e, "class", "source-selection svelte-1jp3vgd"), vt(e, "data-testid", "source-select");
    },
    m(m, h) {
      Vn(m, e, h), c && c.m(e, null), ho(e, i), f && f.m(e, null), ho(e, o), d && d.m(e, null), ho(e, s), _ && _.m(e, null), u = !0;
    },
    p(m, h) {
      h & /*sources*/
      2 && (n = /*sources*/
      m[1].includes("upload")), n ? c ? (c.p(m, h), h & /*sources*/
      2 && _e(c, 1)) : (c = ya(m), c.c(), _e(c, 1), c.m(e, i)) : c && (li(), Ue(c, 1, 1, () => {
        c = null;
      }), ii()), h & /*sources*/
      2 && (l = /*sources*/
      m[1].includes("microphone")), l ? f ? (f.p(m, h), h & /*sources*/
      2 && _e(f, 1)) : (f = ka(m), f.c(), _e(f, 1), f.m(e, o)) : f && (li(), Ue(f, 1, 1, () => {
        f = null;
      }), ii()), h & /*sources*/
      2 && (r = /*sources*/
      m[1].includes("webcam")), r ? d ? (d.p(m, h), h & /*sources*/
      2 && _e(d, 1)) : (d = Ea(m), d.c(), _e(d, 1), d.m(e, s)) : d && (li(), Ue(d, 1, 1, () => {
        d = null;
      }), ii()), h & /*sources*/
      2 && (a = /*sources*/
      m[1].includes("clipboard")), a ? _ ? (_.p(m, h), h & /*sources*/
      2 && _e(_, 1)) : (_ = Sa(m), _.c(), _e(_, 1), _.m(e, null)) : _ && (li(), Ue(_, 1, 1, () => {
        _ = null;
      }), ii());
    },
    i(m) {
      u || (_e(c), _e(f), _e(d), _e(_), u = !0);
    },
    o(m) {
      Ue(c), Ue(f), Ue(d), Ue(_), u = !1;
    },
    d(m) {
      m && Gn(e), c && c.d(), f && f.d(), d && d.d(), _ && _.d();
    }
  };
}
function ya(t) {
  let e, n, i, l, o;
  return n = new Au({}), {
    c() {
      e = bi("button"), hl(n.$$.fragment), vt(e, "class", "icon svelte-1jp3vgd"), vt(e, "aria-label", "Upload file"), xt(
        e,
        "selected",
        /*active_source*/
        t[0] === "upload" || !/*active_source*/
        t[0]
      );
    },
    m(r, s) {
      Vn(r, e, s), bl(n, e, null), i = !0, l || (o = gl(
        e,
        "click",
        /*click_handler*/
        t[6]
      ), l = !0);
    },
    p(r, s) {
      (!i || s & /*active_source*/
      1) && xt(
        e,
        "selected",
        /*active_source*/
        r[0] === "upload" || !/*active_source*/
        r[0]
      );
    },
    i(r) {
      i || (_e(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Ue(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Gn(e), pl(n), l = !1, o();
    }
  };
}
function ka(t) {
  let e, n, i, l, o;
  return n = new yh({}), {
    c() {
      e = bi("button"), hl(n.$$.fragment), vt(e, "class", "icon svelte-1jp3vgd"), vt(e, "aria-label", "Record audio"), xt(
        e,
        "selected",
        /*active_source*/
        t[0] === "microphone"
      );
    },
    m(r, s) {
      Vn(r, e, s), bl(n, e, null), i = !0, l || (o = gl(
        e,
        "click",
        /*click_handler_1*/
        t[7]
      ), l = !0);
    },
    p(r, s) {
      (!i || s & /*active_source*/
      1) && xt(
        e,
        "selected",
        /*active_source*/
        r[0] === "microphone"
      );
    },
    i(r) {
      i || (_e(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Ue(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Gn(e), pl(n), l = !1, o();
    }
  };
}
function Ea(t) {
  let e, n, i, l, o;
  return n = new Bu({}), {
    c() {
      e = bi("button"), hl(n.$$.fragment), vt(e, "class", "icon svelte-1jp3vgd"), vt(e, "aria-label", "Capture from camera"), xt(
        e,
        "selected",
        /*active_source*/
        t[0] === "webcam"
      );
    },
    m(r, s) {
      Vn(r, e, s), bl(n, e, null), i = !0, l || (o = gl(
        e,
        "click",
        /*click_handler_2*/
        t[8]
      ), l = !0);
    },
    p(r, s) {
      (!i || s & /*active_source*/
      1) && xt(
        e,
        "selected",
        /*active_source*/
        r[0] === "webcam"
      );
    },
    i(r) {
      i || (_e(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Ue(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Gn(e), pl(n), l = !1, o();
    }
  };
}
function Sa(t) {
  let e, n, i, l, o;
  return n = new Cu({}), {
    c() {
      e = bi("button"), hl(n.$$.fragment), vt(e, "class", "icon svelte-1jp3vgd"), vt(e, "aria-label", "Paste from clipboard"), xt(
        e,
        "selected",
        /*active_source*/
        t[0] === "clipboard"
      );
    },
    m(r, s) {
      Vn(r, e, s), bl(n, e, null), i = !0, l || (o = gl(
        e,
        "click",
        /*click_handler_3*/
        t[9]
      ), l = !0);
    },
    p(r, s) {
      (!i || s & /*active_source*/
      1) && xt(
        e,
        "selected",
        /*active_source*/
        r[0] === "clipboard"
      );
    },
    i(r) {
      i || (_e(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Ue(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Gn(e), pl(n), l = !1, o();
    }
  };
}
function Kp(t) {
  let e, n, i = (
    /*unique_sources*/
    t[2].length > 1 && wa(t)
  );
  return {
    c() {
      i && i.c(), e = Jp();
    },
    m(l, o) {
      i && i.m(l, o), Vn(l, e, o), n = !0;
    },
    p(l, [o]) {
      /*unique_sources*/
      l[2].length > 1 ? i ? (i.p(l, o), o & /*unique_sources*/
      4 && _e(i, 1)) : (i = wa(l), i.c(), _e(i, 1), i.m(e.parentNode, e)) : i && (li(), Ue(i, 1, 1, () => {
        i = null;
      }), ii());
    },
    i(l) {
      n || (_e(i), n = !0);
    },
    o(l) {
      Ue(i), n = !1;
    },
    d(l) {
      l && Gn(e), i && i.d(l);
    }
  };
}
function $p(t, e, n) {
  let i, { sources: l } = e, { active_source: o } = e, { handle_clear: r = () => {
  } } = e, { handle_select: s = () => {
  } } = e;
  async function a(_) {
    r(), n(0, o = _), s(_);
  }
  const u = () => a("upload"), c = () => a("microphone"), f = () => a("webcam"), d = () => a("clipboard");
  return t.$$set = (_) => {
    "sources" in _ && n(1, l = _.sources), "active_source" in _ && n(0, o = _.active_source), "handle_clear" in _ && n(4, r = _.handle_clear), "handle_select" in _ && n(5, s = _.handle_select);
  }, t.$$.update = () => {
    t.$$.dirty & /*sources*/
    2 && n(2, i = [...new Set(l)]);
  }, [
    o,
    l,
    i,
    a,
    r,
    s,
    u,
    c,
    f,
    d
  ];
}
class e0 extends Zp {
  constructor(e) {
    super(), Qp(this, e, $p, Kp, Yp, {
      sources: 1,
      active_source: 0,
      handle_clear: 4,
      handle_select: 5
    });
  }
}
const { setContext: M2, getContext: t0 } = window.__gradio__svelte__internal, n0 = "WORKER_PROXY_CONTEXT_KEY";
function Hu() {
  return t0(n0);
}
function i0(t) {
  return t.host === window.location.host || t.host === "localhost:7860" || t.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  t.host === "lite.local";
}
function Pu(t, e) {
  const n = e.toLowerCase();
  for (const [i, l] of Object.entries(t))
    if (i.toLowerCase() === n)
      return l;
}
function Ru(t) {
  if (t == null)
    return !1;
  const e = new URL(t, window.location.href);
  return !(!i0(e) || e.protocol !== "http:" && e.protocol !== "https:");
}
async function l0(t) {
  if (t == null || !Ru(t))
    return t;
  const e = Hu();
  if (e == null)
    return t;
  const i = new URL(t, window.location.href).pathname;
  return e.httpRequest({
    method: "GET",
    path: i,
    headers: {},
    query_string: ""
  }).then((l) => {
    if (l.status !== 200)
      throw new Error(`Failed to get file ${i} from the Wasm worker.`);
    const o = new Blob([l.body], {
      type: Pu(l.headers, "content-type")
    });
    return URL.createObjectURL(o);
  });
}
const {
  SvelteComponent: o0,
  assign: $i,
  check_outros: Ou,
  compute_rest_props: Ta,
  create_slot: dr,
  detach: vl,
  element: Du,
  empty: ju,
  exclude_internal_props: r0,
  get_all_dirty_from_scope: _r,
  get_slot_changes: mr,
  get_spread_update: Mu,
  group_outros: xu,
  init: a0,
  insert: wl,
  listen: Uu,
  prevent_default: s0,
  safe_not_equal: u0,
  set_attributes: el,
  transition_in: ln,
  transition_out: on,
  update_slot_base: hr
} = window.__gradio__svelte__internal, { createEventDispatcher: c0 } = window.__gradio__svelte__internal;
function f0(t) {
  let e, n, i, l, o;
  const r = (
    /*#slots*/
    t[8].default
  ), s = dr(
    r,
    t,
    /*$$scope*/
    t[7],
    null
  );
  let a = [
    { href: (
      /*href*/
      t[0]
    ) },
    {
      target: n = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      t[1]
    ) },
    /*$$restProps*/
    t[6]
  ], u = {};
  for (let c = 0; c < a.length; c += 1)
    u = $i(u, a[c]);
  return {
    c() {
      e = Du("a"), s && s.c(), el(e, u);
    },
    m(c, f) {
      wl(c, e, f), s && s.m(e, null), i = !0, l || (o = Uu(
        e,
        "click",
        /*dispatch*/
        t[3].bind(null, "click")
      ), l = !0);
    },
    p(c, f) {
      s && s.p && (!i || f & /*$$scope*/
      128) && hr(
        s,
        r,
        c,
        /*$$scope*/
        c[7],
        i ? mr(
          r,
          /*$$scope*/
          c[7],
          f,
          null
        ) : _r(
          /*$$scope*/
          c[7]
        ),
        null
      ), el(e, u = Mu(a, [
        (!i || f & /*href*/
        1) && { href: (
          /*href*/
          c[0]
        ) },
        { target: n },
        { rel: "noopener noreferrer" },
        (!i || f & /*download*/
        2) && { download: (
          /*download*/
          c[1]
        ) },
        f & /*$$restProps*/
        64 && /*$$restProps*/
        c[6]
      ]));
    },
    i(c) {
      i || (ln(s, c), i = !0);
    },
    o(c) {
      on(s, c), i = !1;
    },
    d(c) {
      c && vl(e), s && s.d(c), l = !1, o();
    }
  };
}
function d0(t) {
  let e, n, i, l;
  const o = [m0, _0], r = [];
  function s(a, u) {
    return (
      /*is_downloading*/
      a[2] ? 0 : 1
    );
  }
  return e = s(t), n = r[e] = o[e](t), {
    c() {
      n.c(), i = ju();
    },
    m(a, u) {
      r[e].m(a, u), wl(a, i, u), l = !0;
    },
    p(a, u) {
      let c = e;
      e = s(a), e === c ? r[e].p(a, u) : (xu(), on(r[c], 1, 1, () => {
        r[c] = null;
      }), Ou(), n = r[e], n ? n.p(a, u) : (n = r[e] = o[e](a), n.c()), ln(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (ln(n), l = !0);
    },
    o(a) {
      on(n), l = !1;
    },
    d(a) {
      a && vl(i), r[e].d(a);
    }
  };
}
function _0(t) {
  let e, n, i, l;
  const o = (
    /*#slots*/
    t[8].default
  ), r = dr(
    o,
    t,
    /*$$scope*/
    t[7],
    null
  );
  let s = [
    /*$$restProps*/
    t[6],
    { href: (
      /*href*/
      t[0]
    ) }
  ], a = {};
  for (let u = 0; u < s.length; u += 1)
    a = $i(a, s[u]);
  return {
    c() {
      e = Du("a"), r && r.c(), el(e, a);
    },
    m(u, c) {
      wl(u, e, c), r && r.m(e, null), n = !0, i || (l = Uu(e, "click", s0(
        /*wasm_click_handler*/
        t[5]
      )), i = !0);
    },
    p(u, c) {
      r && r.p && (!n || c & /*$$scope*/
      128) && hr(
        r,
        o,
        u,
        /*$$scope*/
        u[7],
        n ? mr(
          o,
          /*$$scope*/
          u[7],
          c,
          null
        ) : _r(
          /*$$scope*/
          u[7]
        ),
        null
      ), el(e, a = Mu(s, [
        c & /*$$restProps*/
        64 && /*$$restProps*/
        u[6],
        (!n || c & /*href*/
        1) && { href: (
          /*href*/
          u[0]
        ) }
      ]));
    },
    i(u) {
      n || (ln(r, u), n = !0);
    },
    o(u) {
      on(r, u), n = !1;
    },
    d(u) {
      u && vl(e), r && r.d(u), i = !1, l();
    }
  };
}
function m0(t) {
  let e;
  const n = (
    /*#slots*/
    t[8].default
  ), i = dr(
    n,
    t,
    /*$$scope*/
    t[7],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(l, o) {
      i && i.m(l, o), e = !0;
    },
    p(l, o) {
      i && i.p && (!e || o & /*$$scope*/
      128) && hr(
        i,
        n,
        l,
        /*$$scope*/
        l[7],
        e ? mr(
          n,
          /*$$scope*/
          l[7],
          o,
          null
        ) : _r(
          /*$$scope*/
          l[7]
        ),
        null
      );
    },
    i(l) {
      e || (ln(i, l), e = !0);
    },
    o(l) {
      on(i, l), e = !1;
    },
    d(l) {
      i && i.d(l);
    }
  };
}
function h0(t) {
  let e, n, i, l, o;
  const r = [d0, f0], s = [];
  function a(u, c) {
    return c & /*href*/
    1 && (e = null), e == null && (e = !!/*worker_proxy*/
    (u[4] && Ru(
      /*href*/
      u[0]
    ))), e ? 0 : 1;
  }
  return n = a(t, -1), i = s[n] = r[n](t), {
    c() {
      i.c(), l = ju();
    },
    m(u, c) {
      s[n].m(u, c), wl(u, l, c), o = !0;
    },
    p(u, [c]) {
      let f = n;
      n = a(u, c), n === f ? s[n].p(u, c) : (xu(), on(s[f], 1, 1, () => {
        s[f] = null;
      }), Ou(), i = s[n], i ? i.p(u, c) : (i = s[n] = r[n](u), i.c()), ln(i, 1), i.m(l.parentNode, l));
    },
    i(u) {
      o || (ln(i), o = !0);
    },
    o(u) {
      on(i), o = !1;
    },
    d(u) {
      u && vl(l), s[n].d(u);
    }
  };
}
function p0(t, e, n) {
  const i = ["href", "download"];
  let l = Ta(e, i), { $$slots: o = {}, $$scope: r } = e, { href: s = void 0 } = e, { download: a } = e;
  const u = c0();
  let c = !1;
  const f = Hu();
  async function d() {
    if (c)
      return;
    if (u("click"), s == null)
      throw new Error("href is not defined.");
    if (f == null)
      throw new Error("Wasm worker proxy is not available.");
    const m = new URL(s, window.location.href).pathname;
    n(2, c = !0), f.httpRequest({
      method: "GET",
      path: m,
      headers: {},
      query_string: ""
    }).then((h) => {
      if (h.status !== 200)
        throw new Error(`Failed to get file ${m} from the Wasm worker.`);
      const p = new Blob(
        [h.body],
        {
          type: Pu(h.headers, "content-type")
        }
      ), v = URL.createObjectURL(p), y = document.createElement("a");
      y.href = v, y.download = a, y.click(), URL.revokeObjectURL(v);
    }).finally(() => {
      n(2, c = !1);
    });
  }
  return t.$$set = (_) => {
    e = $i($i({}, e), r0(_)), n(6, l = Ta(e, i)), "href" in _ && n(0, s = _.href), "download" in _ && n(1, a = _.download), "$$scope" in _ && n(7, r = _.$$scope);
  }, [
    s,
    a,
    c,
    u,
    f,
    d,
    l,
    r,
    o
  ];
}
class qu extends o0 {
  constructor(e) {
    super(), a0(this, e, p0, h0, u0, { href: 0, download: 1 });
  }
}
const {
  SvelteComponent: g0,
  append: go,
  attr: b0,
  check_outros: bo,
  create_component: vi,
  destroy_component: wi,
  detach: v0,
  element: w0,
  group_outros: vo,
  init: y0,
  insert: k0,
  mount_component: yi,
  safe_not_equal: E0,
  set_style: Ca,
  space: wo,
  toggle_class: Aa,
  transition_in: Me,
  transition_out: ot
} = window.__gradio__svelte__internal, { createEventDispatcher: S0 } = window.__gradio__svelte__internal;
function Ba(t) {
  let e, n;
  return e = new Fn({
    props: {
      Icon: $m,
      label: (
        /*i18n*/
        t[4]("common.edit")
      )
    }
  }), e.$on(
    "click",
    /*click_handler*/
    t[6]
  ), {
    c() {
      vi(e.$$.fragment);
    },
    m(i, l) {
      yi(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*i18n*/
      16 && (o.label = /*i18n*/
      i[4]("common.edit")), e.$set(o);
    },
    i(i) {
      n || (Me(e.$$.fragment, i), n = !0);
    },
    o(i) {
      ot(e.$$.fragment, i), n = !1;
    },
    d(i) {
      wi(e, i);
    }
  };
}
function La(t) {
  let e, n;
  return e = new Fn({
    props: {
      Icon: cr,
      label: (
        /*i18n*/
        t[4]("common.undo")
      )
    }
  }), e.$on(
    "click",
    /*click_handler_1*/
    t[7]
  ), {
    c() {
      vi(e.$$.fragment);
    },
    m(i, l) {
      yi(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*i18n*/
      16 && (o.label = /*i18n*/
      i[4]("common.undo")), e.$set(o);
    },
    i(i) {
      n || (Me(e.$$.fragment, i), n = !0);
    },
    o(i) {
      ot(e.$$.fragment, i), n = !1;
    },
    d(i) {
      wi(e, i);
    }
  };
}
function Na(t) {
  let e, n;
  return e = new qu({
    props: {
      href: (
        /*download*/
        t[2]
      ),
      download: !0,
      $$slots: { default: [T0] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      vi(e.$$.fragment);
    },
    m(i, l) {
      yi(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*download*/
      4 && (o.href = /*download*/
      i[2]), l & /*$$scope, i18n*/
      528 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (Me(e.$$.fragment, i), n = !0);
    },
    o(i) {
      ot(e.$$.fragment, i), n = !1;
    },
    d(i) {
      wi(e, i);
    }
  };
}
function T0(t) {
  let e, n;
  return e = new Fn({
    props: {
      Icon: Su,
      label: (
        /*i18n*/
        t[4]("common.download")
      )
    }
  }), {
    c() {
      vi(e.$$.fragment);
    },
    m(i, l) {
      yi(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*i18n*/
      16 && (o.label = /*i18n*/
      i[4]("common.download")), e.$set(o);
    },
    i(i) {
      n || (Me(e.$$.fragment, i), n = !0);
    },
    o(i) {
      ot(e.$$.fragment, i), n = !1;
    },
    d(i) {
      wi(e, i);
    }
  };
}
function C0(t) {
  let e, n, i, l, o, r, s = (
    /*editable*/
    t[0] && Ba(t)
  ), a = (
    /*undoable*/
    t[1] && La(t)
  ), u = (
    /*download*/
    t[2] && Na(t)
  );
  return o = new Fn({
    props: {
      Icon: Em,
      label: (
        /*i18n*/
        t[4]("common.clear")
      )
    }
  }), o.$on(
    "click",
    /*click_handler_2*/
    t[8]
  ), {
    c() {
      e = w0("div"), s && s.c(), n = wo(), a && a.c(), i = wo(), u && u.c(), l = wo(), vi(o.$$.fragment), b0(e, "class", "svelte-1wj0ocy"), Aa(e, "not-absolute", !/*absolute*/
      t[3]), Ca(
        e,
        "position",
        /*absolute*/
        t[3] ? "absolute" : "static"
      );
    },
    m(c, f) {
      k0(c, e, f), s && s.m(e, null), go(e, n), a && a.m(e, null), go(e, i), u && u.m(e, null), go(e, l), yi(o, e, null), r = !0;
    },
    p(c, [f]) {
      /*editable*/
      c[0] ? s ? (s.p(c, f), f & /*editable*/
      1 && Me(s, 1)) : (s = Ba(c), s.c(), Me(s, 1), s.m(e, n)) : s && (vo(), ot(s, 1, 1, () => {
        s = null;
      }), bo()), /*undoable*/
      c[1] ? a ? (a.p(c, f), f & /*undoable*/
      2 && Me(a, 1)) : (a = La(c), a.c(), Me(a, 1), a.m(e, i)) : a && (vo(), ot(a, 1, 1, () => {
        a = null;
      }), bo()), /*download*/
      c[2] ? u ? (u.p(c, f), f & /*download*/
      4 && Me(u, 1)) : (u = Na(c), u.c(), Me(u, 1), u.m(e, l)) : u && (vo(), ot(u, 1, 1, () => {
        u = null;
      }), bo());
      const d = {};
      f & /*i18n*/
      16 && (d.label = /*i18n*/
      c[4]("common.clear")), o.$set(d), (!r || f & /*absolute*/
      8) && Aa(e, "not-absolute", !/*absolute*/
      c[3]), f & /*absolute*/
      8 && Ca(
        e,
        "position",
        /*absolute*/
        c[3] ? "absolute" : "static"
      );
    },
    i(c) {
      r || (Me(s), Me(a), Me(u), Me(o.$$.fragment, c), r = !0);
    },
    o(c) {
      ot(s), ot(a), ot(u), ot(o.$$.fragment, c), r = !1;
    },
    d(c) {
      c && v0(e), s && s.d(), a && a.d(), u && u.d(), wi(o);
    }
  };
}
function A0(t, e, n) {
  let { editable: i = !1 } = e, { undoable: l = !1 } = e, { download: o = null } = e, { absolute: r = !0 } = e, { i18n: s } = e;
  const a = S0(), u = () => a("edit"), c = () => a("undo"), f = (d) => {
    a("clear"), d.stopPropagation();
  };
  return t.$$set = (d) => {
    "editable" in d && n(0, i = d.editable), "undoable" in d && n(1, l = d.undoable), "download" in d && n(2, o = d.download), "absolute" in d && n(3, r = d.absolute), "i18n" in d && n(4, s = d.i18n);
  }, [
    i,
    l,
    o,
    r,
    s,
    a,
    u,
    c,
    f
  ];
}
class B0 extends g0 {
  constructor(e) {
    super(), y0(this, e, A0, C0, E0, {
      editable: 0,
      undoable: 1,
      download: 2,
      absolute: 3,
      i18n: 4
    });
  }
}
const {
  SvelteComponent: L0,
  append: Li,
  attr: yo,
  create_component: N0,
  destroy_component: I0,
  detach: H0,
  element: ko,
  init: P0,
  insert: R0,
  listen: O0,
  mount_component: D0,
  noop: j0,
  safe_not_equal: M0,
  set_style: x0,
  space: U0,
  text: q0,
  transition_in: F0,
  transition_out: G0
} = window.__gradio__svelte__internal, { createEventDispatcher: V0 } = window.__gradio__svelte__internal;
function z0(t) {
  let e, n, i, l, o, r = "Click to Access Webcam", s, a, u, c;
  return l = new Bu({}), {
    c() {
      e = ko("button"), n = ko("div"), i = ko("span"), N0(l.$$.fragment), o = U0(), s = q0(r), yo(i, "class", "icon-wrap svelte-fjcd9c"), yo(n, "class", "wrap svelte-fjcd9c"), yo(e, "class", "svelte-fjcd9c"), x0(e, "height", "100%");
    },
    m(f, d) {
      R0(f, e, d), Li(e, n), Li(n, i), D0(l, i, null), Li(n, o), Li(n, s), a = !0, u || (c = O0(
        e,
        "click",
        /*click_handler*/
        t[1]
      ), u = !0);
    },
    p: j0,
    i(f) {
      a || (F0(l.$$.fragment, f), a = !0);
    },
    o(f) {
      G0(l.$$.fragment, f), a = !1;
    },
    d(f) {
      f && H0(e), I0(l), u = !1, c();
    }
  };
}
function X0(t) {
  const e = V0();
  return [e, () => e("click")];
}
class W0 extends L0 {
  constructor(e) {
    super(), P0(this, e, X0, z0, M0, {});
  }
}
const {
  SvelteComponent: Z0,
  action_destroyer: J0,
  add_render_callback: Q0,
  append: Ct,
  attr: fe,
  binding_callbacks: Y0,
  check_outros: si,
  create_component: zn,
  create_in_transition: K0,
  destroy_component: Xn,
  destroy_each: $0,
  detach: Ge,
  element: Je,
  empty: pr,
  ensure_array_like: Ia,
  group_outros: ui,
  init: eg,
  insert: Ve,
  listen: yl,
  mount_component: Wn,
  noop: gr,
  run_all: tg,
  safe_not_equal: ng,
  set_data: Fu,
  set_input_value: Jo,
  space: _i,
  stop_propagation: ig,
  text: Gu,
  toggle_class: Ni,
  transition_in: he,
  transition_out: Ce
} = window.__gradio__svelte__internal, { createEventDispatcher: lg, onMount: og } = window.__gradio__svelte__internal;
function Ha(t, e, n) {
  const i = t.slice();
  return i[31] = e[n], i;
}
function rg(t) {
  let e, n, i, l, o, r, s, a, u, c, f;
  const d = [ug, sg], _ = [];
  function m(v, y) {
    return (
      /*mode*/
      v[1] === "video" || /*streaming*/
      v[0] ? 0 : 1
    );
  }
  i = m(t), l = _[i] = d[i](t);
  let h = !/*recording*/
  t[6] && Pa(t), p = (
    /*options_open*/
    t[9] && Ra(t)
  );
  return {
    c() {
      e = Je("div"), n = Je("button"), l.c(), r = _i(), h && h.c(), s = _i(), p && p.c(), a = pr(), fe(n, "aria-label", o = /*mode*/
      t[1] === "image" ? "capture photo" : "start recording"), fe(n, "class", "svelte-8hqvb6"), fe(e, "class", "button-wrap svelte-8hqvb6");
    },
    m(v, y) {
      Ve(v, e, y), Ct(e, n), _[i].m(n, null), Ct(e, r), h && h.m(e, null), Ve(v, s, y), p && p.m(v, y), Ve(v, a, y), u = !0, c || (f = yl(
        n,
        "click",
        /*record_video_or_photo*/
        t[11]
      ), c = !0);
    },
    p(v, y) {
      let w = i;
      i = m(v), i === w ? _[i].p(v, y) : (ui(), Ce(_[w], 1, 1, () => {
        _[w] = null;
      }), si(), l = _[i], l ? l.p(v, y) : (l = _[i] = d[i](v), l.c()), he(l, 1), l.m(n, null)), (!u || y[0] & /*mode*/
      2 && o !== (o = /*mode*/
      v[1] === "image" ? "capture photo" : "start recording")) && fe(n, "aria-label", o), /*recording*/
      v[6] ? h && (ui(), Ce(h, 1, 1, () => {
        h = null;
      }), si()) : h ? (h.p(v, y), y[0] & /*recording*/
      64 && he(h, 1)) : (h = Pa(v), h.c(), he(h, 1), h.m(e, null)), /*options_open*/
      v[9] ? p ? (p.p(v, y), y[0] & /*options_open*/
      512 && he(p, 1)) : (p = Ra(v), p.c(), he(p, 1), p.m(a.parentNode, a)) : p && (ui(), Ce(p, 1, 1, () => {
        p = null;
      }), si());
    },
    i(v) {
      u || (he(l), he(h), he(p), u = !0);
    },
    o(v) {
      Ce(l), Ce(h), Ce(p), u = !1;
    },
    d(v) {
      v && (Ge(e), Ge(s), Ge(a)), _[i].d(), h && h.d(), p && p.d(v), c = !1, f();
    }
  };
}
function ag(t) {
  let e, n, i, l;
  return n = new W0({}), n.$on(
    "click",
    /*click_handler*/
    t[19]
  ), {
    c() {
      e = Je("div"), zn(n.$$.fragment), fe(e, "title", "grant webcam access");
    },
    m(o, r) {
      Ve(o, e, r), Wn(n, e, null), l = !0;
    },
    p: gr,
    i(o) {
      l || (he(n.$$.fragment, o), o && (i || Q0(() => {
        i = K0(e, Ic, { delay: 100, duration: 200 }), i.start();
      })), l = !0);
    },
    o(o) {
      Ce(n.$$.fragment, o), l = !1;
    },
    d(o) {
      o && Ge(e), Xn(n);
    }
  };
}
function sg(t) {
  let e, n, i;
  return n = new sm({}), {
    c() {
      e = Je("div"), zn(n.$$.fragment), fe(e, "class", "icon svelte-8hqvb6"), fe(e, "title", "capture photo");
    },
    m(l, o) {
      Ve(l, e, o), Wn(n, e, null), i = !0;
    },
    p: gr,
    i(l) {
      i || (he(n.$$.fragment, l), i = !0);
    },
    o(l) {
      Ce(n.$$.fragment, l), i = !1;
    },
    d(l) {
      l && Ge(e), Xn(n);
    }
  };
}
function ug(t) {
  let e, n, i, l;
  const o = [fg, cg], r = [];
  function s(a, u) {
    return (
      /*recording*/
      a[6] ? 0 : 1
    );
  }
  return e = s(t), n = r[e] = o[e](t), {
    c() {
      n.c(), i = pr();
    },
    m(a, u) {
      r[e].m(a, u), Ve(a, i, u), l = !0;
    },
    p(a, u) {
      let c = e;
      e = s(a), e !== c && (ui(), Ce(r[c], 1, 1, () => {
        r[c] = null;
      }), si(), n = r[e], n || (n = r[e] = o[e](a), n.c()), he(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (he(n), l = !0);
    },
    o(a) {
      Ce(n), l = !1;
    },
    d(a) {
      a && Ge(i), r[e].d(a);
    }
  };
}
function cg(t) {
  let e, n, i;
  return n = new pm({}), {
    c() {
      e = Je("div"), zn(n.$$.fragment), fe(e, "class", "icon red svelte-8hqvb6"), fe(e, "title", "start recording");
    },
    m(l, o) {
      Ve(l, e, o), Wn(n, e, null), i = !0;
    },
    i(l) {
      i || (he(n.$$.fragment, l), i = !0);
    },
    o(l) {
      Ce(n.$$.fragment, l), i = !1;
    },
    d(l) {
      l && Ge(e), Xn(n);
    }
  };
}
function fg(t) {
  let e, n, i;
  return n = new Vh({}), {
    c() {
      e = Je("div"), zn(n.$$.fragment), fe(e, "class", "icon red svelte-8hqvb6"), fe(e, "title", "stop recording");
    },
    m(l, o) {
      Ve(l, e, o), Wn(n, e, null), i = !0;
    },
    i(l) {
      i || (he(n.$$.fragment, l), i = !0);
    },
    o(l) {
      Ce(n.$$.fragment, l), i = !1;
    },
    d(l) {
      l && Ge(e), Xn(n);
    }
  };
}
function Pa(t) {
  let e, n, i, l, o;
  return n = new Tu({}), {
    c() {
      e = Je("button"), zn(n.$$.fragment), fe(e, "class", "icon svelte-8hqvb6"), fe(e, "aria-label", "select input source");
    },
    m(r, s) {
      Ve(r, e, s), Wn(n, e, null), i = !0, l || (o = yl(
        e,
        "click",
        /*select_source*/
        t[12]
      ), l = !0);
    },
    p: gr,
    i(r) {
      i || (he(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Ce(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Ge(e), Xn(n), l = !1, o();
    }
  };
}
function Ra(t) {
  let e, n, i, l, o, r, s;
  i = new Tu({});
  function a(f, d) {
    return (
      /*video_sources*/
      f[8].length === 0 ? _g : dg
    );
  }
  let u = a(t), c = u(t);
  return {
    c() {
      e = Je("select"), n = Je("button"), zn(i.$$.fragment), l = _i(), c.c(), fe(n, "class", "inset-icon svelte-8hqvb6"), fe(e, "class", "select-wrap svelte-8hqvb6"), fe(e, "aria-label", "select source");
    },
    m(f, d) {
      Ve(f, e, d), Ct(e, n), Wn(i, n, null), Ct(n, l), c.m(e, null), o = !0, r || (s = [
        yl(n, "click", ig(
          /*click_handler_1*/
          t[20]
        )),
        J0(br.call(
          null,
          e,
          /*handle_click_outside*/
          t[14]
        ))
      ], r = !0);
    },
    p(f, d) {
      u === (u = a(f)) && c ? c.p(f, d) : (c.d(1), c = u(f), c && (c.c(), c.m(e, null)));
    },
    i(f) {
      o || (he(i.$$.fragment, f), o = !0);
    },
    o(f) {
      Ce(i.$$.fragment, f), o = !1;
    },
    d(f) {
      f && Ge(e), Xn(i), c.d(), r = !1, tg(s);
    }
  };
}
function dg(t) {
  let e, n = Ia(
    /*video_sources*/
    t[8]
  ), i = [];
  for (let l = 0; l < n.length; l += 1)
    i[l] = Oa(Ha(t, n, l));
  return {
    c() {
      for (let l = 0; l < i.length; l += 1)
        i[l].c();
      e = pr();
    },
    m(l, o) {
      for (let r = 0; r < i.length; r += 1)
        i[r] && i[r].m(l, o);
      Ve(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*video_sources, selectVideoSource*/
      8448) {
        n = Ia(
          /*video_sources*/
          l[8]
        );
        let r;
        for (r = 0; r < n.length; r += 1) {
          const s = Ha(l, n, r);
          i[r] ? i[r].p(s, o) : (i[r] = Oa(s), i[r].c(), i[r].m(e.parentNode, e));
        }
        for (; r < i.length; r += 1)
          i[r].d(1);
        i.length = n.length;
      }
    },
    d(l) {
      l && Ge(e), $0(i, l);
    }
  };
}
function _g(t) {
  let e, n = (
    /*i18n*/
    t[3]("common.no_devices") + ""
  ), i;
  return {
    c() {
      e = Je("option"), i = Gu(n), e.__value = "", Jo(e, e.__value), fe(e, "class", "svelte-8hqvb6");
    },
    m(l, o) {
      Ve(l, e, o), Ct(e, i);
    },
    p(l, o) {
      o[0] & /*i18n*/
      8 && n !== (n = /*i18n*/
      l[3]("common.no_devices") + "") && Fu(i, n);
    },
    d(l) {
      l && Ge(e);
    }
  };
}
function Oa(t) {
  let e, n = (
    /*source*/
    t[31].label + ""
  ), i, l, o, r, s;
  function a() {
    return (
      /*click_handler_2*/
      t[21](
        /*source*/
        t[31]
      )
    );
  }
  return {
    c() {
      e = Je("option"), i = Gu(n), l = _i(), e.__value = o = `
							` + /*source*/
      t[31].label + `
						`, Jo(e, e.__value), fe(e, "class", "svelte-8hqvb6");
    },
    m(u, c) {
      Ve(u, e, c), Ct(e, i), Ct(e, l), r || (s = yl(e, "click", a), r = !0);
    },
    p(u, c) {
      t = u, c[0] & /*video_sources*/
      256 && n !== (n = /*source*/
      t[31].label + "") && Fu(i, n), c[0] & /*video_sources*/
      256 && o !== (o = `
							` + /*source*/
      t[31].label + `
						`) && (e.__value = o, Jo(e, e.__value));
    },
    d(u) {
      u && Ge(e), r = !1, s();
    }
  };
}
function mg(t) {
  let e, n, i, l, o, r;
  const s = [ag, rg], a = [];
  function u(c, f) {
    return (
      /*webcam_accessed*/
      c[7] ? 1 : 0
    );
  }
  return l = u(t), o = a[l] = s[l](t), {
    c() {
      e = Je("div"), n = Je("video"), i = _i(), o.c(), fe(n, "class", "svelte-8hqvb6"), Ni(
        n,
        "flip",
        /*mirror_webcam*/
        t[2]
      ), Ni(n, "hide", !/*webcam_accessed*/
      t[7]), fe(e, "class", "wrap svelte-8hqvb6");
    },
    m(c, f) {
      Ve(c, e, f), Ct(e, n), t[18](n), Ct(e, i), a[l].m(e, null), r = !0;
    },
    p(c, f) {
      (!r || f[0] & /*mirror_webcam*/
      4) && Ni(
        n,
        "flip",
        /*mirror_webcam*/
        c[2]
      ), (!r || f[0] & /*webcam_accessed*/
      128) && Ni(n, "hide", !/*webcam_accessed*/
      c[7]);
      let d = l;
      l = u(c), l === d ? a[l].p(c, f) : (ui(), Ce(a[d], 1, 1, () => {
        a[d] = null;
      }), si(), o = a[l], o ? o.p(c, f) : (o = a[l] = s[l](c), o.c()), he(o, 1), o.m(e, null));
    },
    i(c) {
      r || (he(o), r = !0);
    },
    o(c) {
      Ce(o), r = !1;
    },
    d(c) {
      c && Ge(e), t[18](null), a[l].d();
    }
  };
}
async function hg(t) {
  let e, n = t[0], i = 1;
  for (; i < t.length; ) {
    const l = t[i], o = t[i + 1];
    if (i += 2, (l === "optionalAccess" || l === "optionalCall") && n == null)
      return;
    l === "access" || l === "optionalAccess" ? (e = n, n = await o(n)) : (l === "call" || l === "optionalCall") && (n = await o((...r) => n.call(e, ...r)), e = void 0);
  }
  return n;
}
function br(t, e) {
  const n = (i) => {
    t && !t.contains(i.target) && !i.defaultPrevented && e(i);
  };
  return document.addEventListener("click", n, !0), {
    destroy() {
      document.removeEventListener("click", n, !0);
    }
  };
}
function pg(t, e, n) {
  let i, l, { streaming: o = !1 } = e, { pending: r = !1 } = e, { root: s = "" } = e, { mode: a = "image" } = e, { mirror_webcam: u } = e, { include_audio: c } = e, { i18n: f } = e;
  const d = lg();
  og(() => l = document.createElement("canvas"));
  const _ = {
    width: { ideal: 1920 },
    height: { ideal: 1440 }
  };
  async function m(N) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      d("error", f("image.no_webcam_support"));
      return;
    }
    try {
      y = await navigator.mediaDevices.getUserMedia({
        video: N ? { deviceId: { exact: N }, ..._ } : _,
        audio: c
      }), n(5, i.srcObject = y, i), n(5, i.muted = !0, i), i.play(), n(7, b = !0);
    } catch (S) {
      if (S instanceof DOMException && S.name == "NotAllowedError")
        d("error", f("image.allow_webcam_access"));
      else
        throw S;
    }
  }
  function h() {
    var N = l.getContext("2d");
    (!o || o && p) && i.videoWidth && i.videoHeight && (l.width = i.videoWidth, l.height = i.videoHeight, N.drawImage(i, 0, 0, i.videoWidth, i.videoHeight), u && (N.scale(-1, 1), N.drawImage(i, -i.videoWidth, 0)), l.toBlob(
      (S) => {
        d(o ? "stream" : "capture", S);
      },
      "image/png",
      0.8
    ));
  }
  let p = !1, v = [], y, w, B;
  function k() {
    if (p) {
      B.stop();
      let N = new Blob(v, { type: w }), S = new FileReader();
      S.onload = async function(pe) {
        if (pe.target) {
          let P = new File([N], "sample." + w.substring(6));
          const J = await lr([P]);
          let Z = (await hg([
            await ir(J, s),
            "optionalAccess",
            async (g) => g.filter,
            "call",
            async (g) => g(Boolean)
          ]))[0];
          d("capture", Z), d("stop_recording");
        }
      }, S.readAsDataURL(N);
    } else {
      d("start_recording"), v = [];
      let N = ["video/webm", "video/mp4"];
      for (let S of N)
        if (MediaRecorder.isTypeSupported(S)) {
          w = S;
          break;
        }
      if (w === null) {
        console.error("No supported MediaRecorder mimeType");
        return;
      }
      B = new MediaRecorder(y, { mimeType: w }), B.addEventListener("dataavailable", function(S) {
        v.push(S.data);
      }), B.start(200);
    }
    n(6, p = !p);
  }
  let b = !1;
  function C() {
    a === "image" && o && n(6, p = !p), a === "image" ? h() : k(), !p && y && (y.getTracks().forEach((N) => N.stop()), n(5, i.srcObject = null, i), n(7, b = !1));
  }
  o && a === "image" && window.setInterval(
    () => {
      i && !r && h();
    },
    500
  );
  async function H() {
    const N = await navigator.mediaDevices.enumerateDevices();
    n(8, R = N.filter((S) => S.kind === "videoinput")), n(9, z = !0);
  }
  let R = [];
  async function x(N) {
    await m(N), n(9, z = !1);
  }
  let z = !1;
  function q(N) {
    N.preventDefault(), N.stopPropagation(), n(9, z = !1);
  }
  function F(N) {
    Y0[N ? "unshift" : "push"](() => {
      i = N, n(5, i);
    });
  }
  const re = async () => m(), A = () => n(9, z = !1), ae = (N) => x(N.deviceId);
  return t.$$set = (N) => {
    "streaming" in N && n(0, o = N.streaming), "pending" in N && n(15, r = N.pending), "root" in N && n(16, s = N.root), "mode" in N && n(1, a = N.mode), "mirror_webcam" in N && n(2, u = N.mirror_webcam), "include_audio" in N && n(17, c = N.include_audio), "i18n" in N && n(3, f = N.i18n);
  }, [
    o,
    a,
    u,
    f,
    br,
    i,
    p,
    b,
    R,
    z,
    m,
    C,
    H,
    x,
    q,
    r,
    s,
    c,
    F,
    re,
    A,
    ae
  ];
}
class gg extends Z0 {
  constructor(e) {
    super(), eg(
      this,
      e,
      pg,
      mg,
      ng,
      {
        streaming: 0,
        pending: 15,
        root: 16,
        mode: 1,
        mirror_webcam: 2,
        include_audio: 17,
        i18n: 3,
        click_outside: 4
      },
      null,
      [-1, -1]
    );
  }
  get click_outside() {
    return br;
  }
}
function Tn(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; t > 1e3 && n < e.length - 1; )
    t /= 1e3, n++;
  let i = e[n];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + i;
}
const {
  SvelteComponent: bg,
  append: it,
  attr: V,
  component_subscribe: Da,
  detach: vg,
  element: wg,
  init: yg,
  insert: kg,
  noop: ja,
  safe_not_equal: Eg,
  set_style: Ii,
  svg_element: lt,
  toggle_class: Ma
} = window.__gradio__svelte__internal, { onMount: Sg } = window.__gradio__svelte__internal;
function Tg(t) {
  let e, n, i, l, o, r, s, a, u, c, f, d;
  return {
    c() {
      e = wg("div"), n = lt("svg"), i = lt("g"), l = lt("path"), o = lt("path"), r = lt("path"), s = lt("path"), a = lt("g"), u = lt("path"), c = lt("path"), f = lt("path"), d = lt("path"), V(l, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), V(l, "fill", "#FF7C00"), V(l, "fill-opacity", "0.4"), V(l, "class", "svelte-43sxxs"), V(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), V(o, "fill", "#FF7C00"), V(o, "class", "svelte-43sxxs"), V(r, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), V(r, "fill", "#FF7C00"), V(r, "fill-opacity", "0.4"), V(r, "class", "svelte-43sxxs"), V(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), V(s, "fill", "#FF7C00"), V(s, "class", "svelte-43sxxs"), Ii(i, "transform", "translate(" + /*$top*/
      t[1][0] + "px, " + /*$top*/
      t[1][1] + "px)"), V(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), V(u, "fill", "#FF7C00"), V(u, "fill-opacity", "0.4"), V(u, "class", "svelte-43sxxs"), V(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), V(c, "fill", "#FF7C00"), V(c, "class", "svelte-43sxxs"), V(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), V(f, "fill", "#FF7C00"), V(f, "fill-opacity", "0.4"), V(f, "class", "svelte-43sxxs"), V(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), V(d, "fill", "#FF7C00"), V(d, "class", "svelte-43sxxs"), Ii(a, "transform", "translate(" + /*$bottom*/
      t[2][0] + "px, " + /*$bottom*/
      t[2][1] + "px)"), V(n, "viewBox", "-1200 -1200 3000 3000"), V(n, "fill", "none"), V(n, "xmlns", "http://www.w3.org/2000/svg"), V(n, "class", "svelte-43sxxs"), V(e, "class", "svelte-43sxxs"), Ma(
        e,
        "margin",
        /*margin*/
        t[0]
      );
    },
    m(_, m) {
      kg(_, e, m), it(e, n), it(n, i), it(i, l), it(i, o), it(i, r), it(i, s), it(n, a), it(a, u), it(a, c), it(a, f), it(a, d);
    },
    p(_, [m]) {
      m & /*$top*/
      2 && Ii(i, "transform", "translate(" + /*$top*/
      _[1][0] + "px, " + /*$top*/
      _[1][1] + "px)"), m & /*$bottom*/
      4 && Ii(a, "transform", "translate(" + /*$bottom*/
      _[2][0] + "px, " + /*$bottom*/
      _[2][1] + "px)"), m & /*margin*/
      1 && Ma(
        e,
        "margin",
        /*margin*/
        _[0]
      );
    },
    i: ja,
    o: ja,
    d(_) {
      _ && vg(e);
    }
  };
}
function Cg(t, e, n) {
  let i, l, { margin: o = !0 } = e;
  const r = Pr([0, 0]);
  Da(t, r, (d) => n(1, i = d));
  const s = Pr([0, 0]);
  Da(t, s, (d) => n(2, l = d));
  let a;
  async function u() {
    await Promise.all([r.set([125, 140]), s.set([-125, -140])]), await Promise.all([r.set([-125, 140]), s.set([125, -140])]), await Promise.all([r.set([-125, 0]), s.set([125, -0])]), await Promise.all([r.set([125, 0]), s.set([-125, 0])]);
  }
  async function c() {
    await u(), a || c();
  }
  async function f() {
    await Promise.all([r.set([125, 0]), s.set([-125, 0])]), c();
  }
  return Sg(() => (f(), () => a = !0)), t.$$set = (d) => {
    "margin" in d && n(0, o = d.margin);
  }, [o, i, l, r, s];
}
class Ag extends bg {
  constructor(e) {
    super(), yg(this, e, Cg, Tg, Eg, { margin: 0 });
  }
}
const {
  SvelteComponent: Bg,
  append: Yt,
  attr: mt,
  binding_callbacks: xa,
  check_outros: Vu,
  create_component: Lg,
  create_slot: Ng,
  destroy_component: Ig,
  destroy_each: zu,
  detach: O,
  element: Et,
  empty: Zn,
  ensure_array_like: tl,
  get_all_dirty_from_scope: Hg,
  get_slot_changes: Pg,
  group_outros: Xu,
  init: Rg,
  insert: D,
  mount_component: Og,
  noop: Qo,
  safe_not_equal: Dg,
  set_data: $e,
  set_style: jt,
  space: ht,
  text: oe,
  toggle_class: Ke,
  transition_in: Hn,
  transition_out: Pn,
  update_slot_base: jg
} = window.__gradio__svelte__internal, { tick: Mg } = window.__gradio__svelte__internal, { onDestroy: xg } = window.__gradio__svelte__internal, Ug = (t) => ({}), Ua = (t) => ({});
function qa(t, e, n) {
  const i = t.slice();
  return i[38] = e[n], i[40] = n, i;
}
function Fa(t, e, n) {
  const i = t.slice();
  return i[38] = e[n], i;
}
function qg(t) {
  let e, n = (
    /*i18n*/
    t[1]("common.error") + ""
  ), i, l, o;
  const r = (
    /*#slots*/
    t[29].error
  ), s = Ng(
    r,
    t,
    /*$$scope*/
    t[28],
    Ua
  );
  return {
    c() {
      e = Et("span"), i = oe(n), l = ht(), s && s.c(), mt(e, "class", "error svelte-1yserjw");
    },
    m(a, u) {
      D(a, e, u), Yt(e, i), D(a, l, u), s && s.m(a, u), o = !0;
    },
    p(a, u) {
      (!o || u[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      a[1]("common.error") + "") && $e(i, n), s && s.p && (!o || u[0] & /*$$scope*/
      268435456) && jg(
        s,
        r,
        a,
        /*$$scope*/
        a[28],
        o ? Pg(
          r,
          /*$$scope*/
          a[28],
          u,
          Ug
        ) : Hg(
          /*$$scope*/
          a[28]
        ),
        Ua
      );
    },
    i(a) {
      o || (Hn(s, a), o = !0);
    },
    o(a) {
      Pn(s, a), o = !1;
    },
    d(a) {
      a && (O(e), O(l)), s && s.d(a);
    }
  };
}
function Fg(t) {
  let e, n, i, l, o, r, s, a, u, c = (
    /*variant*/
    t[8] === "default" && /*show_eta_bar*/
    t[18] && /*show_progress*/
    t[6] === "full" && Ga(t)
  );
  function f(w, B) {
    if (
      /*progress*/
      w[7]
    )
      return zg;
    if (
      /*queue_position*/
      w[2] !== null && /*queue_size*/
      w[3] !== void 0 && /*queue_position*/
      w[2] >= 0
    )
      return Vg;
    if (
      /*queue_position*/
      w[2] === 0
    )
      return Gg;
  }
  let d = f(t), _ = d && d(t), m = (
    /*timer*/
    t[5] && Xa(t)
  );
  const h = [Jg, Zg], p = [];
  function v(w, B) {
    return (
      /*last_progress_level*/
      w[15] != null ? 0 : (
        /*show_progress*/
        w[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = v(t)) && (r = p[o] = h[o](t));
  let y = !/*timer*/
  t[5] && $a(t);
  return {
    c() {
      c && c.c(), e = ht(), n = Et("div"), _ && _.c(), i = ht(), m && m.c(), l = ht(), r && r.c(), s = ht(), y && y.c(), a = Zn(), mt(n, "class", "progress-text svelte-1yserjw"), Ke(
        n,
        "meta-text-center",
        /*variant*/
        t[8] === "center"
      ), Ke(
        n,
        "meta-text",
        /*variant*/
        t[8] === "default"
      );
    },
    m(w, B) {
      c && c.m(w, B), D(w, e, B), D(w, n, B), _ && _.m(n, null), Yt(n, i), m && m.m(n, null), D(w, l, B), ~o && p[o].m(w, B), D(w, s, B), y && y.m(w, B), D(w, a, B), u = !0;
    },
    p(w, B) {
      /*variant*/
      w[8] === "default" && /*show_eta_bar*/
      w[18] && /*show_progress*/
      w[6] === "full" ? c ? c.p(w, B) : (c = Ga(w), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = f(w)) && _ ? _.p(w, B) : (_ && _.d(1), _ = d && d(w), _ && (_.c(), _.m(n, i))), /*timer*/
      w[5] ? m ? m.p(w, B) : (m = Xa(w), m.c(), m.m(n, null)) : m && (m.d(1), m = null), (!u || B[0] & /*variant*/
      256) && Ke(
        n,
        "meta-text-center",
        /*variant*/
        w[8] === "center"
      ), (!u || B[0] & /*variant*/
      256) && Ke(
        n,
        "meta-text",
        /*variant*/
        w[8] === "default"
      );
      let k = o;
      o = v(w), o === k ? ~o && p[o].p(w, B) : (r && (Xu(), Pn(p[k], 1, 1, () => {
        p[k] = null;
      }), Vu()), ~o ? (r = p[o], r ? r.p(w, B) : (r = p[o] = h[o](w), r.c()), Hn(r, 1), r.m(s.parentNode, s)) : r = null), /*timer*/
      w[5] ? y && (y.d(1), y = null) : y ? y.p(w, B) : (y = $a(w), y.c(), y.m(a.parentNode, a));
    },
    i(w) {
      u || (Hn(r), u = !0);
    },
    o(w) {
      Pn(r), u = !1;
    },
    d(w) {
      w && (O(e), O(n), O(l), O(s), O(a)), c && c.d(w), _ && _.d(), m && m.d(), ~o && p[o].d(w), y && y.d(w);
    }
  };
}
function Ga(t) {
  let e, n = `translateX(${/*eta_level*/
  (t[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Et("div"), mt(e, "class", "eta-bar svelte-1yserjw"), jt(e, "transform", n);
    },
    m(i, l) {
      D(i, e, l);
    },
    p(i, l) {
      l[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && jt(e, "transform", n);
    },
    d(i) {
      i && O(e);
    }
  };
}
function Gg(t) {
  let e;
  return {
    c() {
      e = oe("processing |");
    },
    m(n, i) {
      D(n, e, i);
    },
    p: Qo,
    d(n) {
      n && O(e);
    }
  };
}
function Vg(t) {
  let e, n = (
    /*queue_position*/
    t[2] + 1 + ""
  ), i, l, o, r;
  return {
    c() {
      e = oe("queue: "), i = oe(n), l = oe("/"), o = oe(
        /*queue_size*/
        t[3]
      ), r = oe(" |");
    },
    m(s, a) {
      D(s, e, a), D(s, i, a), D(s, l, a), D(s, o, a), D(s, r, a);
    },
    p(s, a) {
      a[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      s[2] + 1 + "") && $e(i, n), a[0] & /*queue_size*/
      8 && $e(
        o,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (O(e), O(i), O(l), O(o), O(r));
    }
  };
}
function zg(t) {
  let e, n = tl(
    /*progress*/
    t[7]
  ), i = [];
  for (let l = 0; l < n.length; l += 1)
    i[l] = za(Fa(t, n, l));
  return {
    c() {
      for (let l = 0; l < i.length; l += 1)
        i[l].c();
      e = Zn();
    },
    m(l, o) {
      for (let r = 0; r < i.length; r += 1)
        i[r] && i[r].m(l, o);
      D(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress*/
      128) {
        n = tl(
          /*progress*/
          l[7]
        );
        let r;
        for (r = 0; r < n.length; r += 1) {
          const s = Fa(l, n, r);
          i[r] ? i[r].p(s, o) : (i[r] = za(s), i[r].c(), i[r].m(e.parentNode, e));
        }
        for (; r < i.length; r += 1)
          i[r].d(1);
        i.length = n.length;
      }
    },
    d(l) {
      l && O(e), zu(i, l);
    }
  };
}
function Va(t) {
  let e, n = (
    /*p*/
    t[38].unit + ""
  ), i, l, o = " ", r;
  function s(c, f) {
    return (
      /*p*/
      c[38].length != null ? Wg : Xg
    );
  }
  let a = s(t), u = a(t);
  return {
    c() {
      u.c(), e = ht(), i = oe(n), l = oe(" | "), r = oe(o);
    },
    m(c, f) {
      u.m(c, f), D(c, e, f), D(c, i, f), D(c, l, f), D(c, r, f);
    },
    p(c, f) {
      a === (a = s(c)) && u ? u.p(c, f) : (u.d(1), u = a(c), u && (u.c(), u.m(e.parentNode, e))), f[0] & /*progress*/
      128 && n !== (n = /*p*/
      c[38].unit + "") && $e(i, n);
    },
    d(c) {
      c && (O(e), O(i), O(l), O(r)), u.d(c);
    }
  };
}
function Xg(t) {
  let e = Tn(
    /*p*/
    t[38].index || 0
  ) + "", n;
  return {
    c() {
      n = oe(e);
    },
    m(i, l) {
      D(i, n, l);
    },
    p(i, l) {
      l[0] & /*progress*/
      128 && e !== (e = Tn(
        /*p*/
        i[38].index || 0
      ) + "") && $e(n, e);
    },
    d(i) {
      i && O(n);
    }
  };
}
function Wg(t) {
  let e = Tn(
    /*p*/
    t[38].index || 0
  ) + "", n, i, l = Tn(
    /*p*/
    t[38].length
  ) + "", o;
  return {
    c() {
      n = oe(e), i = oe("/"), o = oe(l);
    },
    m(r, s) {
      D(r, n, s), D(r, i, s), D(r, o, s);
    },
    p(r, s) {
      s[0] & /*progress*/
      128 && e !== (e = Tn(
        /*p*/
        r[38].index || 0
      ) + "") && $e(n, e), s[0] & /*progress*/
      128 && l !== (l = Tn(
        /*p*/
        r[38].length
      ) + "") && $e(o, l);
    },
    d(r) {
      r && (O(n), O(i), O(o));
    }
  };
}
function za(t) {
  let e, n = (
    /*p*/
    t[38].index != null && Va(t)
  );
  return {
    c() {
      n && n.c(), e = Zn();
    },
    m(i, l) {
      n && n.m(i, l), D(i, e, l);
    },
    p(i, l) {
      /*p*/
      i[38].index != null ? n ? n.p(i, l) : (n = Va(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && O(e), n && n.d(i);
    }
  };
}
function Xa(t) {
  let e, n = (
    /*eta*/
    t[0] ? `/${/*formatted_eta*/
    t[19]}` : ""
  ), i, l;
  return {
    c() {
      e = oe(
        /*formatted_timer*/
        t[20]
      ), i = oe(n), l = oe("s");
    },
    m(o, r) {
      D(o, e, r), D(o, i, r), D(o, l, r);
    },
    p(o, r) {
      r[0] & /*formatted_timer*/
      1048576 && $e(
        e,
        /*formatted_timer*/
        o[20]
      ), r[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && $e(i, n);
    },
    d(o) {
      o && (O(e), O(i), O(l));
    }
  };
}
function Zg(t) {
  let e, n;
  return e = new Ag({
    props: { margin: (
      /*variant*/
      t[8] === "default"
    ) }
  }), {
    c() {
      Lg(e.$$.fragment);
    },
    m(i, l) {
      Og(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*variant*/
      256 && (o.margin = /*variant*/
      i[8] === "default"), e.$set(o);
    },
    i(i) {
      n || (Hn(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Pn(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Ig(e, i);
    }
  };
}
function Jg(t) {
  let e, n, i, l, o, r = `${/*last_progress_level*/
  t[15] * 100}%`, s = (
    /*progress*/
    t[7] != null && Wa(t)
  );
  return {
    c() {
      e = Et("div"), n = Et("div"), s && s.c(), i = ht(), l = Et("div"), o = Et("div"), mt(n, "class", "progress-level-inner svelte-1yserjw"), mt(o, "class", "progress-bar svelte-1yserjw"), jt(o, "width", r), mt(l, "class", "progress-bar-wrap svelte-1yserjw"), mt(e, "class", "progress-level svelte-1yserjw");
    },
    m(a, u) {
      D(a, e, u), Yt(e, n), s && s.m(n, null), Yt(e, i), Yt(e, l), Yt(l, o), t[30](o);
    },
    p(a, u) {
      /*progress*/
      a[7] != null ? s ? s.p(a, u) : (s = Wa(a), s.c(), s.m(n, null)) : s && (s.d(1), s = null), u[0] & /*last_progress_level*/
      32768 && r !== (r = `${/*last_progress_level*/
      a[15] * 100}%`) && jt(o, "width", r);
    },
    i: Qo,
    o: Qo,
    d(a) {
      a && O(e), s && s.d(), t[30](null);
    }
  };
}
function Wa(t) {
  let e, n = tl(
    /*progress*/
    t[7]
  ), i = [];
  for (let l = 0; l < n.length; l += 1)
    i[l] = Ka(qa(t, n, l));
  return {
    c() {
      for (let l = 0; l < i.length; l += 1)
        i[l].c();
      e = Zn();
    },
    m(l, o) {
      for (let r = 0; r < i.length; r += 1)
        i[r] && i[r].m(l, o);
      D(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        n = tl(
          /*progress*/
          l[7]
        );
        let r;
        for (r = 0; r < n.length; r += 1) {
          const s = qa(l, n, r);
          i[r] ? i[r].p(s, o) : (i[r] = Ka(s), i[r].c(), i[r].m(e.parentNode, e));
        }
        for (; r < i.length; r += 1)
          i[r].d(1);
        i.length = n.length;
      }
    },
    d(l) {
      l && O(e), zu(i, l);
    }
  };
}
function Za(t) {
  let e, n, i, l, o = (
    /*i*/
    t[40] !== 0 && Qg()
  ), r = (
    /*p*/
    t[38].desc != null && Ja(t)
  ), s = (
    /*p*/
    t[38].desc != null && /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[40]
    ] != null && Qa()
  ), a = (
    /*progress_level*/
    t[14] != null && Ya(t)
  );
  return {
    c() {
      o && o.c(), e = ht(), r && r.c(), n = ht(), s && s.c(), i = ht(), a && a.c(), l = Zn();
    },
    m(u, c) {
      o && o.m(u, c), D(u, e, c), r && r.m(u, c), D(u, n, c), s && s.m(u, c), D(u, i, c), a && a.m(u, c), D(u, l, c);
    },
    p(u, c) {
      /*p*/
      u[38].desc != null ? r ? r.p(u, c) : (r = Ja(u), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*p*/
      u[38].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[40]
      ] != null ? s || (s = Qa(), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null), /*progress_level*/
      u[14] != null ? a ? a.p(u, c) : (a = Ya(u), a.c(), a.m(l.parentNode, l)) : a && (a.d(1), a = null);
    },
    d(u) {
      u && (O(e), O(n), O(i), O(l)), o && o.d(u), r && r.d(u), s && s.d(u), a && a.d(u);
    }
  };
}
function Qg(t) {
  let e;
  return {
    c() {
      e = oe(" /");
    },
    m(n, i) {
      D(n, e, i);
    },
    d(n) {
      n && O(e);
    }
  };
}
function Ja(t) {
  let e = (
    /*p*/
    t[38].desc + ""
  ), n;
  return {
    c() {
      n = oe(e);
    },
    m(i, l) {
      D(i, n, l);
    },
    p(i, l) {
      l[0] & /*progress*/
      128 && e !== (e = /*p*/
      i[38].desc + "") && $e(n, e);
    },
    d(i) {
      i && O(n);
    }
  };
}
function Qa(t) {
  let e;
  return {
    c() {
      e = oe("-");
    },
    m(n, i) {
      D(n, e, i);
    },
    d(n) {
      n && O(e);
    }
  };
}
function Ya(t) {
  let e = (100 * /*progress_level*/
  (t[14][
    /*i*/
    t[40]
  ] || 0)).toFixed(1) + "", n, i;
  return {
    c() {
      n = oe(e), i = oe("%");
    },
    m(l, o) {
      D(l, n, o), D(l, i, o);
    },
    p(l, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (l[14][
        /*i*/
        l[40]
      ] || 0)).toFixed(1) + "") && $e(n, e);
    },
    d(l) {
      l && (O(n), O(i));
    }
  };
}
function Ka(t) {
  let e, n = (
    /*p*/
    (t[38].desc != null || /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[40]
    ] != null) && Za(t)
  );
  return {
    c() {
      n && n.c(), e = Zn();
    },
    m(i, l) {
      n && n.m(i, l), D(i, e, l);
    },
    p(i, l) {
      /*p*/
      i[38].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[40]
      ] != null ? n ? n.p(i, l) : (n = Za(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && O(e), n && n.d(i);
    }
  };
}
function $a(t) {
  let e, n;
  return {
    c() {
      e = Et("p"), n = oe(
        /*loading_text*/
        t[9]
      ), mt(e, "class", "loading svelte-1yserjw");
    },
    m(i, l) {
      D(i, e, l), Yt(e, n);
    },
    p(i, l) {
      l[0] & /*loading_text*/
      512 && $e(
        n,
        /*loading_text*/
        i[9]
      );
    },
    d(i) {
      i && O(e);
    }
  };
}
function Yg(t) {
  let e, n, i, l, o;
  const r = [Fg, qg], s = [];
  function a(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = a(t)) && (i = s[n] = r[n](t)), {
    c() {
      e = Et("div"), i && i.c(), mt(e, "class", l = "wrap " + /*variant*/
      t[8] + " " + /*show_progress*/
      t[6] + " svelte-1yserjw"), Ke(e, "hide", !/*status*/
      t[4] || /*status*/
      t[4] === "complete" || /*show_progress*/
      t[6] === "hidden"), Ke(
        e,
        "translucent",
        /*variant*/
        t[8] === "center" && /*status*/
        (t[4] === "pending" || /*status*/
        t[4] === "error") || /*translucent*/
        t[11] || /*show_progress*/
        t[6] === "minimal"
      ), Ke(
        e,
        "generating",
        /*status*/
        t[4] === "generating"
      ), Ke(
        e,
        "border",
        /*border*/
        t[12]
      ), jt(
        e,
        "position",
        /*absolute*/
        t[10] ? "absolute" : "static"
      ), jt(
        e,
        "padding",
        /*absolute*/
        t[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      D(u, e, c), ~n && s[n].m(e, null), t[31](e), o = !0;
    },
    p(u, c) {
      let f = n;
      n = a(u), n === f ? ~n && s[n].p(u, c) : (i && (Xu(), Pn(s[f], 1, 1, () => {
        s[f] = null;
      }), Vu()), ~n ? (i = s[n], i ? i.p(u, c) : (i = s[n] = r[n](u), i.c()), Hn(i, 1), i.m(e, null)) : i = null), (!o || c[0] & /*variant, show_progress*/
      320 && l !== (l = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-1yserjw")) && mt(e, "class", l), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Ke(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden"), (!o || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Ke(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || c[0] & /*variant, show_progress, status*/
      336) && Ke(
        e,
        "generating",
        /*status*/
        u[4] === "generating"
      ), (!o || c[0] & /*variant, show_progress, border*/
      4416) && Ke(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && jt(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && jt(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (Hn(i), o = !0);
    },
    o(u) {
      Pn(i), o = !1;
    },
    d(u) {
      u && O(e), ~n && s[n].d(), t[31](null);
    }
  };
}
let Hi = [], Eo = !1;
async function Kg(t, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (Hi.push(t), !Eo)
      Eo = !0;
    else
      return;
    await Mg(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let i = 0; i < Hi.length; i++) {
        const o = Hi[i].getBoundingClientRect();
        (i === 0 || o.top + window.scrollY <= n[0]) && (n[0] = o.top + window.scrollY, n[1] = i);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Eo = !1, Hi = [];
    });
  }
}
function $g(t, e, n) {
  let i, { $$slots: l = {}, $$scope: o } = e, { i18n: r } = e, { eta: s = null } = e, { queue_position: a } = e, { queue_size: u } = e, { status: c } = e, { scroll_to_output: f = !1 } = e, { timer: d = !0 } = e, { show_progress: _ = "full" } = e, { message: m = null } = e, { progress: h = null } = e, { variant: p = "default" } = e, { loading_text: v = "Loading..." } = e, { absolute: y = !0 } = e, { translucent: w = !1 } = e, { border: B = !1 } = e, { autoscroll: k } = e, b, C = !1, H = 0, R = 0, x = null, z = null, q = 0, F = null, re, A = null, ae = !0;
  const N = () => {
    n(0, s = n(26, x = n(19, P = null))), n(24, H = performance.now()), n(25, R = 0), C = !0, S();
  };
  function S() {
    requestAnimationFrame(() => {
      n(25, R = (performance.now() - H) / 1e3), C && S();
    });
  }
  function pe() {
    n(25, R = 0), n(0, s = n(26, x = n(19, P = null))), C && (C = !1);
  }
  xg(() => {
    C && pe();
  });
  let P = null;
  function J(g) {
    xa[g ? "unshift" : "push"](() => {
      A = g, n(16, A), n(7, h), n(14, F), n(15, re);
    });
  }
  function Z(g) {
    xa[g ? "unshift" : "push"](() => {
      b = g, n(13, b);
    });
  }
  return t.$$set = (g) => {
    "i18n" in g && n(1, r = g.i18n), "eta" in g && n(0, s = g.eta), "queue_position" in g && n(2, a = g.queue_position), "queue_size" in g && n(3, u = g.queue_size), "status" in g && n(4, c = g.status), "scroll_to_output" in g && n(21, f = g.scroll_to_output), "timer" in g && n(5, d = g.timer), "show_progress" in g && n(6, _ = g.show_progress), "message" in g && n(22, m = g.message), "progress" in g && n(7, h = g.progress), "variant" in g && n(8, p = g.variant), "loading_text" in g && n(9, v = g.loading_text), "absolute" in g && n(10, y = g.absolute), "translucent" in g && n(11, w = g.translucent), "border" in g && n(12, B = g.border), "autoscroll" in g && n(23, k = g.autoscroll), "$$scope" in g && n(28, o = g.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    218103809 && (s === null && n(0, s = x), s != null && x !== s && (n(27, z = (performance.now() - H) / 1e3 + s), n(19, P = z.toFixed(1)), n(26, x = s))), t.$$.dirty[0] & /*eta_from_start, timer_diff*/
    167772160 && n(17, q = z === null || z <= 0 || !R ? null : Math.min(R / z, 1)), t.$$.dirty[0] & /*progress*/
    128 && h != null && n(18, ae = !1), t.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (h != null ? n(14, F = h.map((g) => {
      if (g.index != null && g.length != null)
        return g.index / g.length;
      if (g.progress != null)
        return g.progress;
    })) : n(14, F = null), F ? (n(15, re = F[F.length - 1]), A && (re === 0 ? n(16, A.style.transition = "0", A) : n(16, A.style.transition = "150ms", A))) : n(15, re = void 0)), t.$$.dirty[0] & /*status*/
    16 && (c === "pending" ? N() : pe()), t.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    10493968 && b && f && (c === "pending" || c === "complete") && Kg(b, k), t.$$.dirty[0] & /*status, message*/
    4194320, t.$$.dirty[0] & /*timer_diff*/
    33554432 && n(20, i = R.toFixed(1));
  }, [
    s,
    r,
    a,
    u,
    c,
    d,
    _,
    h,
    p,
    v,
    y,
    w,
    B,
    b,
    F,
    re,
    A,
    q,
    ae,
    P,
    i,
    f,
    m,
    k,
    H,
    R,
    x,
    z,
    o,
    l,
    J,
    Z
  ];
}
class Wu extends Bg {
  constructor(e) {
    super(), Rg(
      this,
      e,
      $g,
      Yg,
      Dg,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 21,
        timer: 5,
        show_progress: 6,
        message: 22,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 23
      },
      null,
      [-1, -1]
    );
  }
}
const e1 = new Error("failed to get response body reader"), t1 = new Error("failed to complete download"), n1 = "Content-Length", i1 = async (t, e) => {
  var l;
  const n = await fetch(t);
  let i;
  try {
    const o = parseInt(n.headers.get(n1) || "-1"), r = (l = n.body) == null ? void 0 : l.getReader();
    if (!r)
      throw e1;
    const s = [];
    let a = 0;
    for (; ; ) {
      const { done: f, value: d } = await r.read(), _ = d ? d.length : 0;
      if (f) {
        if (o != -1 && o !== a)
          throw t1;
        e && e({ url: t, total: o, received: a, delta: _, done: f });
        break;
      }
      s.push(d), a += _, e && e({ url: t, total: o, received: a, delta: _, done: f });
    }
    const u = new Uint8Array(a);
    let c = 0;
    for (const f of s)
      u.set(f, c), c += f.length;
    i = u.buffer;
  } catch (o) {
    console.log("failed to send download progress event: ", o), i = await n.arrayBuffer(), e && e({
      url: t,
      total: i.byteLength,
      received: i.byteLength,
      delta: 0,
      done: !0
    });
  }
  return i;
}, Yo = async (t, e, n = !1, i) => {
  const l = n ? await i1(t, i) : await (await fetch(t)).arrayBuffer(), o = new Blob([l], { type: e });
  return URL.createObjectURL(o);
};
var $;
(function(t) {
  t.LOAD = "LOAD", t.EXEC = "EXEC", t.WRITE_FILE = "WRITE_FILE", t.READ_FILE = "READ_FILE", t.DELETE_FILE = "DELETE_FILE", t.RENAME = "RENAME", t.CREATE_DIR = "CREATE_DIR", t.LIST_DIR = "LIST_DIR", t.DELETE_DIR = "DELETE_DIR", t.ERROR = "ERROR", t.DOWNLOAD = "DOWNLOAD", t.PROGRESS = "PROGRESS", t.LOG = "LOG", t.MOUNT = "MOUNT", t.UNMOUNT = "UNMOUNT";
})($ || ($ = {}));
const l1 = /* @__PURE__ */ (() => {
  let t = 0;
  return () => t++;
})(), o1 = new Error("ffmpeg is not loaded, call `await ffmpeg.load()` first"), r1 = new Error("called FFmpeg.terminate()");
var Ze, Ot, kt, $t, en, sl, je;
class a1 {
  constructor() {
    Lt(this, Ze, null);
    /**
     * #resolves and #rejects tracks Promise resolves and rejects to
     * be called when we receive message from web worker.
     */
    Lt(this, Ot, {});
    Lt(this, kt, {});
    Lt(this, $t, []);
    Lt(this, en, []);
    Pe(this, "loaded", !1);
    /**
     * register worker message event handlers.
     */
    Lt(this, sl, () => {
      M(this, Ze) && (M(this, Ze).onmessage = ({ data: { id: e, type: n, data: i } }) => {
        switch (n) {
          case $.LOAD:
            this.loaded = !0, M(this, Ot)[e](i);
            break;
          case $.MOUNT:
          case $.UNMOUNT:
          case $.EXEC:
          case $.WRITE_FILE:
          case $.READ_FILE:
          case $.DELETE_FILE:
          case $.RENAME:
          case $.CREATE_DIR:
          case $.LIST_DIR:
          case $.DELETE_DIR:
            M(this, Ot)[e](i);
            break;
          case $.LOG:
            M(this, $t).forEach((l) => l(i));
            break;
          case $.PROGRESS:
            M(this, en).forEach((l) => l(i));
            break;
          case $.ERROR:
            M(this, kt)[e](i);
            break;
        }
        delete M(this, Ot)[e], delete M(this, kt)[e];
      });
    });
    /**
     * Generic function to send messages to web worker.
     */
    Lt(this, je, ({ type: e, data: n }, i = [], l) => M(this, Ze) ? new Promise((o, r) => {
      const s = l1();
      M(this, Ze) && M(this, Ze).postMessage({ id: s, type: e, data: n }, i), M(this, Ot)[s] = o, M(this, kt)[s] = r, l == null || l.addEventListener("abort", () => {
        r(new DOMException(`Message # ${s} was aborted`, "AbortError"));
      }, { once: !0 });
    }) : Promise.reject(o1));
    /**
     * Loads ffmpeg-core inside web worker. It is required to call this method first
     * as it initializes WebAssembly and other essential variables.
     *
     * @category FFmpeg
     * @returns `true` if ffmpeg core is loaded for the first time.
     */
    Pe(this, "load", ({ classWorkerURL: e, ...n } = {}, { signal: i } = {}) => (M(this, Ze) || (Jn(this, Ze, e ? new Worker(new URL(e, import.meta.url), {
      type: "module"
    }) : (
      // We need to duplicated the code here to enable webpack
      // to bundle worekr.js here.
      new Worker(new URL("/assets/worker-43d19264.js", self.location), {
        type: "module"
      })
    )), M(this, sl).call(this)), M(this, je).call(this, {
      type: $.LOAD,
      data: n
    }, void 0, i)));
    /**
     * Execute ffmpeg command.
     *
     * @remarks
     * To avoid common I/O issues, ["-nostdin", "-y"] are prepended to the args
     * by default.
     *
     * @example
     * ```ts
     * const ffmpeg = new FFmpeg();
     * await ffmpeg.load();
     * await ffmpeg.writeFile("video.avi", ...);
     * // ffmpeg -i video.avi video.mp4
     * await ffmpeg.exec(["-i", "video.avi", "video.mp4"]);
     * const data = ffmpeg.readFile("video.mp4");
     * ```
     *
     * @returns `0` if no error, `!= 0` if timeout (1) or error.
     * @category FFmpeg
     */
    Pe(this, "exec", (e, n = -1, { signal: i } = {}) => M(this, je).call(this, {
      type: $.EXEC,
      data: { args: e, timeout: n }
    }, void 0, i));
    /**
     * Terminate all ongoing API calls and terminate web worker.
     * `FFmpeg.load()` must be called again before calling any other APIs.
     *
     * @category FFmpeg
     */
    Pe(this, "terminate", () => {
      const e = Object.keys(M(this, kt));
      for (const n of e)
        M(this, kt)[n](r1), delete M(this, kt)[n], delete M(this, Ot)[n];
      M(this, Ze) && (M(this, Ze).terminate(), Jn(this, Ze, null), this.loaded = !1);
    });
    /**
     * Write data to ffmpeg.wasm.
     *
     * @example
     * ```ts
     * const ffmpeg = new FFmpeg();
     * await ffmpeg.load();
     * await ffmpeg.writeFile("video.avi", await fetchFile("../video.avi"));
     * await ffmpeg.writeFile("text.txt", "hello world");
     * ```
     *
     * @category File System
     */
    Pe(this, "writeFile", (e, n, { signal: i } = {}) => {
      const l = [];
      return n instanceof Uint8Array && l.push(n.buffer), M(this, je).call(this, {
        type: $.WRITE_FILE,
        data: { path: e, data: n }
      }, l, i);
    });
    Pe(this, "mount", (e, n, i) => {
      const l = [];
      return M(this, je).call(this, {
        type: $.MOUNT,
        data: { fsType: e, options: n, mountPoint: i }
      }, l);
    });
    Pe(this, "unmount", (e) => {
      const n = [];
      return M(this, je).call(this, {
        type: $.UNMOUNT,
        data: { mountPoint: e }
      }, n);
    });
    /**
     * Read data from ffmpeg.wasm.
     *
     * @example
     * ```ts
     * const ffmpeg = new FFmpeg();
     * await ffmpeg.load();
     * const data = await ffmpeg.readFile("video.mp4");
     * ```
     *
     * @category File System
     */
    Pe(this, "readFile", (e, n = "binary", { signal: i } = {}) => M(this, je).call(this, {
      type: $.READ_FILE,
      data: { path: e, encoding: n }
    }, void 0, i));
    /**
     * Delete a file.
     *
     * @category File System
     */
    Pe(this, "deleteFile", (e, { signal: n } = {}) => M(this, je).call(this, {
      type: $.DELETE_FILE,
      data: { path: e }
    }, void 0, n));
    /**
     * Rename a file or directory.
     *
     * @category File System
     */
    Pe(this, "rename", (e, n, { signal: i } = {}) => M(this, je).call(this, {
      type: $.RENAME,
      data: { oldPath: e, newPath: n }
    }, void 0, i));
    /**
     * Create a directory.
     *
     * @category File System
     */
    Pe(this, "createDir", (e, { signal: n } = {}) => M(this, je).call(this, {
      type: $.CREATE_DIR,
      data: { path: e }
    }, void 0, n));
    /**
     * List directory contents.
     *
     * @category File System
     */
    Pe(this, "listDir", (e, { signal: n } = {}) => M(this, je).call(this, {
      type: $.LIST_DIR,
      data: { path: e }
    }, void 0, n));
    /**
     * Delete an empty directory.
     *
     * @category File System
     */
    Pe(this, "deleteDir", (e, { signal: n } = {}) => M(this, je).call(this, {
      type: $.DELETE_DIR,
      data: { path: e }
    }, void 0, n));
  }
  on(e, n) {
    e === "log" ? M(this, $t).push(n) : e === "progress" && M(this, en).push(n);
  }
  off(e, n) {
    e === "log" ? Jn(this, $t, M(this, $t).filter((i) => i !== n)) : e === "progress" && Jn(this, en, M(this, en).filter((i) => i !== n));
  }
}
Ze = new WeakMap(), Ot = new WeakMap(), kt = new WeakMap(), $t = new WeakMap(), en = new WeakMap(), sl = new WeakMap(), je = new WeakMap();
const s1 = {
  "3g2": "video/3gpp2",
  "3gp": "video/3gpp",
  "3gpp": "video/3gpp",
  "3mf": "model/3mf",
  aac: "audio/aac",
  ac: "application/pkix-attr-cert",
  adp: "audio/adpcm",
  adts: "audio/aac",
  ai: "application/postscript",
  aml: "application/automationml-aml+xml",
  amlx: "application/automationml-amlx+zip",
  amr: "audio/amr",
  apng: "image/apng",
  appcache: "text/cache-manifest",
  appinstaller: "application/appinstaller",
  appx: "application/appx",
  appxbundle: "application/appxbundle",
  asc: "application/pgp-keys",
  atom: "application/atom+xml",
  atomcat: "application/atomcat+xml",
  atomdeleted: "application/atomdeleted+xml",
  atomsvc: "application/atomsvc+xml",
  au: "audio/basic",
  avci: "image/avci",
  avcs: "image/avcs",
  avif: "image/avif",
  aw: "application/applixware",
  bdoc: "application/bdoc",
  bin: "application/octet-stream",
  bmp: "image/bmp",
  bpk: "application/octet-stream",
  btf: "image/prs.btif",
  btif: "image/prs.btif",
  buffer: "application/octet-stream",
  ccxml: "application/ccxml+xml",
  cdfx: "application/cdfx+xml",
  cdmia: "application/cdmi-capability",
  cdmic: "application/cdmi-container",
  cdmid: "application/cdmi-domain",
  cdmio: "application/cdmi-object",
  cdmiq: "application/cdmi-queue",
  cer: "application/pkix-cert",
  cgm: "image/cgm",
  cjs: "application/node",
  class: "application/java-vm",
  coffee: "text/coffeescript",
  conf: "text/plain",
  cpl: "application/cpl+xml",
  cpt: "application/mac-compactpro",
  crl: "application/pkix-crl",
  css: "text/css",
  csv: "text/csv",
  cu: "application/cu-seeme",
  cwl: "application/cwl",
  cww: "application/prs.cww",
  davmount: "application/davmount+xml",
  dbk: "application/docbook+xml",
  deb: "application/octet-stream",
  def: "text/plain",
  deploy: "application/octet-stream",
  dib: "image/bmp",
  "disposition-notification": "message/disposition-notification",
  dist: "application/octet-stream",
  distz: "application/octet-stream",
  dll: "application/octet-stream",
  dmg: "application/octet-stream",
  dms: "application/octet-stream",
  doc: "application/msword",
  dot: "application/msword",
  dpx: "image/dpx",
  drle: "image/dicom-rle",
  dsc: "text/prs.lines.tag",
  dssc: "application/dssc+der",
  dtd: "application/xml-dtd",
  dump: "application/octet-stream",
  dwd: "application/atsc-dwd+xml",
  ear: "application/java-archive",
  ecma: "application/ecmascript",
  elc: "application/octet-stream",
  emf: "image/emf",
  eml: "message/rfc822",
  emma: "application/emma+xml",
  emotionml: "application/emotionml+xml",
  eps: "application/postscript",
  epub: "application/epub+zip",
  exe: "application/octet-stream",
  exi: "application/exi",
  exp: "application/express",
  exr: "image/aces",
  ez: "application/andrew-inset",
  fdf: "application/fdf",
  fdt: "application/fdt+xml",
  fits: "image/fits",
  g3: "image/g3fax",
  gbr: "application/rpki-ghostbusters",
  geojson: "application/geo+json",
  gif: "image/gif",
  glb: "model/gltf-binary",
  gltf: "model/gltf+json",
  gml: "application/gml+xml",
  gpx: "application/gpx+xml",
  gram: "application/srgs",
  grxml: "application/srgs+xml",
  gxf: "application/gxf",
  gz: "application/gzip",
  h261: "video/h261",
  h263: "video/h263",
  h264: "video/h264",
  heic: "image/heic",
  heics: "image/heic-sequence",
  heif: "image/heif",
  heifs: "image/heif-sequence",
  hej2: "image/hej2k",
  held: "application/atsc-held+xml",
  hjson: "application/hjson",
  hlp: "application/winhlp",
  hqx: "application/mac-binhex40",
  hsj2: "image/hsj2",
  htm: "text/html",
  html: "text/html",
  ics: "text/calendar",
  ief: "image/ief",
  ifb: "text/calendar",
  iges: "model/iges",
  igs: "model/iges",
  img: "application/octet-stream",
  in: "text/plain",
  ini: "text/plain",
  ink: "application/inkml+xml",
  inkml: "application/inkml+xml",
  ipfix: "application/ipfix",
  iso: "application/octet-stream",
  its: "application/its+xml",
  jade: "text/jade",
  jar: "application/java-archive",
  jhc: "image/jphc",
  jls: "image/jls",
  jp2: "image/jp2",
  jpe: "image/jpeg",
  jpeg: "image/jpeg",
  jpf: "image/jpx",
  jpg: "image/jpeg",
  jpg2: "image/jp2",
  jpgm: "image/jpm",
  jpgv: "video/jpeg",
  jph: "image/jph",
  jpm: "image/jpm",
  jpx: "image/jpx",
  js: "text/javascript",
  json: "application/json",
  json5: "application/json5",
  jsonld: "application/ld+json",
  jsonml: "application/jsonml+json",
  jsx: "text/jsx",
  jt: "model/jt",
  jxr: "image/jxr",
  jxra: "image/jxra",
  jxrs: "image/jxrs",
  jxs: "image/jxs",
  jxsc: "image/jxsc",
  jxsi: "image/jxsi",
  jxss: "image/jxss",
  kar: "audio/midi",
  ktx: "image/ktx",
  ktx2: "image/ktx2",
  less: "text/less",
  lgr: "application/lgr+xml",
  list: "text/plain",
  litcoffee: "text/coffeescript",
  log: "text/plain",
  lostxml: "application/lost+xml",
  lrf: "application/octet-stream",
  m1v: "video/mpeg",
  m21: "application/mp21",
  m2a: "audio/mpeg",
  m2v: "video/mpeg",
  m3a: "audio/mpeg",
  m4a: "audio/mp4",
  m4p: "application/mp4",
  m4s: "video/iso.segment",
  ma: "application/mathematica",
  mads: "application/mads+xml",
  maei: "application/mmt-aei+xml",
  man: "text/troff",
  manifest: "text/cache-manifest",
  map: "application/json",
  mar: "application/octet-stream",
  markdown: "text/markdown",
  mathml: "application/mathml+xml",
  mb: "application/mathematica",
  mbox: "application/mbox",
  md: "text/markdown",
  mdx: "text/mdx",
  me: "text/troff",
  mesh: "model/mesh",
  meta4: "application/metalink4+xml",
  metalink: "application/metalink+xml",
  mets: "application/mets+xml",
  mft: "application/rpki-manifest",
  mid: "audio/midi",
  midi: "audio/midi",
  mime: "message/rfc822",
  mj2: "video/mj2",
  mjp2: "video/mj2",
  mjs: "text/javascript",
  mml: "text/mathml",
  mods: "application/mods+xml",
  mov: "video/quicktime",
  mp2: "audio/mpeg",
  mp21: "application/mp21",
  mp2a: "audio/mpeg",
  mp3: "audio/mpeg",
  mp4: "video/mp4",
  mp4a: "audio/mp4",
  mp4s: "application/mp4",
  mp4v: "video/mp4",
  mpd: "application/dash+xml",
  mpe: "video/mpeg",
  mpeg: "video/mpeg",
  mpf: "application/media-policy-dataset+xml",
  mpg: "video/mpeg",
  mpg4: "video/mp4",
  mpga: "audio/mpeg",
  mpp: "application/dash-patch+xml",
  mrc: "application/marc",
  mrcx: "application/marcxml+xml",
  ms: "text/troff",
  mscml: "application/mediaservercontrol+xml",
  msh: "model/mesh",
  msi: "application/octet-stream",
  msix: "application/msix",
  msixbundle: "application/msixbundle",
  msm: "application/octet-stream",
  msp: "application/octet-stream",
  mtl: "model/mtl",
  musd: "application/mmt-usd+xml",
  mxf: "application/mxf",
  mxmf: "audio/mobile-xmf",
  mxml: "application/xv+xml",
  n3: "text/n3",
  nb: "application/mathematica",
  nq: "application/n-quads",
  nt: "application/n-triples",
  obj: "model/obj",
  oda: "application/oda",
  oga: "audio/ogg",
  ogg: "audio/ogg",
  ogv: "video/ogg",
  ogx: "application/ogg",
  omdoc: "application/omdoc+xml",
  onepkg: "application/onenote",
  onetmp: "application/onenote",
  onetoc: "application/onenote",
  onetoc2: "application/onenote",
  opf: "application/oebps-package+xml",
  opus: "audio/ogg",
  otf: "font/otf",
  owl: "application/rdf+xml",
  oxps: "application/oxps",
  p10: "application/pkcs10",
  p7c: "application/pkcs7-mime",
  p7m: "application/pkcs7-mime",
  p7s: "application/pkcs7-signature",
  p8: "application/pkcs8",
  pdf: "application/pdf",
  pfr: "application/font-tdpfr",
  pgp: "application/pgp-encrypted",
  pkg: "application/octet-stream",
  pki: "application/pkixcmp",
  pkipath: "application/pkix-pkipath",
  pls: "application/pls+xml",
  png: "image/png",
  prc: "model/prc",
  prf: "application/pics-rules",
  provx: "application/provenance+xml",
  ps: "application/postscript",
  pskcxml: "application/pskc+xml",
  pti: "image/prs.pti",
  qt: "video/quicktime",
  raml: "application/raml+yaml",
  rapd: "application/route-apd+xml",
  rdf: "application/rdf+xml",
  relo: "application/p2p-overlay+xml",
  rif: "application/reginfo+xml",
  rl: "application/resource-lists+xml",
  rld: "application/resource-lists-diff+xml",
  rmi: "audio/midi",
  rnc: "application/relax-ng-compact-syntax",
  rng: "application/xml",
  roa: "application/rpki-roa",
  roff: "text/troff",
  rq: "application/sparql-query",
  rs: "application/rls-services+xml",
  rsat: "application/atsc-rsat+xml",
  rsd: "application/rsd+xml",
  rsheet: "application/urc-ressheet+xml",
  rss: "application/rss+xml",
  rtf: "text/rtf",
  rtx: "text/richtext",
  rusd: "application/route-usd+xml",
  s3m: "audio/s3m",
  sbml: "application/sbml+xml",
  scq: "application/scvp-cv-request",
  scs: "application/scvp-cv-response",
  sdp: "application/sdp",
  senmlx: "application/senml+xml",
  sensmlx: "application/sensml+xml",
  ser: "application/java-serialized-object",
  setpay: "application/set-payment-initiation",
  setreg: "application/set-registration-initiation",
  sgi: "image/sgi",
  sgm: "text/sgml",
  sgml: "text/sgml",
  shex: "text/shex",
  shf: "application/shf+xml",
  shtml: "text/html",
  sieve: "application/sieve",
  sig: "application/pgp-signature",
  sil: "audio/silk",
  silo: "model/mesh",
  siv: "application/sieve",
  slim: "text/slim",
  slm: "text/slim",
  sls: "application/route-s-tsid+xml",
  smi: "application/smil+xml",
  smil: "application/smil+xml",
  snd: "audio/basic",
  so: "application/octet-stream",
  spdx: "text/spdx",
  spp: "application/scvp-vp-response",
  spq: "application/scvp-vp-request",
  spx: "audio/ogg",
  sql: "application/sql",
  sru: "application/sru+xml",
  srx: "application/sparql-results+xml",
  ssdl: "application/ssdl+xml",
  ssml: "application/ssml+xml",
  stk: "application/hyperstudio",
  stl: "model/stl",
  stpx: "model/step+xml",
  stpxz: "model/step-xml+zip",
  stpz: "model/step+zip",
  styl: "text/stylus",
  stylus: "text/stylus",
  svg: "image/svg+xml",
  svgz: "image/svg+xml",
  swidtag: "application/swid+xml",
  t: "text/troff",
  t38: "image/t38",
  td: "application/urc-targetdesc+xml",
  tei: "application/tei+xml",
  teicorpus: "application/tei+xml",
  text: "text/plain",
  tfi: "application/thraud+xml",
  tfx: "image/tiff-fx",
  tif: "image/tiff",
  tiff: "image/tiff",
  toml: "application/toml",
  tr: "text/troff",
  trig: "application/trig",
  ts: "video/mp2t",
  tsd: "application/timestamped-data",
  tsv: "text/tab-separated-values",
  ttc: "font/collection",
  ttf: "font/ttf",
  ttl: "text/turtle",
  ttml: "application/ttml+xml",
  txt: "text/plain",
  u3d: "model/u3d",
  u8dsn: "message/global-delivery-status",
  u8hdr: "message/global-headers",
  u8mdn: "message/global-disposition-notification",
  u8msg: "message/global",
  ubj: "application/ubjson",
  uri: "text/uri-list",
  uris: "text/uri-list",
  urls: "text/uri-list",
  vcard: "text/vcard",
  vrml: "model/vrml",
  vtt: "text/vtt",
  vxml: "application/voicexml+xml",
  war: "application/java-archive",
  wasm: "application/wasm",
  wav: "audio/wav",
  weba: "audio/webm",
  webm: "video/webm",
  webmanifest: "application/manifest+json",
  webp: "image/webp",
  wgsl: "text/wgsl",
  wgt: "application/widget",
  wif: "application/watcherinfo+xml",
  wmf: "image/wmf",
  woff: "font/woff",
  woff2: "font/woff2",
  wrl: "model/vrml",
  wsdl: "application/wsdl+xml",
  wspolicy: "application/wspolicy+xml",
  x3d: "model/x3d+xml",
  x3db: "model/x3d+fastinfoset",
  x3dbz: "model/x3d+binary",
  x3dv: "model/x3d-vrml",
  x3dvz: "model/x3d+vrml",
  x3dz: "model/x3d+xml",
  xaml: "application/xaml+xml",
  xav: "application/xcap-att+xml",
  xca: "application/xcap-caps+xml",
  xcs: "application/calendar+xml",
  xdf: "application/xcap-diff+xml",
  xdssc: "application/dssc+xml",
  xel: "application/xcap-el+xml",
  xenc: "application/xenc+xml",
  xer: "application/patch-ops-error+xml",
  xfdf: "application/xfdf",
  xht: "application/xhtml+xml",
  xhtml: "application/xhtml+xml",
  xhvml: "application/xv+xml",
  xlf: "application/xliff+xml",
  xm: "audio/xm",
  xml: "text/xml",
  xns: "application/xcap-ns+xml",
  xop: "application/xop+xml",
  xpl: "application/xproc+xml",
  xsd: "application/xml",
  xsf: "application/prs.xsf+xml",
  xsl: "application/xml",
  xslt: "application/xml",
  xspf: "application/xspf+xml",
  xvm: "application/xv+xml",
  xvml: "application/xv+xml",
  yaml: "text/yaml",
  yang: "application/yang",
  yin: "application/yin+xml",
  yml: "text/yaml",
  zip: "application/zip"
};
function u1(t) {
  let e = ("" + t).trim().toLowerCase(), n = e.lastIndexOf(".");
  return s1[~n ? e.substring(++n) : e];
}
const es = (t) => {
  let e = ["B", "KB", "MB", "GB", "PB"], n = 0;
  for (; t > 1024; )
    t /= 1024, n++;
  let i = e[n];
  return t.toFixed(1) + " " + i;
}, c1 = () => !0;
function f1(t, { autoplay: e }) {
  async function n() {
    e && await t.play();
  }
  return t.addEventListener("loadeddata", n), {
    destroy() {
      t.removeEventListener("loadeddata", n);
    }
  };
}
async function d1() {
  const t = new a1(), e = "https://unpkg.com/@ffmpeg/core@0.12.4/dist/esm";
  return await t.load({
    coreURL: await Yo(`${e}/ffmpeg-core.js`, "text/javascript"),
    wasmURL: await Yo(`${e}/ffmpeg-core.wasm`, "application/wasm")
  }), t;
}
async function _1(t, e, n, i) {
  const l = i.src, o = u1(i.src) || "video/mp4", r = await Yo(l, o), a = await (await fetch(r)).blob(), u = m1(o) || "mp4", c = `input.${u}`, f = `output.${u}`;
  try {
    if (e === 0 && n === 0)
      return a;
    await t.writeFile(
      c,
      new Uint8Array(await a.arrayBuffer())
    );
    let d = [
      "-i",
      c,
      ...e !== 0 ? ["-ss", e.toString()] : [],
      ...n !== 0 ? ["-to", n.toString()] : [],
      "-c:a",
      "copy",
      f
    ];
    await t.exec(d);
    const _ = await t.readFile(f);
    return new Blob([_], {
      type: `video/${u}`
    });
  } catch (d) {
    return console.error("Error initializing FFmpeg:", d), a;
  }
}
const m1 = (t) => ({
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/ogg": "ogv",
  "video/quicktime": "mov",
  "video/x-msvideo": "avi",
  "video/x-matroska": "mkv",
  "video/mpeg": "mpeg",
  "video/3gpp": "3gp",
  "video/3gpp2": "3g2",
  "video/h261": "h261",
  "video/h263": "h263",
  "video/h264": "h264",
  "video/jpeg": "jpgv",
  "video/jpm": "jpm",
  "video/mj2": "mj2",
  "video/mpv": "mpv",
  "video/vnd.ms-playready.media.pyv": "pyv",
  "video/vnd.uvvu.mp4": "uvu",
  "video/vnd.vivo": "viv",
  "video/x-f4v": "f4v",
  "video/x-fli": "fli",
  "video/x-flv": "flv",
  "video/x-m4v": "m4v",
  "video/x-ms-asf": "asf",
  "video/x-ms-wm": "wm",
  "video/x-ms-wmv": "wmv",
  "video/x-ms-wmx": "wmx",
  "video/x-ms-wvx": "wvx",
  "video/x-sgi-movie": "movie",
  "video/x-smv": "smv"
})[t] || null;
const {
  SvelteComponent: h1,
  action_destroyer: p1,
  add_render_callback: g1,
  assign: ts,
  attr: Pt,
  binding_callbacks: b1,
  create_slot: v1,
  detach: So,
  element: ns,
  exclude_internal_props: is,
  get_all_dirty_from_scope: w1,
  get_slot_changes: y1,
  init: k1,
  insert: To,
  is_function: E1,
  listen: Xe,
  raf: S1,
  run_all: T1,
  safe_not_equal: C1,
  space: A1,
  src_url_equal: ls,
  toggle_class: os,
  transition_in: B1,
  transition_out: L1,
  update_slot_base: N1
} = window.__gradio__svelte__internal, { createEventDispatcher: I1 } = window.__gradio__svelte__internal;
function H1(t) {
  let e, n, i, l, o, r = !1, s, a = !0, u, c, f, d;
  const _ = (
    /*#slots*/
    t[16].default
  ), m = v1(
    _,
    t,
    /*$$scope*/
    t[15],
    null
  );
  function h() {
    cancelAnimationFrame(s), i.paused || (s = S1(h), r = !0), t[17].call(i);
  }
  return {
    c() {
      e = ns("div"), e.innerHTML = '<span class="load-wrap svelte-1pwzuub"><span class="loader svelte-1pwzuub"></span></span>', n = A1(), i = ns("video"), m && m.c(), Pt(e, "class", "overlay svelte-1pwzuub"), os(e, "hidden", !/*processingVideo*/
      t[9]), ls(i.src, l = /*resolved_src*/
      t[10]) || Pt(i, "src", l), i.muted = /*muted*/
      t[4], i.playsInline = /*playsinline*/
      t[5], Pt(
        i,
        "preload",
        /*preload*/
        t[6]
      ), i.autoplay = /*autoplay*/
      t[7], i.loop = !0, i.controls = /*controls*/
      t[8], Pt(i, "data-testid", o = /*$$props*/
      t[12]["data-testid"]), Pt(i, "crossorigin", "anonymous"), /*duration*/
      t[1] === void 0 && g1(() => (
        /*video_durationchange_handler*/
        t[18].call(i)
      ));
    },
    m(p, v) {
      To(p, e, v), To(p, n, v), To(p, i, v), m && m.m(i, null), t[20](i), c = !0, f || (d = [
        Xe(
          i,
          "loadeddata",
          /*dispatch*/
          t[11].bind(null, "loadeddata")
        ),
        Xe(
          i,
          "click",
          /*dispatch*/
          t[11].bind(null, "click")
        ),
        Xe(
          i,
          "play",
          /*dispatch*/
          t[11].bind(null, "play")
        ),
        Xe(
          i,
          "pause",
          /*dispatch*/
          t[11].bind(null, "pause")
        ),
        Xe(
          i,
          "ended",
          /*dispatch*/
          t[11].bind(null, "ended")
        ),
        Xe(
          i,
          "mouseover",
          /*dispatch*/
          t[11].bind(null, "mouseover")
        ),
        Xe(
          i,
          "mouseout",
          /*dispatch*/
          t[11].bind(null, "mouseout")
        ),
        Xe(
          i,
          "focus",
          /*dispatch*/
          t[11].bind(null, "focus")
        ),
        Xe(
          i,
          "blur",
          /*dispatch*/
          t[11].bind(null, "blur")
        ),
        Xe(i, "timeupdate", h),
        Xe(
          i,
          "durationchange",
          /*video_durationchange_handler*/
          t[18]
        ),
        Xe(
          i,
          "play",
          /*video_play_pause_handler*/
          t[19]
        ),
        Xe(
          i,
          "pause",
          /*video_play_pause_handler*/
          t[19]
        ),
        p1(u = f1.call(null, i, { autoplay: (
          /*autoplay*/
          t[7] ?? !1
        ) }))
      ], f = !0);
    },
    p(p, [v]) {
      (!c || v & /*processingVideo*/
      512) && os(e, "hidden", !/*processingVideo*/
      p[9]), m && m.p && (!c || v & /*$$scope*/
      32768) && N1(
        m,
        _,
        p,
        /*$$scope*/
        p[15],
        c ? y1(
          _,
          /*$$scope*/
          p[15],
          v,
          null
        ) : w1(
          /*$$scope*/
          p[15]
        ),
        null
      ), (!c || v & /*resolved_src*/
      1024 && !ls(i.src, l = /*resolved_src*/
      p[10])) && Pt(i, "src", l), (!c || v & /*muted*/
      16) && (i.muted = /*muted*/
      p[4]), (!c || v & /*playsinline*/
      32) && (i.playsInline = /*playsinline*/
      p[5]), (!c || v & /*preload*/
      64) && Pt(
        i,
        "preload",
        /*preload*/
        p[6]
      ), (!c || v & /*autoplay*/
      128) && (i.autoplay = /*autoplay*/
      p[7]), (!c || v & /*controls*/
      256) && (i.controls = /*controls*/
      p[8]), (!c || v & /*$$props*/
      4096 && o !== (o = /*$$props*/
      p[12]["data-testid"])) && Pt(i, "data-testid", o), !r && v & /*currentTime*/
      1 && !isNaN(
        /*currentTime*/
        p[0]
      ) && (i.currentTime = /*currentTime*/
      p[0]), r = !1, v & /*paused*/
      4 && a !== (a = /*paused*/
      p[2]) && i[a ? "pause" : "play"](), u && E1(u.update) && v & /*autoplay*/
      128 && u.update.call(null, { autoplay: (
        /*autoplay*/
        p[7] ?? !1
      ) });
    },
    i(p) {
      c || (B1(m, p), c = !0);
    },
    o(p) {
      L1(m, p), c = !1;
    },
    d(p) {
      p && (So(e), So(n), So(i)), m && m.d(p), t[20](null), f = !1, T1(d);
    }
  };
}
function P1(t, e, n) {
  let { $$slots: i = {}, $$scope: l } = e, { src: o = void 0 } = e, { muted: r = void 0 } = e, { playsinline: s = void 0 } = e, { preload: a = void 0 } = e, { autoplay: u = !0 } = e, { controls: c = void 0 } = e, { currentTime: f = void 0 } = e, { duration: d = void 0 } = e, { paused: _ = void 0 } = e, { node: m = void 0 } = e, { processingVideo: h = !1 } = e, p, v;
  const y = I1();
  function w() {
    f = this.currentTime, n(0, f);
  }
  function B() {
    d = this.duration, n(1, d);
  }
  function k() {
    _ = this.paused, n(2, _);
  }
  function b(C) {
    b1[C ? "unshift" : "push"](() => {
      m = C, n(3, m);
    });
  }
  return t.$$set = (C) => {
    n(12, e = ts(ts({}, e), is(C))), "src" in C && n(13, o = C.src), "muted" in C && n(4, r = C.muted), "playsinline" in C && n(5, s = C.playsinline), "preload" in C && n(6, a = C.preload), "autoplay" in C && n(7, u = C.autoplay), "controls" in C && n(8, c = C.controls), "currentTime" in C && n(0, f = C.currentTime), "duration" in C && n(1, d = C.duration), "paused" in C && n(2, _ = C.paused), "node" in C && n(3, m = C.node), "processingVideo" in C && n(9, h = C.processingVideo), "$$scope" in C && n(15, l = C.$$scope);
  }, t.$$.update = () => {
    if (t.$$.dirty & /*src, latest_src*/
    24576) {
      n(10, p = o), n(14, v = o);
      const C = o;
      l0(C).then((H) => {
        v === C && n(10, p = H);
      });
    }
  }, e = is(e), [
    f,
    d,
    _,
    m,
    r,
    s,
    a,
    u,
    c,
    h,
    p,
    y,
    e,
    o,
    v,
    l,
    i,
    w,
    B,
    k,
    b
  ];
}
class Zu extends h1 {
  constructor(e) {
    super(), k1(this, e, P1, H1, C1, {
      src: 13,
      muted: 4,
      playsinline: 5,
      preload: 6,
      autoplay: 7,
      controls: 8,
      currentTime: 0,
      duration: 1,
      paused: 2,
      node: 3,
      processingVideo: 9
    });
  }
}
const {
  SvelteComponent: R1,
  append: bn,
  attr: Be,
  destroy_block: O1,
  detach: kl,
  element: Kt,
  ensure_array_like: rs,
  init: D1,
  insert: El,
  listen: vn,
  noop: Ko,
  run_all: j1,
  safe_not_equal: M1,
  set_style: Rt,
  space: Co,
  src_url_equal: as,
  update_keyed_each: x1
} = window.__gradio__svelte__internal, { onMount: ss, onDestroy: U1 } = window.__gradio__svelte__internal;
function us(t, e, n) {
  const i = t.slice();
  return i[20] = e[n], i[22] = n, i;
}
function q1(t) {
  let e, n, i, l, o, r = [], s = /* @__PURE__ */ new Map(), a, u, c, f, d = rs(
    /*thumbnails*/
    t[1]
  );
  const _ = (m) => (
    /*i*/
    m[22]
  );
  for (let m = 0; m < d.length; m += 1) {
    let h = us(t, d, m), p = _(h);
    s.set(p, r[m] = cs(p, h));
  }
  return {
    c() {
      e = Kt("div"), n = Kt("button"), i = Co(), l = Kt("div"), o = Co();
      for (let m = 0; m < r.length; m += 1)
        r[m].c();
      a = Co(), u = Kt("button"), Be(n, "aria-label", "start drag handle for trimming video"), Be(n, "class", "handle left svelte-kn3uji"), Rt(
        n,
        "left",
        /*leftHandlePosition*/
        t[2] + "%"
      ), Be(l, "class", "opaque-layer svelte-kn3uji"), Rt(
        l,
        "left",
        /*leftHandlePosition*/
        t[2] + "%"
      ), Rt(l, "right", 100 - /*rightHandlePosition*/
      t[3] + "%"), Be(u, "aria-label", "end drag handle for trimming video"), Be(u, "class", "handle right svelte-kn3uji"), Rt(
        u,
        "left",
        /*rightHandlePosition*/
        t[3] + "%"
      ), Be(e, "id", "timeline"), Be(e, "class", "thumbnail-wrapper svelte-kn3uji");
    },
    m(m, h) {
      El(m, e, h), bn(e, n), bn(e, i), bn(e, l), bn(e, o);
      for (let p = 0; p < r.length; p += 1)
        r[p] && r[p].m(e, null);
      bn(e, a), bn(e, u), c || (f = [
        vn(
          n,
          "mousedown",
          /*mousedown_handler*/
          t[10]
        ),
        vn(
          n,
          "blur",
          /*stopDragging*/
          t[5]
        ),
        vn(
          n,
          "keydown",
          /*keydown_handler*/
          t[11]
        ),
        vn(
          u,
          "mousedown",
          /*mousedown_handler_1*/
          t[12]
        ),
        vn(
          u,
          "blur",
          /*stopDragging*/
          t[5]
        ),
        vn(
          u,
          "keydown",
          /*keydown_handler_1*/
          t[13]
        )
      ], c = !0);
    },
    p(m, h) {
      h & /*leftHandlePosition*/
      4 && Rt(
        n,
        "left",
        /*leftHandlePosition*/
        m[2] + "%"
      ), h & /*leftHandlePosition*/
      4 && Rt(
        l,
        "left",
        /*leftHandlePosition*/
        m[2] + "%"
      ), h & /*rightHandlePosition*/
      8 && Rt(l, "right", 100 - /*rightHandlePosition*/
      m[3] + "%"), h & /*thumbnails*/
      2 && (d = rs(
        /*thumbnails*/
        m[1]
      ), r = x1(r, h, _, 1, m, d, s, e, O1, cs, a, us)), h & /*rightHandlePosition*/
      8 && Rt(
        u,
        "left",
        /*rightHandlePosition*/
        m[3] + "%"
      );
    },
    d(m) {
      m && kl(e);
      for (let h = 0; h < r.length; h += 1)
        r[h].d();
      c = !1, j1(f);
    }
  };
}
function F1(t) {
  let e;
  return {
    c() {
      e = Kt("div"), e.innerHTML = '<span aria-label="loading timeline" class="loader svelte-kn3uji"></span>', Be(e, "class", "load-wrap svelte-kn3uji");
    },
    m(n, i) {
      El(n, e, i);
    },
    p: Ko,
    d(n) {
      n && kl(e);
    }
  };
}
function cs(t, e) {
  let n, i, l;
  return {
    key: t,
    first: null,
    c() {
      n = Kt("img"), as(n.src, i = /*thumbnail*/
      e[20]) || Be(n, "src", i), Be(n, "alt", l = `frame-${/*i*/
      e[22]}`), Be(n, "draggable", "false"), Be(n, "class", "svelte-kn3uji"), this.first = n;
    },
    m(o, r) {
      El(o, n, r);
    },
    p(o, r) {
      e = o, r & /*thumbnails*/
      2 && !as(n.src, i = /*thumbnail*/
      e[20]) && Be(n, "src", i), r & /*thumbnails*/
      2 && l !== (l = `frame-${/*i*/
      e[22]}`) && Be(n, "alt", l);
    },
    d(o) {
      o && kl(n);
    }
  };
}
function G1(t) {
  let e;
  function n(o, r) {
    return (
      /*loadingTimeline*/
      o[0] ? F1 : q1
    );
  }
  let i = n(t), l = i(t);
  return {
    c() {
      e = Kt("div"), l.c(), Be(e, "class", "container svelte-kn3uji");
    },
    m(o, r) {
      El(o, e, r), l.m(e, null);
    },
    p(o, [r]) {
      i === (i = n(o)) && l ? l.p(o, r) : (l.d(1), l = i(o), l && (l.c(), l.m(e, null)));
    },
    i: Ko,
    o: Ko,
    d(o) {
      o && kl(e), l.d();
    }
  };
}
let Ao = 10;
function V1(t, e, n) {
  let { videoElement: i } = e, { trimmedDuration: l } = e, { dragStart: o } = e, { dragEnd: r } = e, { loadingTimeline: s } = e, a = [], u, c = 0, f = 100, d = null;
  const _ = (b) => {
    d = b;
  }, m = () => {
    d = null;
  }, h = (b, C) => {
    if (d) {
      const H = document.getElementById("timeline");
      if (!H)
        return;
      const R = H.getBoundingClientRect();
      let x = (b.clientX - R.left) / R.width * 100;
      if (C ? x = d === "left" ? c + C : f + C : x = (b.clientX - R.left) / R.width * 100, x = Math.max(0, Math.min(x, 100)), d === "left") {
        n(2, c = Math.min(x, f));
        const F = c / 100 * u;
        n(6, i.currentTime = F, i), n(8, o = F);
      } else if (d === "right") {
        n(3, f = Math.max(x, c));
        const F = f / 100 * u;
        n(6, i.currentTime = F, i), n(9, r = F);
      }
      const z = c / 100 * u, q = f / 100 * u;
      n(7, l = q - z), n(2, c), n(3, f);
    }
  }, p = (b) => {
    if (d) {
      const C = 1 / u * 100;
      b.key === "ArrowLeft" ? h({ clientX: 0 }, -C) : b.key === "ArrowRight" && h({ clientX: 0 }, C);
    }
  }, v = () => {
    const b = document.createElement("canvas"), C = b.getContext("2d");
    if (!C)
      return;
    b.width = i.videoWidth, b.height = i.videoHeight, C.drawImage(i, 0, 0, b.width, b.height);
    const H = b.toDataURL("image/jpeg", 0.7);
    n(1, a = [...a, H]);
  };
  ss(() => {
    const b = () => {
      u = i.duration;
      const C = u / Ao;
      let H = 0;
      const R = () => {
        v(), H++, H < Ao ? n(6, i.currentTime += C, i) : i.removeEventListener("seeked", R);
      };
      i.addEventListener("seeked", R), n(6, i.currentTime = 0, i);
    };
    i.readyState >= 1 ? b() : i.addEventListener("loadedmetadata", b);
  }), U1(() => {
    window.removeEventListener("mousemove", h), window.removeEventListener("mouseup", m), window.removeEventListener("keydown", p);
  }), ss(() => {
    window.addEventListener("mousemove", h), window.addEventListener("mouseup", m), window.addEventListener("keydown", p);
  });
  const y = () => _("left"), w = (b) => {
    (b.key === "ArrowLeft" || b.key == "ArrowRight") && _("left");
  }, B = () => _("right"), k = (b) => {
    (b.key === "ArrowLeft" || b.key == "ArrowRight") && _("right");
  };
  return t.$$set = (b) => {
    "videoElement" in b && n(6, i = b.videoElement), "trimmedDuration" in b && n(7, l = b.trimmedDuration), "dragStart" in b && n(8, o = b.dragStart), "dragEnd" in b && n(9, r = b.dragEnd), "loadingTimeline" in b && n(0, s = b.loadingTimeline);
  }, t.$$.update = () => {
    t.$$.dirty & /*thumbnails*/
    2 && n(0, s = a.length !== Ao);
  }, [
    s,
    a,
    c,
    f,
    _,
    m,
    i,
    l,
    o,
    r,
    y,
    w,
    B,
    k
  ];
}
class z1 extends R1 {
  constructor(e) {
    super(), D1(this, e, V1, G1, M1, {
      videoElement: 6,
      trimmedDuration: 7,
      dragStart: 8,
      dragEnd: 9,
      loadingTimeline: 0
    });
  }
}
const {
  SvelteComponent: X1,
  add_flush_callback: Pi,
  append: kn,
  attr: Fe,
  bind: Ri,
  binding_callbacks: Oi,
  check_outros: qi,
  create_component: vr,
  destroy_component: wr,
  detach: pt,
  element: gt,
  empty: W1,
  group_outros: Fi,
  init: Z1,
  insert: bt,
  listen: nl,
  mount_component: yr,
  noop: $o,
  run_all: J1,
  safe_not_equal: Q1,
  set_data: Y1,
  space: Gi,
  text: K1,
  toggle_class: Cn,
  transition_in: xe,
  transition_out: at
} = window.__gradio__svelte__internal, { onMount: $1 } = window.__gradio__svelte__internal;
function fs(t) {
  let e, n, i, l, o, r, s;
  function a(_) {
    t[13](_);
  }
  function u(_) {
    t[14](_);
  }
  function c(_) {
    t[15](_);
  }
  function f(_) {
    t[16](_);
  }
  let d = { videoElement: (
    /*videoElement*/
    t[2]
  ) };
  return (
    /*dragStart*/
    t[9] !== void 0 && (d.dragStart = /*dragStart*/
    t[9]), /*dragEnd*/
    t[10] !== void 0 && (d.dragEnd = /*dragEnd*/
    t[10]), /*trimmedDuration*/
    t[7] !== void 0 && (d.trimmedDuration = /*trimmedDuration*/
    t[7]), /*loadingTimeline*/
    t[11] !== void 0 && (d.loadingTimeline = /*loadingTimeline*/
    t[11]), n = new z1({ props: d }), Oi.push(() => Ri(n, "dragStart", a)), Oi.push(() => Ri(n, "dragEnd", u)), Oi.push(() => Ri(n, "trimmedDuration", c)), Oi.push(() => Ri(n, "loadingTimeline", f)), {
      c() {
        e = gt("div"), vr(n.$$.fragment), Fe(e, "class", "timeline-wrapper svelte-14ninhl");
      },
      m(_, m) {
        bt(_, e, m), yr(n, e, null), s = !0;
      },
      p(_, m) {
        const h = {};
        m & /*videoElement*/
        4 && (h.videoElement = /*videoElement*/
        _[2]), !i && m & /*dragStart*/
        512 && (i = !0, h.dragStart = /*dragStart*/
        _[9], Pi(() => i = !1)), !l && m & /*dragEnd*/
        1024 && (l = !0, h.dragEnd = /*dragEnd*/
        _[10], Pi(() => l = !1)), !o && m & /*trimmedDuration*/
        128 && (o = !0, h.trimmedDuration = /*trimmedDuration*/
        _[7], Pi(() => o = !1)), !r && m & /*loadingTimeline*/
        2048 && (r = !0, h.loadingTimeline = /*loadingTimeline*/
        _[11], Pi(() => r = !1)), n.$set(h);
      },
      i(_) {
        s || (xe(n.$$.fragment, _), s = !0);
      },
      o(_) {
        at(n.$$.fragment, _), s = !1;
      },
      d(_) {
        _ && pt(e), wr(n);
      }
    }
  );
}
function eb(t) {
  let e;
  return {
    c() {
      e = gt("div"), Fe(e, "class", "svelte-14ninhl");
    },
    m(n, i) {
      bt(n, e, i);
    },
    p: $o,
    d(n) {
      n && pt(e);
    }
  };
}
function tb(t) {
  let e, n = Sn(
    /*trimmedDuration*/
    t[7]
  ) + "", i;
  return {
    c() {
      e = gt("time"), i = K1(n), Fe(e, "aria-label", "duration of selected region in seconds"), Fe(e, "class", "svelte-14ninhl"), Cn(
        e,
        "hidden",
        /*loadingTimeline*/
        t[11]
      );
    },
    m(l, o) {
      bt(l, e, o), kn(e, i);
    },
    p(l, o) {
      o & /*trimmedDuration*/
      128 && n !== (n = Sn(
        /*trimmedDuration*/
        l[7]
      ) + "") && Y1(i, n), o & /*loadingTimeline*/
      2048 && Cn(
        e,
        "hidden",
        /*loadingTimeline*/
        l[11]
      );
    },
    d(l) {
      l && pt(e);
    }
  };
}
function ds(t) {
  let e, n, i, l, o;
  return n = new cr({}), {
    c() {
      e = gt("button"), vr(n.$$.fragment), Fe(e, "class", "action icon svelte-14ninhl"), e.disabled = /*processingVideo*/
      t[1], Fe(e, "aria-label", "Reset video to initial value");
    },
    m(r, s) {
      bt(r, e, s), yr(n, e, null), i = !0, l || (o = nl(
        e,
        "click",
        /*click_handler*/
        t[17]
      ), l = !0);
    },
    p(r, s) {
      (!i || s & /*processingVideo*/
      2) && (e.disabled = /*processingVideo*/
      r[1]);
    },
    i(r) {
      i || (xe(n.$$.fragment, r), i = !0);
    },
    o(r) {
      at(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && pt(e), wr(n), l = !1, o();
    }
  };
}
function _s(t) {
  let e, n, i, l;
  const o = [ib, nb], r = [];
  function s(a, u) {
    return (
      /*mode*/
      a[0] === "" ? 0 : 1
    );
  }
  return e = s(t), n = r[e] = o[e](t), {
    c() {
      n.c(), i = W1();
    },
    m(a, u) {
      r[e].m(a, u), bt(a, i, u), l = !0;
    },
    p(a, u) {
      let c = e;
      e = s(a), e === c ? r[e].p(a, u) : (Fi(), at(r[c], 1, 1, () => {
        r[c] = null;
      }), qi(), n = r[e], n ? n.p(a, u) : (n = r[e] = o[e](a), n.c()), xe(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (xe(n), l = !0);
    },
    o(a) {
      at(n), l = !1;
    },
    d(a) {
      a && pt(i), r[e].d(a);
    }
  };
}
function nb(t) {
  let e, n, i, l, o;
  return {
    c() {
      e = gt("button"), e.textContent = "Trim", n = Gi(), i = gt("button"), i.textContent = "Cancel", Fe(e, "class", "text-button svelte-14ninhl"), Cn(
        e,
        "hidden",
        /*loadingTimeline*/
        t[11]
      ), Fe(i, "class", "text-button svelte-14ninhl"), Cn(
        i,
        "hidden",
        /*loadingTimeline*/
        t[11]
      );
    },
    m(r, s) {
      bt(r, e, s), bt(r, n, s), bt(r, i, s), l || (o = [
        nl(
          e,
          "click",
          /*click_handler_1*/
          t[18]
        ),
        nl(
          i,
          "click",
          /*toggleTrimmingMode*/
          t[12]
        )
      ], l = !0);
    },
    p(r, s) {
      s & /*loadingTimeline*/
      2048 && Cn(
        e,
        "hidden",
        /*loadingTimeline*/
        r[11]
      ), s & /*loadingTimeline*/
      2048 && Cn(
        i,
        "hidden",
        /*loadingTimeline*/
        r[11]
      );
    },
    i: $o,
    o: $o,
    d(r) {
      r && (pt(e), pt(n), pt(i)), l = !1, J1(o);
    }
  };
}
function ib(t) {
  let e, n, i, l, o;
  return n = new Yh({}), {
    c() {
      e = gt("button"), vr(n.$$.fragment), e.disabled = /*processingVideo*/
      t[1], Fe(e, "class", "action icon svelte-14ninhl"), Fe(e, "aria-label", "Trim video to selection");
    },
    m(r, s) {
      bt(r, e, s), yr(n, e, null), i = !0, l || (o = nl(
        e,
        "click",
        /*toggleTrimmingMode*/
        t[12]
      ), l = !0);
    },
    p(r, s) {
      (!i || s & /*processingVideo*/
      2) && (e.disabled = /*processingVideo*/
      r[1]);
    },
    i(r) {
      i || (xe(n.$$.fragment, r), i = !0);
    },
    o(r) {
      at(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && pt(e), wr(n), l = !1, o();
    }
  };
}
function lb(t) {
  let e, n, i, l, o, r, s, a = (
    /*mode*/
    t[0] === "edit" && fs(t)
  );
  function u(m, h) {
    return (
      /*mode*/
      m[0] === "edit" && /*trimmedDuration*/
      m[7] !== null ? tb : eb
    );
  }
  let c = u(t), f = c(t), d = (
    /*showRedo*/
    t[3] && /*mode*/
    t[0] === "" && ds(t)
  ), _ = (
    /*interactive*/
    t[4] && _s(t)
  );
  return {
    c() {
      e = gt("div"), a && a.c(), n = Gi(), i = gt("div"), f.c(), l = Gi(), o = gt("div"), d && d.c(), r = Gi(), _ && _.c(), Fe(o, "class", "settings-wrapper svelte-14ninhl"), Fe(i, "class", "controls svelte-14ninhl"), Fe(i, "data-testid", "waveform-controls"), Fe(e, "class", "container svelte-14ninhl");
    },
    m(m, h) {
      bt(m, e, h), a && a.m(e, null), kn(e, n), kn(e, i), f.m(i, null), kn(i, l), kn(i, o), d && d.m(o, null), kn(o, r), _ && _.m(o, null), s = !0;
    },
    p(m, [h]) {
      /*mode*/
      m[0] === "edit" ? a ? (a.p(m, h), h & /*mode*/
      1 && xe(a, 1)) : (a = fs(m), a.c(), xe(a, 1), a.m(e, n)) : a && (Fi(), at(a, 1, 1, () => {
        a = null;
      }), qi()), c === (c = u(m)) && f ? f.p(m, h) : (f.d(1), f = c(m), f && (f.c(), f.m(i, l))), /*showRedo*/
      m[3] && /*mode*/
      m[0] === "" ? d ? (d.p(m, h), h & /*showRedo, mode*/
      9 && xe(d, 1)) : (d = ds(m), d.c(), xe(d, 1), d.m(o, r)) : d && (Fi(), at(d, 1, 1, () => {
        d = null;
      }), qi()), /*interactive*/
      m[4] ? _ ? (_.p(m, h), h & /*interactive*/
      16 && xe(_, 1)) : (_ = _s(m), _.c(), xe(_, 1), _.m(o, null)) : _ && (Fi(), at(_, 1, 1, () => {
        _ = null;
      }), qi());
    },
    i(m) {
      s || (xe(a), xe(d), xe(_), s = !0);
    },
    o(m) {
      at(a), at(d), at(_), s = !1;
    },
    d(m) {
      m && pt(e), a && a.d(), f.d(), d && d.d(), _ && _.d();
    }
  };
}
function ob(t, e, n) {
  let { videoElement: i } = e, { showRedo: l = !1 } = e, { interactive: o = !0 } = e, { mode: r = "" } = e, { handle_reset_value: s } = e, { handle_trim_video: a } = e, { processingVideo: u = !1 } = e, c;
  $1(async () => {
    n(8, c = await d1());
  });
  let f = null, d = 0, _ = 0, m = !1;
  const h = () => {
    r === "edit" ? (n(0, r = ""), n(7, f = i.duration)) : n(0, r = "edit");
  };
  function p(b) {
    d = b, n(9, d);
  }
  function v(b) {
    _ = b, n(10, _);
  }
  function y(b) {
    f = b, n(7, f), n(0, r), n(2, i);
  }
  function w(b) {
    m = b, n(11, m);
  }
  const B = () => {
    s(), n(0, r = "");
  }, k = () => {
    n(0, r = ""), n(1, u = !0), _1(c, d, _, i).then((b) => {
      a(b);
    }).then(() => {
      n(1, u = !1);
    });
  };
  return t.$$set = (b) => {
    "videoElement" in b && n(2, i = b.videoElement), "showRedo" in b && n(3, l = b.showRedo), "interactive" in b && n(4, o = b.interactive), "mode" in b && n(0, r = b.mode), "handle_reset_value" in b && n(5, s = b.handle_reset_value), "handle_trim_video" in b && n(6, a = b.handle_trim_video), "processingVideo" in b && n(1, u = b.processingVideo);
  }, t.$$.update = () => {
    t.$$.dirty & /*mode, trimmedDuration, videoElement*/
    133 && r === "edit" && f === null && i && n(7, f = i.duration);
  }, [
    r,
    u,
    i,
    l,
    o,
    s,
    a,
    f,
    c,
    d,
    _,
    m,
    h,
    p,
    v,
    y,
    w,
    B,
    k
  ];
}
class rb extends X1 {
  constructor(e) {
    super(), Z1(this, e, ob, lb, Q1, {
      videoElement: 2,
      showRedo: 3,
      interactive: 4,
      mode: 0,
      handle_reset_value: 5,
      handle_trim_video: 6,
      processingVideo: 1
    });
  }
}
const {
  SvelteComponent: ab,
  add_flush_callback: oi,
  append: De,
  attr: we,
  bind: ri,
  binding_callbacks: ai,
  bubble: ms,
  check_outros: hs,
  create_component: Rn,
  destroy_component: On,
  detach: Vi,
  element: yt,
  empty: sb,
  group_outros: ps,
  init: ub,
  insert: zi,
  listen: Xt,
  mount_component: Dn,
  prevent_default: gs,
  run_all: cb,
  safe_not_equal: fb,
  set_data: bs,
  space: ei,
  src_url_equal: vs,
  stop_propagation: db,
  text: Bo,
  toggle_class: ws,
  transition_in: rt,
  transition_out: _t
} = window.__gradio__svelte__internal, { createEventDispatcher: _b } = window.__gradio__svelte__internal;
function mb(t) {
  let e, n;
  return {
    c() {
      e = yt("track"), we(e, "kind", "captions"), vs(e.src, n = /*subtitle*/
      t[1]) || we(e, "src", n), e.default = !0;
    },
    m(i, l) {
      zi(i, e, l);
    },
    p(i, l) {
      l & /*subtitle*/
      2 && !vs(e.src, n = /*subtitle*/
      i[1]) && we(e, "src", n);
    },
    d(i) {
      i && Vi(e);
    }
  };
}
function hb(t) {
  let e, n;
  return e = new Bh({}), {
    c() {
      Rn(e.$$.fragment);
    },
    m(i, l) {
      Dn(e, i, l), n = !0;
    },
    i(i) {
      n || (rt(e.$$.fragment, i), n = !0);
    },
    o(i) {
      _t(e.$$.fragment, i), n = !1;
    },
    d(i) {
      On(e, i);
    }
  };
}
function pb(t) {
  let e, n;
  return e = new Dh({}), {
    c() {
      Rn(e.$$.fragment);
    },
    m(i, l) {
      Dn(e, i, l), n = !0;
    },
    i(i) {
      n || (rt(e.$$.fragment, i), n = !0);
    },
    o(i) {
      _t(e.$$.fragment, i), n = !1;
    },
    d(i) {
      On(e, i);
    }
  };
}
function gb(t) {
  let e, n;
  return e = new cr({}), {
    c() {
      Rn(e.$$.fragment);
    },
    m(i, l) {
      Dn(e, i, l), n = !0;
    },
    i(i) {
      n || (rt(e.$$.fragment, i), n = !0);
    },
    o(i) {
      _t(e.$$.fragment, i), n = !1;
    },
    d(i) {
      On(e, i);
    }
  };
}
function ys(t) {
  let e, n, i;
  function l(r) {
    t[26](r);
  }
  let o = {
    videoElement: (
      /*video*/
      t[10]
    ),
    showRedo: !0,
    handle_trim_video: (
      /*handle_trim_video*/
      t[16]
    ),
    handle_reset_value: (
      /*handle_reset_value*/
      t[6]
    )
  };
  return (
    /*processingVideo*/
    t[11] !== void 0 && (o.processingVideo = /*processingVideo*/
    t[11]), e = new rb({ props: o }), ai.push(() => ri(e, "processingVideo", l)), {
      c() {
        Rn(e.$$.fragment);
      },
      m(r, s) {
        Dn(e, r, s), i = !0;
      },
      p(r, s) {
        const a = {};
        s & /*video*/
        1024 && (a.videoElement = /*video*/
        r[10]), s & /*handle_reset_value*/
        64 && (a.handle_reset_value = /*handle_reset_value*/
        r[6]), !n && s & /*processingVideo*/
        2048 && (n = !0, a.processingVideo = /*processingVideo*/
        r[11], oi(() => n = !1)), e.$set(a);
      },
      i(r) {
        i || (rt(e.$$.fragment, r), i = !0);
      },
      o(r) {
        _t(e.$$.fragment, r), i = !1;
      },
      d(r) {
        On(e, r);
      }
    }
  );
}
function bb(t) {
  let e, n, i, l, o, r, s, a, u, c, f, d, _, m, h, p = Sn(
    /*time*/
    t[7]
  ) + "", v, y, w = Sn(
    /*duration*/
    t[8]
  ) + "", B, k, b, C, H, R, x, z, q, F, re, A;
  function ae(T) {
    t[20](T);
  }
  function N(T) {
    t[21](T);
  }
  function S(T) {
    t[22](T);
  }
  function pe(T) {
    t[23](T);
  }
  let P = {
    src: (
      /*src*/
      t[0]
    ),
    preload: "auto",
    autoplay: (
      /*autoplay*/
      t[3]
    ),
    "data-testid": `${/*label*/
    t[4]}-player`,
    processingVideo: (
      /*processingVideo*/
      t[11]
    ),
    $$slots: { default: [mb] },
    $$scope: { ctx: t }
  };
  /*time*/
  t[7] !== void 0 && (P.currentTime = /*time*/
  t[7]), /*duration*/
  t[8] !== void 0 && (P.duration = /*duration*/
  t[8]), /*paused*/
  t[9] !== void 0 && (P.paused = /*paused*/
  t[9]), /*video*/
  t[10] !== void 0 && (P.node = /*video*/
  t[10]), i = new Zu({ props: P }), ai.push(() => ri(i, "currentTime", ae)), ai.push(() => ri(i, "duration", N)), ai.push(() => ri(i, "paused", S)), ai.push(() => ri(i, "node", pe)), i.$on(
    "click",
    /*play_pause*/
    t[13]
  ), i.$on(
    "play",
    /*play_handler*/
    t[24]
  ), i.$on(
    "pause",
    /*pause_handler*/
    t[25]
  ), i.$on(
    "ended",
    /*handle_end*/
    t[15]
  );
  const J = [gb, pb, hb], Z = [];
  function g(T, I) {
    return (
      /*time*/
      T[7] === /*duration*/
      T[8] ? 0 : (
        /*paused*/
        T[9] ? 1 : 2
      )
    );
  }
  d = g(t), _ = Z[d] = J[d](t), x = new mh({});
  let E = (
    /*interactive*/
    t[5] && ys(t)
  );
  return {
    c() {
      e = yt("div"), n = yt("div"), Rn(i.$$.fragment), a = ei(), u = yt("div"), c = yt("div"), f = yt("span"), _.c(), m = ei(), h = yt("span"), v = Bo(p), y = Bo(" / "), B = Bo(w), k = ei(), b = yt("progress"), H = ei(), R = yt("div"), Rn(x.$$.fragment), z = ei(), E && E.c(), q = sb(), we(n, "class", "mirror-wrap svelte-1laj904"), ws(
        n,
        "mirror",
        /*mirror*/
        t[2]
      ), we(f, "role", "button"), we(f, "tabindex", "0"), we(f, "class", "icon svelte-1laj904"), we(f, "aria-label", "play-pause-replay-button"), we(h, "class", "time svelte-1laj904"), b.value = C = /*time*/
      t[7] / /*duration*/
      t[8] || 0, we(b, "class", "svelte-1laj904"), we(R, "role", "button"), we(R, "tabindex", "0"), we(R, "class", "icon svelte-1laj904"), we(R, "aria-label", "full-screen"), we(c, "class", "inner svelte-1laj904"), we(u, "class", "controls svelte-1laj904"), we(e, "class", "wrap svelte-1laj904");
    },
    m(T, I) {
      zi(T, e, I), De(e, n), Dn(i, n, null), De(e, a), De(e, u), De(u, c), De(c, f), Z[d].m(f, null), De(c, m), De(c, h), De(h, v), De(h, y), De(h, B), De(c, k), De(c, b), De(c, H), De(c, R), Dn(x, R, null), zi(T, z, I), E && E.m(T, I), zi(T, q, I), F = !0, re || (A = [
        Xt(
          f,
          "click",
          /*play_pause*/
          t[13]
        ),
        Xt(
          f,
          "keydown",
          /*play_pause*/
          t[13]
        ),
        Xt(
          b,
          "mousemove",
          /*handleMove*/
          t[12]
        ),
        Xt(b, "touchmove", gs(
          /*handleMove*/
          t[12]
        )),
        Xt(b, "click", db(gs(
          /*handle_click*/
          t[14]
        ))),
        Xt(
          R,
          "click",
          /*open_full_screen*/
          t[17]
        ),
        Xt(
          R,
          "keypress",
          /*open_full_screen*/
          t[17]
        )
      ], re = !0);
    },
    p(T, [I]) {
      const K = {};
      I & /*src*/
      1 && (K.src = /*src*/
      T[0]), I & /*autoplay*/
      8 && (K.autoplay = /*autoplay*/
      T[3]), I & /*label*/
      16 && (K["data-testid"] = `${/*label*/
      T[4]}-player`), I & /*processingVideo*/
      2048 && (K.processingVideo = /*processingVideo*/
      T[11]), I & /*$$scope, subtitle*/
      268435458 && (K.$$scope = { dirty: I, ctx: T }), !l && I & /*time*/
      128 && (l = !0, K.currentTime = /*time*/
      T[7], oi(() => l = !1)), !o && I & /*duration*/
      256 && (o = !0, K.duration = /*duration*/
      T[8], oi(() => o = !1)), !r && I & /*paused*/
      512 && (r = !0, K.paused = /*paused*/
      T[9], oi(() => r = !1)), !s && I & /*video*/
      1024 && (s = !0, K.node = /*video*/
      T[10], oi(() => s = !1)), i.$set(K), (!F || I & /*mirror*/
      4) && ws(
        n,
        "mirror",
        /*mirror*/
        T[2]
      );
      let ue = d;
      d = g(T), d !== ue && (ps(), _t(Z[ue], 1, 1, () => {
        Z[ue] = null;
      }), hs(), _ = Z[d], _ || (_ = Z[d] = J[d](T), _.c()), rt(_, 1), _.m(f, null)), (!F || I & /*time*/
      128) && p !== (p = Sn(
        /*time*/
        T[7]
      ) + "") && bs(v, p), (!F || I & /*duration*/
      256) && w !== (w = Sn(
        /*duration*/
        T[8]
      ) + "") && bs(B, w), (!F || I & /*time, duration*/
      384 && C !== (C = /*time*/
      T[7] / /*duration*/
      T[8] || 0)) && (b.value = C), /*interactive*/
      T[5] ? E ? (E.p(T, I), I & /*interactive*/
      32 && rt(E, 1)) : (E = ys(T), E.c(), rt(E, 1), E.m(q.parentNode, q)) : E && (ps(), _t(E, 1, 1, () => {
        E = null;
      }), hs());
    },
    i(T) {
      F || (rt(i.$$.fragment, T), rt(_), rt(x.$$.fragment, T), rt(E), F = !0);
    },
    o(T) {
      _t(i.$$.fragment, T), _t(_), _t(x.$$.fragment, T), _t(E), F = !1;
    },
    d(T) {
      T && (Vi(e), Vi(z), Vi(q)), On(i), Z[d].d(), On(x), E && E.d(T), re = !1, cb(A);
    }
  };
}
async function vb(t) {
  let e, n = t[0], i = 1;
  for (; i < t.length; ) {
    const l = t[i], o = t[i + 1];
    if (i += 2, (l === "optionalAccess" || l === "optionalCall") && n == null)
      return;
    l === "access" || l === "optionalAccess" ? (e = n, n = await o(n)) : (l === "call" || l === "optionalCall") && (n = await o((...r) => n.call(e, ...r)), e = void 0);
  }
  return n;
}
function wb(t, e, n) {
  let { root: i = "" } = e, { src: l } = e, { subtitle: o = null } = e, { mirror: r } = e, { autoplay: s = !0 } = e, { label: a = "test" } = e, { interactive: u = !1 } = e, { handle_change: c = () => {
  } } = e, { handle_reset_value: f = () => {
  } } = e;
  const d = _b();
  let _ = 0, m, h = !0, p, v = !1;
  function y(A) {
    if (!m)
      return;
    if (A.type === "click") {
      B(A);
      return;
    }
    if (A.type !== "touchmove" && !(A.buttons & 1))
      return;
    const ae = A.type === "touchmove" ? A.touches[0].clientX : A.clientX, { left: N, right: S } = A.currentTarget.getBoundingClientRect();
    n(7, _ = m * (ae - N) / (S - N));
  }
  async function w() {
    document.fullscreenElement != p && (p.currentTime > 0 && !p.paused && !p.ended && p.readyState > p.HAVE_CURRENT_DATA ? p.pause() : await p.play());
  }
  function B(A) {
    const { left: ae, right: N } = A.currentTarget.getBoundingClientRect();
    n(7, _ = m * (A.clientX - ae) / (N - ae));
  }
  function k() {
    d("stop"), d("end");
  }
  const b = async (A) => {
    let ae = new File([A], "video.mp4");
    const N = await lr([ae]);
    let S = (await vb([
      await ir(N, i),
      "optionalAccess",
      async (pe) => pe.filter,
      "call",
      async (pe) => pe(Boolean)
    ]))[0];
    c(S);
  };
  function C() {
    p.requestFullscreen();
  }
  function H(A) {
    _ = A, n(7, _);
  }
  function R(A) {
    m = A, n(8, m);
  }
  function x(A) {
    h = A, n(9, h);
  }
  function z(A) {
    p = A, n(10, p);
  }
  function q(A) {
    ms.call(this, t, A);
  }
  function F(A) {
    ms.call(this, t, A);
  }
  function re(A) {
    v = A, n(11, v);
  }
  return t.$$set = (A) => {
    "root" in A && n(18, i = A.root), "src" in A && n(0, l = A.src), "subtitle" in A && n(1, o = A.subtitle), "mirror" in A && n(2, r = A.mirror), "autoplay" in A && n(3, s = A.autoplay), "label" in A && n(4, a = A.label), "interactive" in A && n(5, u = A.interactive), "handle_change" in A && n(19, c = A.handle_change), "handle_reset_value" in A && n(6, f = A.handle_reset_value);
  }, [
    l,
    o,
    r,
    s,
    a,
    u,
    f,
    _,
    m,
    h,
    p,
    v,
    y,
    w,
    B,
    k,
    b,
    C,
    i,
    c,
    H,
    R,
    x,
    z,
    q,
    F,
    re
  ];
}
class Ju extends ab {
  constructor(e) {
    super(), ub(this, e, wb, bb, fb, {
      root: 18,
      src: 0,
      subtitle: 1,
      mirror: 2,
      autoplay: 3,
      label: 4,
      interactive: 5,
      handle_change: 19,
      handle_reset_value: 6
    });
  }
}
const {
  SvelteComponent: yb,
  add_flush_callback: Qu,
  append: er,
  attr: mi,
  bind: Yu,
  binding_callbacks: Ku,
  bubble: Wt,
  check_outros: Sl,
  create_component: jn,
  create_slot: kb,
  destroy_component: Mn,
  detach: St,
  element: il,
  empty: $u,
  get_all_dirty_from_scope: Eb,
  get_slot_changes: Sb,
  group_outros: Tl,
  init: Tb,
  insert: Tt,
  mount_component: xn,
  noop: tr,
  safe_not_equal: ec,
  set_data: ks,
  space: ll,
  text: Es,
  transition_in: Ne,
  transition_out: Ie,
  update_slot_base: Cb
} = window.__gradio__svelte__internal, { createEventDispatcher: Ab } = window.__gradio__svelte__internal;
function Bb(t) {
  let e, n, i, l, o, r, s;
  e = new B0({
    props: {
      i18n: (
        /*i18n*/
        t[11]
      ),
      download: (
        /*show_download_button*/
        t[5] ? (
          /*value*/
          t[0].url
        ) : null
      )
    }
  }), e.$on(
    "clear",
    /*handle_clear*/
    t[16]
  );
  const a = [Ib, Nb], u = [];
  function c(f, d) {
    return i == null && (i = !!c1()), i ? 0 : (
      /*value*/
      f[0].size ? 1 : -1
    );
  }
  return ~(l = c(t)) && (o = u[l] = a[l](t)), {
    c() {
      jn(e.$$.fragment), n = ll(), o && o.c(), r = $u();
    },
    m(f, d) {
      xn(e, f, d), Tt(f, n, d), ~l && u[l].m(f, d), Tt(f, r, d), s = !0;
    },
    p(f, d) {
      const _ = {};
      d & /*i18n*/
      2048 && (_.i18n = /*i18n*/
      f[11]), d & /*show_download_button, value*/
      33 && (_.download = /*show_download_button*/
      f[5] ? (
        /*value*/
        f[0].url
      ) : null), e.$set(_);
      let m = l;
      l = c(f), l === m ? ~l && u[l].p(f, d) : (o && (Tl(), Ie(u[m], 1, 1, () => {
        u[m] = null;
      }), Sl()), ~l ? (o = u[l], o ? o.p(f, d) : (o = u[l] = a[l](f), o.c()), Ne(o, 1), o.m(r.parentNode, r)) : o = null);
    },
    i(f) {
      s || (Ne(e.$$.fragment, f), Ne(o), s = !0);
    },
    o(f) {
      Ie(e.$$.fragment, f), Ie(o), s = !1;
    },
    d(f) {
      f && (St(n), St(r)), Mn(e, f), ~l && u[l].d(f);
    }
  };
}
function Lb(t) {
  let e, n, i, l;
  const o = [Pb, Hb], r = [];
  function s(a, u) {
    return (
      /*active_source*/
      a[1] === "upload" ? 0 : (
        /*active_source*/
        a[1] === "webcam" ? 1 : -1
      )
    );
  }
  return ~(n = s(t)) && (i = r[n] = o[n](t)), {
    c() {
      e = il("div"), i && i.c(), mi(e, "class", "upload-container svelte-hlh2yp");
    },
    m(a, u) {
      Tt(a, e, u), ~n && r[n].m(e, null), l = !0;
    },
    p(a, u) {
      let c = n;
      n = s(a), n === c ? ~n && r[n].p(a, u) : (i && (Tl(), Ie(r[c], 1, 1, () => {
        r[c] = null;
      }), Sl()), ~n ? (i = r[n], i ? i.p(a, u) : (i = r[n] = o[n](a), i.c()), Ne(i, 1), i.m(e, null)) : i = null);
    },
    i(a) {
      l || (Ne(i), l = !0);
    },
    o(a) {
      Ie(i), l = !1;
    },
    d(a) {
      a && St(e), ~n && r[n].d();
    }
  };
}
function Nb(t) {
  let e, n = (
    /*value*/
    (t[0].orig_name || /*value*/
    t[0].url) + ""
  ), i, l, o, r = es(
    /*value*/
    t[0].size
  ) + "", s;
  return {
    c() {
      e = il("div"), i = Es(n), l = ll(), o = il("div"), s = Es(r), mi(e, "class", "file-name svelte-hlh2yp"), mi(o, "class", "file-size svelte-hlh2yp");
    },
    m(a, u) {
      Tt(a, e, u), er(e, i), Tt(a, l, u), Tt(a, o, u), er(o, s);
    },
    p(a, u) {
      u & /*value*/
      1 && n !== (n = /*value*/
      (a[0].orig_name || /*value*/
      a[0].url) + "") && ks(i, n), u & /*value*/
      1 && r !== (r = es(
        /*value*/
        a[0].size
      ) + "") && ks(s, r);
    },
    i: tr,
    o: tr,
    d(a) {
      a && (St(e), St(l), St(o));
    }
  };
}
function Ib(t) {
  var o;
  let e = (
    /*value*/
    (o = t[0]) == null ? void 0 : o.url
  ), n, i, l = Ss(t);
  return {
    c() {
      l.c(), n = $u();
    },
    m(r, s) {
      l.m(r, s), Tt(r, n, s), i = !0;
    },
    p(r, s) {
      var a;
      s & /*value*/
      1 && ec(e, e = /*value*/
      (a = r[0]) == null ? void 0 : a.url) ? (Tl(), Ie(l, 1, 1, tr), Sl(), l = Ss(r), l.c(), Ne(l, 1), l.m(n.parentNode, n)) : l.p(r, s);
    },
    i(r) {
      i || (Ne(l), i = !0);
    },
    o(r) {
      Ie(l), i = !1;
    },
    d(r) {
      r && St(n), l.d(r);
    }
  };
}
function Ss(t) {
  var i;
  let e, n;
  return e = new Ju({
    props: {
      root: (
        /*root*/
        t[10]
      ),
      interactive: !0,
      autoplay: (
        /*autoplay*/
        t[9]
      ),
      src: (
        /*value*/
        t[0].url
      ),
      subtitle: (
        /*subtitle*/
        (i = t[2]) == null ? void 0 : i.url
      ),
      mirror: (
        /*mirror_webcam*/
        t[7] && /*active_source*/
        t[1] === "webcam"
      ),
      label: (
        /*label*/
        t[4]
      ),
      handle_change: (
        /*handle_change*/
        t[17]
      ),
      handle_reset_value: (
        /*handle_reset_value*/
        t[12]
      )
    }
  }), e.$on(
    "play",
    /*play_handler*/
    t[25]
  ), e.$on(
    "pause",
    /*pause_handler*/
    t[26]
  ), e.$on(
    "stop",
    /*stop_handler*/
    t[27]
  ), e.$on(
    "end",
    /*end_handler*/
    t[28]
  ), {
    c() {
      jn(e.$$.fragment);
    },
    m(l, o) {
      xn(e, l, o), n = !0;
    },
    p(l, o) {
      var s;
      const r = {};
      o & /*root*/
      1024 && (r.root = /*root*/
      l[10]), o & /*autoplay*/
      512 && (r.autoplay = /*autoplay*/
      l[9]), o & /*value*/
      1 && (r.src = /*value*/
      l[0].url), o & /*subtitle*/
      4 && (r.subtitle = /*subtitle*/
      (s = l[2]) == null ? void 0 : s.url), o & /*mirror_webcam, active_source*/
      130 && (r.mirror = /*mirror_webcam*/
      l[7] && /*active_source*/
      l[1] === "webcam"), o & /*label*/
      16 && (r.label = /*label*/
      l[4]), o & /*handle_reset_value*/
      4096 && (r.handle_reset_value = /*handle_reset_value*/
      l[12]), e.$set(r);
    },
    i(l) {
      n || (Ne(e.$$.fragment, l), n = !0);
    },
    o(l) {
      Ie(e.$$.fragment, l), n = !1;
    },
    d(l) {
      Mn(e, l);
    }
  };
}
function Hb(t) {
  let e, n;
  return e = new gg({
    props: {
      root: (
        /*root*/
        t[10]
      ),
      mirror_webcam: (
        /*mirror_webcam*/
        t[7]
      ),
      include_audio: (
        /*include_audio*/
        t[8]
      ),
      mode: "video",
      i18n: (
        /*i18n*/
        t[11]
      )
    }
  }), e.$on(
    "error",
    /*error_handler*/
    t[22]
  ), e.$on(
    "capture",
    /*handle_capture*/
    t[18]
  ), e.$on(
    "start_recording",
    /*start_recording_handler*/
    t[23]
  ), e.$on(
    "stop_recording",
    /*stop_recording_handler*/
    t[24]
  ), {
    c() {
      jn(e.$$.fragment);
    },
    m(i, l) {
      xn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*root*/
      1024 && (o.root = /*root*/
      i[10]), l & /*mirror_webcam*/
      128 && (o.mirror_webcam = /*mirror_webcam*/
      i[7]), l & /*include_audio*/
      256 && (o.include_audio = /*include_audio*/
      i[8]), l & /*i18n*/
      2048 && (o.i18n = /*i18n*/
      i[11]), e.$set(o);
    },
    i(i) {
      n || (Ne(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Mn(e, i);
    }
  };
}
function Pb(t) {
  let e, n, i;
  function l(r) {
    t[20](r);
  }
  let o = {
    filetype: "video/x-m4v,video/*",
    root: (
      /*root*/
      t[10]
    ),
    $$slots: { default: [Rb] },
    $$scope: { ctx: t }
  };
  return (
    /*dragging*/
    t[13] !== void 0 && (o.dragging = /*dragging*/
    t[13]), e = new Wd({ props: o }), Ku.push(() => Yu(e, "dragging", l)), e.$on(
      "load",
      /*handle_load*/
      t[15]
    ), e.$on(
      "error",
      /*error_handler_1*/
      t[21]
    ), {
      c() {
        jn(e.$$.fragment);
      },
      m(r, s) {
        xn(e, r, s), i = !0;
      },
      p(r, s) {
        const a = {};
        s & /*root*/
        1024 && (a.root = /*root*/
        r[10]), s & /*$$scope*/
        1073741824 && (a.$$scope = { dirty: s, ctx: r }), !n && s & /*dragging*/
        8192 && (n = !0, a.dragging = /*dragging*/
        r[13], Qu(() => n = !1)), e.$set(a);
      },
      i(r) {
        i || (Ne(e.$$.fragment, r), i = !0);
      },
      o(r) {
        Ie(e.$$.fragment, r), i = !1;
      },
      d(r) {
        Mn(e, r);
      }
    }
  );
}
function Rb(t) {
  let e;
  const n = (
    /*#slots*/
    t[19].default
  ), i = kb(
    n,
    t,
    /*$$scope*/
    t[30],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(l, o) {
      i && i.m(l, o), e = !0;
    },
    p(l, o) {
      i && i.p && (!e || o & /*$$scope*/
      1073741824) && Cb(
        i,
        n,
        l,
        /*$$scope*/
        l[30],
        e ? Sb(
          n,
          /*$$scope*/
          l[30],
          o,
          null
        ) : Eb(
          /*$$scope*/
          l[30]
        ),
        null
      );
    },
    i(l) {
      e || (Ne(i, l), e = !0);
    },
    o(l) {
      Ie(i, l), e = !1;
    },
    d(l) {
      i && i.d(l);
    }
  };
}
function Ob(t) {
  let e, n, i, l, o, r, s, a, u;
  e = new yu({
    props: {
      show_label: (
        /*show_label*/
        t[6]
      ),
      Icon: fr,
      label: (
        /*label*/
        t[4] || "Video"
      )
    }
  });
  const c = [Lb, Bb], f = [];
  function d(h, p) {
    return (
      /*value*/
      h[0] === null || /*value*/
      h[0].url === void 0 ? 0 : 1
    );
  }
  l = d(t), o = f[l] = c[l](t);
  function _(h) {
    t[29](h);
  }
  let m = {
    sources: (
      /*sources*/
      t[3]
    ),
    handle_clear: (
      /*handle_clear*/
      t[16]
    )
  };
  return (
    /*active_source*/
    t[1] !== void 0 && (m.active_source = /*active_source*/
    t[1]), s = new e0({ props: m }), Ku.push(() => Yu(s, "active_source", _)), {
      c() {
        jn(e.$$.fragment), n = ll(), i = il("div"), o.c(), r = ll(), jn(s.$$.fragment), mi(i, "data-testid", "video"), mi(i, "class", "video-container svelte-hlh2yp");
      },
      m(h, p) {
        xn(e, h, p), Tt(h, n, p), Tt(h, i, p), f[l].m(i, null), er(i, r), xn(s, i, null), u = !0;
      },
      p(h, [p]) {
        const v = {};
        p & /*show_label*/
        64 && (v.show_label = /*show_label*/
        h[6]), p & /*label*/
        16 && (v.label = /*label*/
        h[4] || "Video"), e.$set(v);
        let y = l;
        l = d(h), l === y ? f[l].p(h, p) : (Tl(), Ie(f[y], 1, 1, () => {
          f[y] = null;
        }), Sl(), o = f[l], o ? o.p(h, p) : (o = f[l] = c[l](h), o.c()), Ne(o, 1), o.m(i, r));
        const w = {};
        p & /*sources*/
        8 && (w.sources = /*sources*/
        h[3]), !a && p & /*active_source*/
        2 && (a = !0, w.active_source = /*active_source*/
        h[1], Qu(() => a = !1)), s.$set(w);
      },
      i(h) {
        u || (Ne(e.$$.fragment, h), Ne(o), Ne(s.$$.fragment, h), u = !0);
      },
      o(h) {
        Ie(e.$$.fragment, h), Ie(o), Ie(s.$$.fragment, h), u = !1;
      },
      d(h) {
        h && (St(n), St(i)), Mn(e, h), f[l].d(), Mn(s);
      }
    }
  );
}
function Db(t, e, n) {
  let { $$slots: i = {}, $$scope: l } = e, { value: o = null } = e, { subtitle: r = null } = e, { sources: s = ["webcam", "upload"] } = e, { label: a = void 0 } = e, { show_download_button: u = !1 } = e, { show_label: c = !0 } = e, { mirror_webcam: f = !1 } = e, { include_audio: d } = e, { autoplay: _ } = e, { root: m } = e, { i18n: h } = e, { active_source: p = "webcam" } = e, { handle_reset_value: v = () => {
  } } = e;
  const y = Ab();
  function w({ detail: S }) {
    n(0, o = S), y("change", S), y("upload", S);
  }
  function B() {
    n(0, o = null), y("change", null), y("clear");
  }
  function k(S) {
    y("change", S);
  }
  function b({ detail: S }) {
    y("change", S);
  }
  let C = !1;
  function H(S) {
    C = S, n(13, C);
  }
  const R = ({ detail: S }) => y("error", S);
  function x(S) {
    Wt.call(this, t, S);
  }
  function z(S) {
    Wt.call(this, t, S);
  }
  function q(S) {
    Wt.call(this, t, S);
  }
  function F(S) {
    Wt.call(this, t, S);
  }
  function re(S) {
    Wt.call(this, t, S);
  }
  function A(S) {
    Wt.call(this, t, S);
  }
  function ae(S) {
    Wt.call(this, t, S);
  }
  function N(S) {
    p = S, n(1, p);
  }
  return t.$$set = (S) => {
    "value" in S && n(0, o = S.value), "subtitle" in S && n(2, r = S.subtitle), "sources" in S && n(3, s = S.sources), "label" in S && n(4, a = S.label), "show_download_button" in S && n(5, u = S.show_download_button), "show_label" in S && n(6, c = S.show_label), "mirror_webcam" in S && n(7, f = S.mirror_webcam), "include_audio" in S && n(8, d = S.include_audio), "autoplay" in S && n(9, _ = S.autoplay), "root" in S && n(10, m = S.root), "i18n" in S && n(11, h = S.i18n), "active_source" in S && n(1, p = S.active_source), "handle_reset_value" in S && n(12, v = S.handle_reset_value), "$$scope" in S && n(30, l = S.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*dragging*/
    8192 && y("drag", C);
  }, [
    o,
    p,
    r,
    s,
    a,
    u,
    c,
    f,
    d,
    _,
    m,
    h,
    v,
    C,
    y,
    w,
    B,
    k,
    b,
    i,
    H,
    R,
    x,
    z,
    q,
    F,
    re,
    A,
    ae,
    N,
    l
  ];
}
class jb extends yb {
  constructor(e) {
    super(), Tb(this, e, Db, Ob, ec, {
      value: 0,
      subtitle: 2,
      sources: 3,
      label: 4,
      show_download_button: 5,
      show_label: 6,
      mirror_webcam: 7,
      include_audio: 8,
      autoplay: 9,
      root: 10,
      i18n: 11,
      active_source: 1,
      handle_reset_value: 12
    });
  }
}
const {
  SvelteComponent: Mb,
  append: xb,
  attr: Ts,
  bubble: wn,
  check_outros: Xi,
  create_component: cn,
  destroy_component: fn,
  detach: ol,
  element: Ub,
  empty: qb,
  group_outros: Wi,
  init: Fb,
  insert: rl,
  mount_component: dn,
  noop: tc,
  safe_not_equal: nc,
  space: nr,
  transition_in: ye,
  transition_out: Le
} = window.__gradio__svelte__internal, { createEventDispatcher: Gb, afterUpdate: Vb, tick: zb } = window.__gradio__svelte__internal;
function Xb(t) {
  let e = (
    /*value*/
    t[0].url
  ), n, i, l, o, r = Cs(t), s = (
    /*show_download_button*/
    t[6] && As(t)
  ), a = (
    /*show_share_button*/
    t[5] && Bs(t)
  );
  return {
    c() {
      r.c(), n = nr(), i = Ub("div"), s && s.c(), l = nr(), a && a.c(), Ts(i, "class", "icon-buttons svelte-1mrvp2o"), Ts(i, "data-testid", "download-div");
    },
    m(u, c) {
      r.m(u, c), rl(u, n, c), rl(u, i, c), s && s.m(i, null), xb(i, l), a && a.m(i, null), o = !0;
    },
    p(u, c) {
      c & /*value*/
      1 && nc(e, e = /*value*/
      u[0].url) ? (Wi(), Le(r, 1, 1, tc), Xi(), r = Cs(u), r.c(), ye(r, 1), r.m(n.parentNode, n)) : r.p(u, c), /*show_download_button*/
      u[6] ? s ? (s.p(u, c), c & /*show_download_button*/
      64 && ye(s, 1)) : (s = As(u), s.c(), ye(s, 1), s.m(i, l)) : s && (Wi(), Le(s, 1, 1, () => {
        s = null;
      }), Xi()), /*show_share_button*/
      u[5] ? a ? (a.p(u, c), c & /*show_share_button*/
      32 && ye(a, 1)) : (a = Bs(u), a.c(), ye(a, 1), a.m(i, null)) : a && (Wi(), Le(a, 1, 1, () => {
        a = null;
      }), Xi());
    },
    i(u) {
      o || (ye(r), ye(s), ye(a), o = !0);
    },
    o(u) {
      Le(r), Le(s), Le(a), o = !1;
    },
    d(u) {
      u && (ol(n), ol(i)), r.d(u), s && s.d(), a && a.d();
    }
  };
}
function Wb(t) {
  let e, n;
  return e = new tm({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [Jb] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      cn(e.$$.fragment);
    },
    m(i, l) {
      dn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*$$scope*/
      262144 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (ye(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Le(e.$$.fragment, i), n = !1;
    },
    d(i) {
      fn(e, i);
    }
  };
}
function Cs(t) {
  var i;
  let e, n;
  return e = new Ju({
    props: {
      src: (
        /*value*/
        t[0].url
      ),
      subtitle: (
        /*subtitle*/
        (i = t[1]) == null ? void 0 : i.url
      ),
      autoplay: (
        /*autoplay*/
        t[4]
      ),
      mirror: !1,
      label: (
        /*label*/
        t[2]
      ),
      interactive: !1
    }
  }), e.$on(
    "play",
    /*play_handler*/
    t[8]
  ), e.$on(
    "pause",
    /*pause_handler*/
    t[9]
  ), e.$on(
    "stop",
    /*stop_handler*/
    t[10]
  ), e.$on(
    "end",
    /*end_handler*/
    t[11]
  ), {
    c() {
      cn(e.$$.fragment);
    },
    m(l, o) {
      dn(e, l, o), n = !0;
    },
    p(l, o) {
      var s;
      const r = {};
      o & /*value*/
      1 && (r.src = /*value*/
      l[0].url), o & /*subtitle*/
      2 && (r.subtitle = /*subtitle*/
      (s = l[1]) == null ? void 0 : s.url), o & /*autoplay*/
      16 && (r.autoplay = /*autoplay*/
      l[4]), o & /*label*/
      4 && (r.label = /*label*/
      l[2]), e.$set(r);
    },
    i(l) {
      n || (ye(e.$$.fragment, l), n = !0);
    },
    o(l) {
      Le(e.$$.fragment, l), n = !1;
    },
    d(l) {
      fn(e, l);
    }
  };
}
function As(t) {
  let e, n;
  return e = new qu({
    props: {
      href: (
        /*value*/
        t[0].url
      ),
      download: (
        /*value*/
        t[0].orig_name || /*value*/
        t[0].path
      ),
      $$slots: { default: [Zb] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      cn(e.$$.fragment);
    },
    m(i, l) {
      dn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*value*/
      1 && (o.href = /*value*/
      i[0].url), l & /*value*/
      1 && (o.download = /*value*/
      i[0].orig_name || /*value*/
      i[0].path), l & /*$$scope*/
      262144 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (ye(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Le(e.$$.fragment, i), n = !1;
    },
    d(i) {
      fn(e, i);
    }
  };
}
function Zb(t) {
  let e, n;
  return e = new Fn({
    props: { Icon: Su, label: "Download" }
  }), {
    c() {
      cn(e.$$.fragment);
    },
    m(i, l) {
      dn(e, i, l), n = !0;
    },
    p: tc,
    i(i) {
      n || (ye(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Le(e.$$.fragment, i), n = !1;
    },
    d(i) {
      fn(e, i);
    }
  };
}
function Bs(t) {
  let e, n;
  return e = new jp({
    props: {
      i18n: (
        /*i18n*/
        t[7]
      ),
      value: (
        /*value*/
        t[0]
      ),
      formatter: (
        /*func*/
        t[12]
      )
    }
  }), e.$on(
    "error",
    /*error_handler*/
    t[13]
  ), e.$on(
    "share",
    /*share_handler*/
    t[14]
  ), {
    c() {
      cn(e.$$.fragment);
    },
    m(i, l) {
      dn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*i18n*/
      128 && (o.i18n = /*i18n*/
      i[7]), l & /*value*/
      1 && (o.value = /*value*/
      i[0]), e.$set(o);
    },
    i(i) {
      n || (ye(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Le(e.$$.fragment, i), n = !1;
    },
    d(i) {
      fn(e, i);
    }
  };
}
function Jb(t) {
  let e, n;
  return e = new fr({}), {
    c() {
      cn(e.$$.fragment);
    },
    m(i, l) {
      dn(e, i, l), n = !0;
    },
    i(i) {
      n || (ye(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Le(e.$$.fragment, i), n = !1;
    },
    d(i) {
      fn(e, i);
    }
  };
}
function Qb(t) {
  let e, n, i, l, o, r;
  e = new yu({
    props: {
      show_label: (
        /*show_label*/
        t[3]
      ),
      Icon: fr,
      label: (
        /*label*/
        t[2] || "Video"
      )
    }
  });
  const s = [Wb, Xb], a = [];
  function u(c, f) {
    return (
      /*value*/
      c[0] === null || /*value*/
      c[0].url === void 0 ? 0 : 1
    );
  }
  return i = u(t), l = a[i] = s[i](t), {
    c() {
      cn(e.$$.fragment), n = nr(), l.c(), o = qb();
    },
    m(c, f) {
      dn(e, c, f), rl(c, n, f), a[i].m(c, f), rl(c, o, f), r = !0;
    },
    p(c, [f]) {
      const d = {};
      f & /*show_label*/
      8 && (d.show_label = /*show_label*/
      c[3]), f & /*label*/
      4 && (d.label = /*label*/
      c[2] || "Video"), e.$set(d);
      let _ = i;
      i = u(c), i === _ ? a[i].p(c, f) : (Wi(), Le(a[_], 1, 1, () => {
        a[_] = null;
      }), Xi(), l = a[i], l ? l.p(c, f) : (l = a[i] = s[i](c), l.c()), ye(l, 1), l.m(o.parentNode, o));
    },
    i(c) {
      r || (ye(e.$$.fragment, c), ye(l), r = !0);
    },
    o(c) {
      Le(e.$$.fragment, c), Le(l), r = !1;
    },
    d(c) {
      c && (ol(n), ol(o)), fn(e, c), a[i].d(c);
    }
  };
}
function Yb(t, e, n) {
  let { value: i = null } = e, { subtitle: l = null } = e, { label: o = void 0 } = e, { show_label: r = !0 } = e, { autoplay: s = !0 } = e, { show_share_button: a = !0 } = e, { show_download_button: u = !0 } = e, { i18n: c } = e, f = null, d = null;
  const _ = Gb();
  Vb(async () => {
    i !== f && l !== d && d !== null && (f = i, n(0, i = null), await zb(), n(0, i = f)), f = i, d = l;
  });
  function m(k) {
    wn.call(this, t, k);
  }
  function h(k) {
    wn.call(this, t, k);
  }
  function p(k) {
    wn.call(this, t, k);
  }
  function v(k) {
    wn.call(this, t, k);
  }
  const y = async (k) => k ? await Sp(k.data, "url") : "";
  function w(k) {
    wn.call(this, t, k);
  }
  function B(k) {
    wn.call(this, t, k);
  }
  return t.$$set = (k) => {
    "value" in k && n(0, i = k.value), "subtitle" in k && n(1, l = k.subtitle), "label" in k && n(2, o = k.label), "show_label" in k && n(3, r = k.show_label), "autoplay" in k && n(4, s = k.autoplay), "show_share_button" in k && n(5, a = k.show_share_button), "show_download_button" in k && n(6, u = k.show_download_button), "i18n" in k && n(7, c = k.i18n);
  }, t.$$.update = () => {
    t.$$.dirty & /*value*/
    1 && i && _("change", i);
  }, [
    i,
    l,
    o,
    r,
    s,
    a,
    u,
    c,
    m,
    h,
    p,
    v,
    y,
    w,
    B
  ];
}
class Kb extends Mb {
  constructor(e) {
    super(), Fb(this, e, Yb, Qb, nc, {
      value: 0,
      subtitle: 1,
      label: 2,
      show_label: 3,
      autoplay: 4,
      show_share_button: 5,
      show_download_button: 6,
      i18n: 7
    });
  }
}
const {
  SvelteComponent: $b,
  add_flush_callback: e2,
  append: t2,
  attr: n2,
  bind: i2,
  binding_callbacks: l2,
  check_outros: o2,
  create_component: r2,
  destroy_component: a2,
  detach: Cl,
  element: ic,
  empty: lc,
  group_outros: s2,
  init: u2,
  insert: Al,
  is_function: Ls,
  mount_component: c2,
  noop: Ns,
  safe_not_equal: f2,
  set_data: d2,
  text: _2,
  toggle_class: yn,
  transition_in: ci,
  transition_out: al
} = window.__gradio__svelte__internal;
function Is(t) {
  let e, n, i, l;
  const o = [h2, m2], r = [];
  function s(a, u) {
    return 0;
  }
  return e = s(), n = r[e] = o[e](t), {
    c() {
      n.c(), i = lc();
    },
    m(a, u) {
      r[e].m(a, u), Al(a, i, u), l = !0;
    },
    p(a, u) {
      n.p(a, u);
    },
    i(a) {
      l || (ci(n), l = !0);
    },
    o(a) {
      al(n), l = !1;
    },
    d(a) {
      a && Cl(i), r[e].d(a);
    }
  };
}
function m2(t) {
  let e, n;
  return {
    c() {
      e = ic("div"), n = _2(
        /*value*/
        t[2]
      );
    },
    m(i, l) {
      Al(i, e, l), t2(e, n);
    },
    p(i, l) {
      l & /*value*/
      4 && d2(
        n,
        /*value*/
        i[2]
      );
    },
    i: Ns,
    o: Ns,
    d(i) {
      i && Cl(e);
    }
  };
}
function h2(t) {
  var s;
  let e, n, i, l;
  function o(a) {
    t[5](a);
  }
  let r = {
    muted: !0,
    playsinline: !0,
    src: (
      /*value*/
      (s = t[2]) == null ? void 0 : s.video.url
    )
  };
  return (
    /*video*/
    t[3] !== void 0 && (r.node = /*video*/
    t[3]), n = new Zu({ props: r }), l2.push(() => i2(n, "node", o)), n.$on(
      "loadeddata",
      /*init*/
      t[4]
    ), n.$on("mouseover", function() {
      Ls(
        /*video*/
        t[3].play.bind(
          /*video*/
          t[3]
        )
      ) && t[3].play.bind(
        /*video*/
        t[3]
      ).apply(this, arguments);
    }), n.$on("mouseout", function() {
      Ls(
        /*video*/
        t[3].pause.bind(
          /*video*/
          t[3]
        )
      ) && t[3].pause.bind(
        /*video*/
        t[3]
      ).apply(this, arguments);
    }), {
      c() {
        e = ic("div"), r2(n.$$.fragment), n2(e, "class", "container svelte-13u05e4"), yn(
          e,
          "table",
          /*type*/
          t[0] === "table"
        ), yn(
          e,
          "gallery",
          /*type*/
          t[0] === "gallery"
        ), yn(
          e,
          "selected",
          /*selected*/
          t[1]
        );
      },
      m(a, u) {
        Al(a, e, u), c2(n, e, null), l = !0;
      },
      p(a, u) {
        var f;
        t = a;
        const c = {};
        u & /*value*/
        4 && (c.src = /*value*/
        (f = t[2]) == null ? void 0 : f.video.url), !i && u & /*video*/
        8 && (i = !0, c.node = /*video*/
        t[3], e2(() => i = !1)), n.$set(c), (!l || u & /*type*/
        1) && yn(
          e,
          "table",
          /*type*/
          t[0] === "table"
        ), (!l || u & /*type*/
        1) && yn(
          e,
          "gallery",
          /*type*/
          t[0] === "gallery"
        ), (!l || u & /*selected*/
        2) && yn(
          e,
          "selected",
          /*selected*/
          t[1]
        );
      },
      i(a) {
        l || (ci(n.$$.fragment, a), l = !0);
      },
      o(a) {
        al(n.$$.fragment, a), l = !1;
      },
      d(a) {
        a && Cl(e), a2(n);
      }
    }
  );
}
function p2(t) {
  let e, n, i = (
    /*value*/
    t[2] && Is(t)
  );
  return {
    c() {
      i && i.c(), e = lc();
    },
    m(l, o) {
      i && i.m(l, o), Al(l, e, o), n = !0;
    },
    p(l, [o]) {
      /*value*/
      l[2] ? i ? (i.p(l, o), o & /*value*/
      4 && ci(i, 1)) : (i = Is(l), i.c(), ci(i, 1), i.m(e.parentNode, e)) : i && (s2(), al(i, 1, 1, () => {
        i = null;
      }), o2());
    },
    i(l) {
      n || (ci(i), n = !0);
    },
    o(l) {
      al(i), n = !1;
    },
    d(l) {
      l && Cl(e), i && i.d(l);
    }
  };
}
function g2(t, e, n) {
  let { type: i } = e, { selected: l = !1 } = e, { value: o } = e, r;
  async function s() {
    n(3, r.muted = !0, r), n(3, r.playsInline = !0, r), n(3, r.controls = !1, r), r.setAttribute("muted", ""), await r.play(), r.pause();
  }
  function a(u) {
    r = u, n(3, r);
  }
  return t.$$set = (u) => {
    "type" in u && n(0, i = u.type), "selected" in u && n(1, l = u.selected), "value" in u && n(2, o = u.value);
  }, [i, l, o, r, s, a];
}
class x2 extends $b {
  constructor(e) {
    super(), u2(this, e, g2, p2, f2, { type: 0, selected: 1, value: 2 });
  }
}
const {
  SvelteComponent: b2,
  assign: oc,
  check_outros: v2,
  create_component: rn,
  destroy_component: an,
  detach: kr,
  empty: w2,
  flush: se,
  get_spread_object: rc,
  get_spread_update: ac,
  group_outros: y2,
  init: k2,
  insert: Er,
  mount_component: sn,
  safe_not_equal: E2,
  space: sc,
  transition_in: At,
  transition_out: Bt
} = window.__gradio__svelte__internal;
function S2(t) {
  let e, n;
  return e = new wu({
    props: {
      visible: (
        /*visible*/
        t[4]
      ),
      variant: (
        /*value*/
        t[0] === null && /*active_source*/
        t[21] === "upload" ? "dashed" : "solid"
      ),
      border_mode: (
        /*dragging*/
        t[24] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        t[2]
      ),
      elem_classes: (
        /*elem_classes*/
        t[3]
      ),
      height: (
        /*height*/
        t[9]
      ),
      width: (
        /*width*/
        t[10]
      ),
      container: (
        /*container*/
        t[11]
      ),
      scale: (
        /*scale*/
        t[12]
      ),
      min_width: (
        /*min_width*/
        t[13]
      ),
      allow_overflow: !1,
      $$slots: { default: [A2] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      rn(e.$$.fragment);
    },
    m(i, l) {
      sn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*visible*/
      16 && (o.visible = /*visible*/
      i[4]), l[0] & /*value, active_source*/
      2097153 && (o.variant = /*value*/
      i[0] === null && /*active_source*/
      i[21] === "upload" ? "dashed" : "solid"), l[0] & /*dragging*/
      16777216 && (o.border_mode = /*dragging*/
      i[24] ? "focus" : "base"), l[0] & /*elem_id*/
      4 && (o.elem_id = /*elem_id*/
      i[2]), l[0] & /*elem_classes*/
      8 && (o.elem_classes = /*elem_classes*/
      i[3]), l[0] & /*height*/
      512 && (o.height = /*height*/
      i[9]), l[0] & /*width*/
      1024 && (o.width = /*width*/
      i[10]), l[0] & /*container*/
      2048 && (o.container = /*container*/
      i[11]), l[0] & /*scale*/
      4096 && (o.scale = /*scale*/
      i[12]), l[0] & /*min_width*/
      8192 && (o.min_width = /*min_width*/
      i[13]), l[0] & /*_video, _subtitle, label, show_label, show_download_button, sources, active_source, mirror_webcam, include_audio, autoplay, root, gradio, dragging, loading_status*/
      33243618 | l[1] & /*$$scope*/
      16384 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (At(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Bt(e.$$.fragment, i), n = !1;
    },
    d(i) {
      an(e, i);
    }
  };
}
function T2(t) {
  let e, n;
  return e = new wu({
    props: {
      visible: (
        /*visible*/
        t[4]
      ),
      variant: (
        /*value*/
        t[0] === null && /*active_source*/
        t[21] === "upload" ? "dashed" : "solid"
      ),
      border_mode: (
        /*dragging*/
        t[24] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        t[2]
      ),
      elem_classes: (
        /*elem_classes*/
        t[3]
      ),
      height: (
        /*height*/
        t[9]
      ),
      width: (
        /*width*/
        t[10]
      ),
      container: (
        /*container*/
        t[11]
      ),
      scale: (
        /*scale*/
        t[12]
      ),
      min_width: (
        /*min_width*/
        t[13]
      ),
      allow_overflow: !1,
      $$slots: { default: [B2] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      rn(e.$$.fragment);
    },
    m(i, l) {
      sn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*visible*/
      16 && (o.visible = /*visible*/
      i[4]), l[0] & /*value, active_source*/
      2097153 && (o.variant = /*value*/
      i[0] === null && /*active_source*/
      i[21] === "upload" ? "dashed" : "solid"), l[0] & /*dragging*/
      16777216 && (o.border_mode = /*dragging*/
      i[24] ? "focus" : "base"), l[0] & /*elem_id*/
      4 && (o.elem_id = /*elem_id*/
      i[2]), l[0] & /*elem_classes*/
      8 && (o.elem_classes = /*elem_classes*/
      i[3]), l[0] & /*height*/
      512 && (o.height = /*height*/
      i[9]), l[0] & /*width*/
      1024 && (o.width = /*width*/
      i[10]), l[0] & /*container*/
      2048 && (o.container = /*container*/
      i[11]), l[0] & /*scale*/
      4096 && (o.scale = /*scale*/
      i[12]), l[0] & /*min_width*/
      8192 && (o.min_width = /*min_width*/
      i[13]), l[0] & /*_video, _subtitle, label, show_label, autoplay, show_share_button, show_download_button, gradio, loading_status*/
      12828962 | l[1] & /*$$scope*/
      16384 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (At(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Bt(e.$$.fragment, i), n = !1;
    },
    d(i) {
      an(e, i);
    }
  };
}
function C2(t) {
  let e, n;
  return e = new Wp({
    props: {
      i18n: (
        /*gradio*/
        t[17].i18n
      ),
      type: "video"
    }
  }), {
    c() {
      rn(e.$$.fragment);
    },
    m(i, l) {
      sn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*gradio*/
      131072 && (o.i18n = /*gradio*/
      i[17].i18n), e.$set(o);
    },
    i(i) {
      n || (At(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Bt(e.$$.fragment, i), n = !1;
    },
    d(i) {
      an(e, i);
    }
  };
}
function A2(t) {
  let e, n, i, l;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        t[17].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      t[17].i18n
    ) },
    /*loading_status*/
    t[1]
  ];
  let r = {};
  for (let s = 0; s < o.length; s += 1)
    r = oc(r, o[s]);
  return e = new Wu({ props: r }), i = new jb({
    props: {
      value: (
        /*_video*/
        t[22]
      ),
      subtitle: (
        /*_subtitle*/
        t[23]
      ),
      label: (
        /*label*/
        t[5]
      ),
      show_label: (
        /*show_label*/
        t[8]
      ),
      show_download_button: (
        /*show_download_button*/
        t[16]
      ),
      sources: (
        /*sources*/
        t[6]
      ),
      active_source: (
        /*active_source*/
        t[21]
      ),
      mirror_webcam: (
        /*mirror_webcam*/
        t[19]
      ),
      include_audio: (
        /*include_audio*/
        t[20]
      ),
      autoplay: (
        /*autoplay*/
        t[14]
      ),
      root: (
        /*root*/
        t[7]
      ),
      handle_reset_value: (
        /*handle_reset_value*/
        t[25]
      ),
      i18n: (
        /*gradio*/
        t[17].i18n
      ),
      $$slots: { default: [C2] },
      $$scope: { ctx: t }
    }
  }), i.$on(
    "change",
    /*handle_change*/
    t[26]
  ), i.$on(
    "drag",
    /*drag_handler*/
    t[36]
  ), i.$on(
    "error",
    /*handle_error*/
    t[27]
  ), i.$on(
    "clear",
    /*clear_handler*/
    t[37]
  ), i.$on(
    "play",
    /*play_handler_1*/
    t[38]
  ), i.$on(
    "pause",
    /*pause_handler_1*/
    t[39]
  ), i.$on(
    "upload",
    /*upload_handler*/
    t[40]
  ), i.$on(
    "stop",
    /*stop_handler_1*/
    t[41]
  ), i.$on(
    "end",
    /*end_handler_1*/
    t[42]
  ), i.$on(
    "start_recording",
    /*start_recording_handler*/
    t[43]
  ), i.$on(
    "stop_recording",
    /*stop_recording_handler*/
    t[44]
  ), {
    c() {
      rn(e.$$.fragment), n = sc(), rn(i.$$.fragment);
    },
    m(s, a) {
      sn(e, s, a), Er(s, n, a), sn(i, s, a), l = !0;
    },
    p(s, a) {
      const u = a[0] & /*gradio, loading_status*/
      131074 ? ac(o, [
        a[0] & /*gradio*/
        131072 && {
          autoscroll: (
            /*gradio*/
            s[17].autoscroll
          )
        },
        a[0] & /*gradio*/
        131072 && { i18n: (
          /*gradio*/
          s[17].i18n
        ) },
        a[0] & /*loading_status*/
        2 && rc(
          /*loading_status*/
          s[1]
        )
      ]) : {};
      e.$set(u);
      const c = {};
      a[0] & /*_video*/
      4194304 && (c.value = /*_video*/
      s[22]), a[0] & /*_subtitle*/
      8388608 && (c.subtitle = /*_subtitle*/
      s[23]), a[0] & /*label*/
      32 && (c.label = /*label*/
      s[5]), a[0] & /*show_label*/
      256 && (c.show_label = /*show_label*/
      s[8]), a[0] & /*show_download_button*/
      65536 && (c.show_download_button = /*show_download_button*/
      s[16]), a[0] & /*sources*/
      64 && (c.sources = /*sources*/
      s[6]), a[0] & /*active_source*/
      2097152 && (c.active_source = /*active_source*/
      s[21]), a[0] & /*mirror_webcam*/
      524288 && (c.mirror_webcam = /*mirror_webcam*/
      s[19]), a[0] & /*include_audio*/
      1048576 && (c.include_audio = /*include_audio*/
      s[20]), a[0] & /*autoplay*/
      16384 && (c.autoplay = /*autoplay*/
      s[14]), a[0] & /*root*/
      128 && (c.root = /*root*/
      s[7]), a[0] & /*gradio*/
      131072 && (c.i18n = /*gradio*/
      s[17].i18n), a[0] & /*gradio*/
      131072 | a[1] & /*$$scope*/
      16384 && (c.$$scope = { dirty: a, ctx: s }), i.$set(c);
    },
    i(s) {
      l || (At(e.$$.fragment, s), At(i.$$.fragment, s), l = !0);
    },
    o(s) {
      Bt(e.$$.fragment, s), Bt(i.$$.fragment, s), l = !1;
    },
    d(s) {
      s && kr(n), an(e, s), an(i, s);
    }
  };
}
function B2(t) {
  let e, n, i, l;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        t[17].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      t[17].i18n
    ) },
    /*loading_status*/
    t[1]
  ];
  let r = {};
  for (let s = 0; s < o.length; s += 1)
    r = oc(r, o[s]);
  return e = new Wu({ props: r }), i = new Kb({
    props: {
      value: (
        /*_video*/
        t[22]
      ),
      subtitle: (
        /*_subtitle*/
        t[23]
      ),
      label: (
        /*label*/
        t[5]
      ),
      show_label: (
        /*show_label*/
        t[8]
      ),
      autoplay: (
        /*autoplay*/
        t[14]
      ),
      show_share_button: (
        /*show_share_button*/
        t[15]
      ),
      show_download_button: (
        /*show_download_button*/
        t[16]
      ),
      i18n: (
        /*gradio*/
        t[17].i18n
      )
    }
  }), i.$on(
    "play",
    /*play_handler*/
    t[30]
  ), i.$on(
    "pause",
    /*pause_handler*/
    t[31]
  ), i.$on(
    "stop",
    /*stop_handler*/
    t[32]
  ), i.$on(
    "end",
    /*end_handler*/
    t[33]
  ), i.$on(
    "share",
    /*share_handler*/
    t[34]
  ), i.$on(
    "error",
    /*error_handler*/
    t[35]
  ), {
    c() {
      rn(e.$$.fragment), n = sc(), rn(i.$$.fragment);
    },
    m(s, a) {
      sn(e, s, a), Er(s, n, a), sn(i, s, a), l = !0;
    },
    p(s, a) {
      const u = a[0] & /*gradio, loading_status*/
      131074 ? ac(o, [
        a[0] & /*gradio*/
        131072 && {
          autoscroll: (
            /*gradio*/
            s[17].autoscroll
          )
        },
        a[0] & /*gradio*/
        131072 && { i18n: (
          /*gradio*/
          s[17].i18n
        ) },
        a[0] & /*loading_status*/
        2 && rc(
          /*loading_status*/
          s[1]
        )
      ]) : {};
      e.$set(u);
      const c = {};
      a[0] & /*_video*/
      4194304 && (c.value = /*_video*/
      s[22]), a[0] & /*_subtitle*/
      8388608 && (c.subtitle = /*_subtitle*/
      s[23]), a[0] & /*label*/
      32 && (c.label = /*label*/
      s[5]), a[0] & /*show_label*/
      256 && (c.show_label = /*show_label*/
      s[8]), a[0] & /*autoplay*/
      16384 && (c.autoplay = /*autoplay*/
      s[14]), a[0] & /*show_share_button*/
      32768 && (c.show_share_button = /*show_share_button*/
      s[15]), a[0] & /*show_download_button*/
      65536 && (c.show_download_button = /*show_download_button*/
      s[16]), a[0] & /*gradio*/
      131072 && (c.i18n = /*gradio*/
      s[17].i18n), i.$set(c);
    },
    i(s) {
      l || (At(e.$$.fragment, s), At(i.$$.fragment, s), l = !0);
    },
    o(s) {
      Bt(e.$$.fragment, s), Bt(i.$$.fragment, s), l = !1;
    },
    d(s) {
      s && kr(n), an(e, s), an(i, s);
    }
  };
}
function L2(t) {
  let e, n, i, l;
  const o = [T2, S2], r = [];
  function s(a, u) {
    return (
      /*interactive*/
      a[18] ? 1 : 0
    );
  }
  return e = s(t), n = r[e] = o[e](t), {
    c() {
      n.c(), i = w2();
    },
    m(a, u) {
      r[e].m(a, u), Er(a, i, u), l = !0;
    },
    p(a, u) {
      let c = e;
      e = s(a), e === c ? r[e].p(a, u) : (y2(), Bt(r[c], 1, 1, () => {
        r[c] = null;
      }), v2(), n = r[e], n ? n.p(a, u) : (n = r[e] = o[e](a), n.c()), At(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (At(n), l = !0);
    },
    o(a) {
      Bt(n), l = !1;
    },
    d(a) {
      a && kr(i), r[e].d(a);
    }
  };
}
function N2(t, e, n) {
  let { elem_id: i = "" } = e, { elem_classes: l = [] } = e, { visible: o = !0 } = e, { value: r = null } = e, s = null, { label: a } = e, { sources: u } = e, { root: c } = e, { show_label: f } = e, { loading_status: d } = e, { height: _ } = e, { width: m } = e, { container: h = !1 } = e, { scale: p = null } = e, { min_width: v = void 0 } = e, { autoplay: y = !1 } = e, { show_share_button: w = !0 } = e, { show_download_button: B } = e, { gradio: k } = e, { interactive: b } = e, { mirror_webcam: C } = e, { include_audio: H } = e, R = null, x = null, z, q = r;
  const F = () => {
    q === null || r === q || n(0, r = q);
  };
  let re = !1;
  function A({ detail: L }) {
    L != null ? n(0, r = { video: L, subtitles: null }) : n(0, r = null);
  }
  function ae({ detail: L }) {
    const [Ut, st] = L.includes("Invalid file type") ? ["warning", "complete"] : ["error", "error"];
    n(1, d = d || {}), n(1, d.status = st, d), n(1, d.message = L, d), k.dispatch(Ut, L);
  }
  const N = () => k.dispatch("play"), S = () => k.dispatch("pause"), pe = () => k.dispatch("stop"), P = () => k.dispatch("end"), J = ({ detail: L }) => k.dispatch("share", L), Z = ({ detail: L }) => k.dispatch("error", L), g = ({ detail: L }) => n(24, re = L), E = () => k.dispatch("clear"), T = () => k.dispatch("play"), I = () => k.dispatch("pause"), K = () => k.dispatch("upload"), ue = () => k.dispatch("stop"), j = () => k.dispatch("end"), He = () => k.dispatch("start_recording"), ke = () => k.dispatch("stop_recording");
  return t.$$set = (L) => {
    "elem_id" in L && n(2, i = L.elem_id), "elem_classes" in L && n(3, l = L.elem_classes), "visible" in L && n(4, o = L.visible), "value" in L && n(0, r = L.value), "label" in L && n(5, a = L.label), "sources" in L && n(6, u = L.sources), "root" in L && n(7, c = L.root), "show_label" in L && n(8, f = L.show_label), "loading_status" in L && n(1, d = L.loading_status), "height" in L && n(9, _ = L.height), "width" in L && n(10, m = L.width), "container" in L && n(11, h = L.container), "scale" in L && n(12, p = L.scale), "min_width" in L && n(13, v = L.min_width), "autoplay" in L && n(14, y = L.autoplay), "show_share_button" in L && n(15, w = L.show_share_button), "show_download_button" in L && n(16, B = L.show_download_button), "gradio" in L && n(17, k = L.gradio), "interactive" in L && n(18, b = L.interactive), "mirror_webcam" in L && n(19, C = L.mirror_webcam), "include_audio" in L && n(20, H = L.include_audio);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*value, initial_value*/
    536870913 && r && q === null && n(29, q = r), t.$$.dirty[0] & /*sources, active_source*/
    2097216 && u && !z && n(21, z = u[0]), t.$$.dirty[0] & /*value*/
    1 && (r != null ? (n(22, R = r.video), n(23, x = r.subtitles)) : (n(22, R = null), n(23, x = null))), t.$$.dirty[0] & /*value, old_value, gradio*/
    268566529 && JSON.stringify(r) !== JSON.stringify(s) && (n(28, s = r), k.dispatch("change"));
  }, [
    r,
    d,
    i,
    l,
    o,
    a,
    u,
    c,
    f,
    _,
    m,
    h,
    p,
    v,
    y,
    w,
    B,
    k,
    b,
    C,
    H,
    z,
    R,
    x,
    re,
    F,
    A,
    ae,
    s,
    q,
    N,
    S,
    pe,
    P,
    J,
    Z,
    g,
    E,
    T,
    I,
    K,
    ue,
    j,
    He,
    ke
  ];
}
class U2 extends b2 {
  constructor(e) {
    super(), k2(
      this,
      e,
      N2,
      L2,
      E2,
      {
        elem_id: 2,
        elem_classes: 3,
        visible: 4,
        value: 0,
        label: 5,
        sources: 6,
        root: 7,
        show_label: 8,
        loading_status: 1,
        height: 9,
        width: 10,
        container: 11,
        scale: 12,
        min_width: 13,
        autoplay: 14,
        show_share_button: 15,
        show_download_button: 16,
        gradio: 17,
        interactive: 18,
        mirror_webcam: 19,
        include_audio: 20
      },
      null,
      [-1, -1]
    );
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), se();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), se();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), se();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), se();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(e) {
    this.$$set({ label: e }), se();
  }
  get sources() {
    return this.$$.ctx[6];
  }
  set sources(e) {
    this.$$set({ sources: e }), se();
  }
  get root() {
    return this.$$.ctx[7];
  }
  set root(e) {
    this.$$set({ root: e }), se();
  }
  get show_label() {
    return this.$$.ctx[8];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), se();
  }
  get loading_status() {
    return this.$$.ctx[1];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), se();
  }
  get height() {
    return this.$$.ctx[9];
  }
  set height(e) {
    this.$$set({ height: e }), se();
  }
  get width() {
    return this.$$.ctx[10];
  }
  set width(e) {
    this.$$set({ width: e }), se();
  }
  get container() {
    return this.$$.ctx[11];
  }
  set container(e) {
    this.$$set({ container: e }), se();
  }
  get scale() {
    return this.$$.ctx[12];
  }
  set scale(e) {
    this.$$set({ scale: e }), se();
  }
  get min_width() {
    return this.$$.ctx[13];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), se();
  }
  get autoplay() {
    return this.$$.ctx[14];
  }
  set autoplay(e) {
    this.$$set({ autoplay: e }), se();
  }
  get show_share_button() {
    return this.$$.ctx[15];
  }
  set show_share_button(e) {
    this.$$set({ show_share_button: e }), se();
  }
  get show_download_button() {
    return this.$$.ctx[16];
  }
  set show_download_button(e) {
    this.$$set({ show_download_button: e }), se();
  }
  get gradio() {
    return this.$$.ctx[17];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), se();
  }
  get interactive() {
    return this.$$.ctx[18];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), se();
  }
  get mirror_webcam() {
    return this.$$.ctx[19];
  }
  set mirror_webcam(e) {
    this.$$set({ mirror_webcam: e }), se();
  }
  get include_audio() {
    return this.$$.ctx[20];
  }
  set include_audio(e) {
    this.$$set({ include_audio: e }), se();
  }
}
export {
  x2 as BaseExample,
  jb as BaseInteractiveVideo,
  Ju as BasePlayer,
  Kb as BaseStaticVideo,
  U2 as default,
  f1 as loaded,
  c1 as playable,
  es as prettyBytes
};
