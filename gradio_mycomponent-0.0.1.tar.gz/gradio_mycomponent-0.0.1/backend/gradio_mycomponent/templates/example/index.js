var C;
(function(e) {
  e.LOAD = "LOAD", e.EXEC = "EXEC", e.WRITE_FILE = "WRITE_FILE", e.READ_FILE = "READ_FILE", e.DELETE_FILE = "DELETE_FILE", e.RENAME = "RENAME", e.CREATE_DIR = "CREATE_DIR", e.LIST_DIR = "LIST_DIR", e.DELETE_DIR = "DELETE_DIR", e.ERROR = "ERROR", e.DOWNLOAD = "DOWNLOAD", e.PROGRESS = "PROGRESS", e.LOG = "LOG", e.MOUNT = "MOUNT", e.UNMOUNT = "UNMOUNT";
})(C || (C = {}));
function H(e, { autoplay: t }) {
  async function l() {
    t && await e.play();
  }
  return e.addEventListener("loadeddata", l), {
    destroy() {
      e.removeEventListener("loadeddata", l);
    }
  };
}
const { setContext: Pe, getContext: B } = window.__gradio__svelte__internal, J = "WORKER_PROXY_CONTEXT_KEY";
function Q() {
  return B(J);
}
function Z(e) {
  return e.host === window.location.host || e.host === "localhost:7860" || e.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  e.host === "lite.local";
}
function M(e, t) {
  const l = t.toLowerCase();
  for (const [n, i] of Object.entries(e))
    if (n.toLowerCase() === l)
      return i;
}
function F(e) {
  if (e == null)
    return !1;
  const t = new URL(e, window.location.href);
  return !(!Z(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
async function x(e) {
  if (e == null || !F(e))
    return e;
  const t = Q();
  if (t == null)
    return e;
  const n = new URL(e, window.location.href).pathname;
  return t.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((i) => {
    if (i.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const d = new Blob([i.body], {
      type: M(i.headers, "content-type")
    });
    return URL.createObjectURL(d);
  });
}
const {
  SvelteComponent: $,
  action_destroyer: ee,
  add_render_callback: ne,
  assign: N,
  attr: v,
  binding_callbacks: te,
  create_slot: le,
  detach: I,
  element: T,
  exclude_internal_props: A,
  get_all_dirty_from_scope: ie,
  get_slot_changes: oe,
  init: ue,
  insert: D,
  is_function: ae,
  listen: m,
  raf: re,
  run_all: se,
  safe_not_equal: de,
  space: fe,
  src_url_equal: U,
  toggle_class: S,
  transition_in: _e,
  transition_out: ce,
  update_slot_base: me
} = window.__gradio__svelte__internal, { createEventDispatcher: be } = window.__gradio__svelte__internal;
function Ee(e) {
  let t, l, n, i, d, s = !1, b, o = !0, r, f, E, R;
  const h = (
    /*#slots*/
    e[16].default
  ), c = le(
    h,
    e,
    /*$$scope*/
    e[15],
    null
  );
  function g() {
    cancelAnimationFrame(b), n.paused || (b = re(g), s = !0), e[17].call(n);
  }
  return {
    c() {
      t = T("div"), t.innerHTML = '<span class="load-wrap svelte-1pwzuub"><span class="loader svelte-1pwzuub"></span></span>', l = fe(), n = T("video"), c && c.c(), v(t, "class", "overlay svelte-1pwzuub"), S(t, "hidden", !/*processingVideo*/
      e[9]), U(n.src, i = /*resolved_src*/
      e[10]) || v(n, "src", i), n.muted = /*muted*/
      e[4], n.playsInline = /*playsinline*/
      e[5], v(
        n,
        "preload",
        /*preload*/
        e[6]
      ), n.autoplay = /*autoplay*/
      e[7], n.loop = !0, n.controls = /*controls*/
      e[8], v(n, "data-testid", d = /*$$props*/
      e[12]["data-testid"]), v(n, "crossorigin", "anonymous"), /*duration*/
      e[1] === void 0 && ne(() => (
        /*video_durationchange_handler*/
        e[18].call(n)
      ));
    },
    m(u, _) {
      D(u, t, _), D(u, l, _), D(u, n, _), c && c.m(n, null), e[20](n), f = !0, E || (R = [
        m(
          n,
          "loadeddata",
          /*dispatch*/
          e[11].bind(null, "loadeddata")
        ),
        m(
          n,
          "click",
          /*dispatch*/
          e[11].bind(null, "click")
        ),
        m(
          n,
          "play",
          /*dispatch*/
          e[11].bind(null, "play")
        ),
        m(
          n,
          "pause",
          /*dispatch*/
          e[11].bind(null, "pause")
        ),
        m(
          n,
          "ended",
          /*dispatch*/
          e[11].bind(null, "ended")
        ),
        m(
          n,
          "mouseover",
          /*dispatch*/
          e[11].bind(null, "mouseover")
        ),
        m(
          n,
          "mouseout",
          /*dispatch*/
          e[11].bind(null, "mouseout")
        ),
        m(
          n,
          "focus",
          /*dispatch*/
          e[11].bind(null, "focus")
        ),
        m(
          n,
          "blur",
          /*dispatch*/
          e[11].bind(null, "blur")
        ),
        m(n, "timeupdate", g),
        m(
          n,
          "durationchange",
          /*video_durationchange_handler*/
          e[18]
        ),
        m(
          n,
          "play",
          /*video_play_pause_handler*/
          e[19]
        ),
        m(
          n,
          "pause",
          /*video_play_pause_handler*/
          e[19]
        ),
        ee(r = H.call(null, n, { autoplay: (
          /*autoplay*/
          e[7] ?? !1
        ) }))
      ], E = !0);
    },
    p(u, [_]) {
      (!f || _ & /*processingVideo*/
      512) && S(t, "hidden", !/*processingVideo*/
      u[9]), c && c.p && (!f || _ & /*$$scope*/
      32768) && me(
        c,
        h,
        u,
        /*$$scope*/
        u[15],
        f ? oe(
          h,
          /*$$scope*/
          u[15],
          _,
          null
        ) : ie(
          /*$$scope*/
          u[15]
        ),
        null
      ), (!f || _ & /*resolved_src*/
      1024 && !U(n.src, i = /*resolved_src*/
      u[10])) && v(n, "src", i), (!f || _ & /*muted*/
      16) && (n.muted = /*muted*/
      u[4]), (!f || _ & /*playsinline*/
      32) && (n.playsInline = /*playsinline*/
      u[5]), (!f || _ & /*preload*/
      64) && v(
        n,
        "preload",
        /*preload*/
        u[6]
      ), (!f || _ & /*autoplay*/
      128) && (n.autoplay = /*autoplay*/
      u[7]), (!f || _ & /*controls*/
      256) && (n.controls = /*controls*/
      u[8]), (!f || _ & /*$$props*/
      4096 && d !== (d = /*$$props*/
      u[12]["data-testid"])) && v(n, "data-testid", d), !s && _ & /*currentTime*/
      1 && !isNaN(
        /*currentTime*/
        u[0]
      ) && (n.currentTime = /*currentTime*/
      u[0]), s = !1, _ & /*paused*/
      4 && o !== (o = /*paused*/
      u[2]) && n[o ? "pause" : "play"](), r && ae(r.update) && _ & /*autoplay*/
      128 && r.update.call(null, { autoplay: (
        /*autoplay*/
        u[7] ?? !1
      ) });
    },
    i(u) {
      f || (_e(c, u), f = !0);
    },
    o(u) {
      ce(c, u), f = !1;
    },
    d(u) {
      u && (I(t), I(l), I(n)), c && c.d(u), e[20](null), E = !1, se(R);
    }
  };
}
function he(e, t, l) {
  let { $$slots: n = {}, $$scope: i } = t, { src: d = void 0 } = t, { muted: s = void 0 } = t, { playsinline: b = void 0 } = t, { preload: o = void 0 } = t, { autoplay: r = !0 } = t, { controls: f = void 0 } = t, { currentTime: E = void 0 } = t, { duration: R = void 0 } = t, { paused: h = void 0 } = t, { node: c = void 0 } = t, { processingVideo: g = !1 } = t, u, _;
  const X = be();
  function G() {
    E = this.currentTime, l(0, E);
  }
  function K() {
    R = this.duration, l(1, R);
  }
  function Y() {
    h = this.paused, l(2, h);
  }
  function z(a) {
    te[a ? "unshift" : "push"](() => {
      c = a, l(3, c);
    });
  }
  return e.$$set = (a) => {
    l(12, t = N(N({}, t), A(a))), "src" in a && l(13, d = a.src), "muted" in a && l(4, s = a.muted), "playsinline" in a && l(5, b = a.playsinline), "preload" in a && l(6, o = a.preload), "autoplay" in a && l(7, r = a.autoplay), "controls" in a && l(8, f = a.controls), "currentTime" in a && l(0, E = a.currentTime), "duration" in a && l(1, R = a.duration), "paused" in a && l(2, h = a.paused), "node" in a && l(3, c = a.node), "processingVideo" in a && l(9, g = a.processingVideo), "$$scope" in a && l(15, i = a.$$scope);
  }, e.$$.update = () => {
    if (e.$$.dirty & /*src, latest_src*/
    24576) {
      l(10, u = d), l(14, _ = d);
      const a = d;
      x(a).then((j) => {
        _ === a && l(10, u = j);
      });
    }
  }, t = A(t), [
    E,
    R,
    h,
    c,
    s,
    b,
    o,
    r,
    f,
    g,
    u,
    X,
    t,
    d,
    _,
    i,
    n,
    G,
    K,
    Y,
    z
  ];
}
class ve extends $ {
  constructor(t) {
    super(), ue(this, t, he, Ee, de, {
      src: 13,
      muted: 4,
      playsinline: 5,
      preload: 6,
      autoplay: 7,
      controls: 8,
      currentTime: 0,
      duration: 1,
      paused: 2,
      node: 3,
      processingVideo: 9
    });
  }
}
new Intl.Collator(0, { numeric: 1 }).compare;
const {
  SvelteComponent: Re,
  add_flush_callback: ye,
  append: ge,
  attr: Le,
  bind: pe,
  binding_callbacks: ke,
  check_outros: Oe,
  create_component: Ie,
  destroy_component: De,
  detach: k,
  element: q,
  empty: P,
  group_outros: Ce,
  init: Ne,
  insert: O,
  is_function: W,
  mount_component: Te,
  noop: w,
  safe_not_equal: Ae,
  set_data: Ue,
  text: Se,
  toggle_class: y,
  transition_in: L,
  transition_out: p
} = window.__gradio__svelte__internal;
function V(e) {
  let t, l, n, i;
  const d = [we, We], s = [];
  function b(o, r) {
    return 0;
  }
  return t = b(), l = s[t] = d[t](e), {
    c() {
      l.c(), n = P();
    },
    m(o, r) {
      s[t].m(o, r), O(o, n, r), i = !0;
    },
    p(o, r) {
      l.p(o, r);
    },
    i(o) {
      i || (L(l), i = !0);
    },
    o(o) {
      p(l), i = !1;
    },
    d(o) {
      o && k(n), s[t].d(o);
    }
  };
}
function We(e) {
  let t, l;
  return {
    c() {
      t = q("div"), l = Se(
        /*value*/
        e[2]
      );
    },
    m(n, i) {
      O(n, t, i), ge(t, l);
    },
    p(n, i) {
      i & /*value*/
      4 && Ue(
        l,
        /*value*/
        n[2]
      );
    },
    i: w,
    o: w,
    d(n) {
      n && k(t);
    }
  };
}
function we(e) {
  var b;
  let t, l, n, i;
  function d(o) {
    e[5](o);
  }
  let s = {
    muted: !0,
    playsinline: !0,
    src: (
      /*value*/
      (b = e[2]) == null ? void 0 : b.video.url
    )
  };
  return (
    /*video*/
    e[3] !== void 0 && (s.node = /*video*/
    e[3]), l = new ve({ props: s }), ke.push(() => pe(l, "node", d)), l.$on(
      "loadeddata",
      /*init*/
      e[4]
    ), l.$on("mouseover", function() {
      W(
        /*video*/
        e[3].play.bind(
          /*video*/
          e[3]
        )
      ) && e[3].play.bind(
        /*video*/
        e[3]
      ).apply(this, arguments);
    }), l.$on("mouseout", function() {
      W(
        /*video*/
        e[3].pause.bind(
          /*video*/
          e[3]
        )
      ) && e[3].pause.bind(
        /*video*/
        e[3]
      ).apply(this, arguments);
    }), {
      c() {
        t = q("div"), Ie(l.$$.fragment), Le(t, "class", "container svelte-13u05e4"), y(
          t,
          "table",
          /*type*/
          e[0] === "table"
        ), y(
          t,
          "gallery",
          /*type*/
          e[0] === "gallery"
        ), y(
          t,
          "selected",
          /*selected*/
          e[1]
        );
      },
      m(o, r) {
        O(o, t, r), Te(l, t, null), i = !0;
      },
      p(o, r) {
        var E;
        e = o;
        const f = {};
        r & /*value*/
        4 && (f.src = /*value*/
        (E = e[2]) == null ? void 0 : E.video.url), !n && r & /*video*/
        8 && (n = !0, f.node = /*video*/
        e[3], ye(() => n = !1)), l.$set(f), (!i || r & /*type*/
        1) && y(
          t,
          "table",
          /*type*/
          e[0] === "table"
        ), (!i || r & /*type*/
        1) && y(
          t,
          "gallery",
          /*type*/
          e[0] === "gallery"
        ), (!i || r & /*selected*/
        2) && y(
          t,
          "selected",
          /*selected*/
          e[1]
        );
      },
      i(o) {
        i || (L(l.$$.fragment, o), i = !0);
      },
      o(o) {
        p(l.$$.fragment, o), i = !1;
      },
      d(o) {
        o && k(t), De(l);
      }
    }
  );
}
function Ve(e) {
  let t, l, n = (
    /*value*/
    e[2] && V(e)
  );
  return {
    c() {
      n && n.c(), t = P();
    },
    m(i, d) {
      n && n.m(i, d), O(i, t, d), l = !0;
    },
    p(i, [d]) {
      /*value*/
      i[2] ? n ? (n.p(i, d), d & /*value*/
      4 && L(n, 1)) : (n = V(i), n.c(), L(n, 1), n.m(t.parentNode, t)) : n && (Ce(), p(n, 1, 1, () => {
        n = null;
      }), Oe());
    },
    i(i) {
      l || (L(n), l = !0);
    },
    o(i) {
      p(n), l = !1;
    },
    d(i) {
      i && k(t), n && n.d(i);
    }
  };
}
function qe(e, t, l) {
  let { type: n } = t, { selected: i = !1 } = t, { value: d } = t, s;
  async function b() {
    l(3, s.muted = !0, s), l(3, s.playsInline = !0, s), l(3, s.controls = !1, s), s.setAttribute("muted", ""), await s.play(), s.pause();
  }
  function o(r) {
    s = r, l(3, s);
  }
  return e.$$set = (r) => {
    "type" in r && l(0, n = r.type), "selected" in r && l(1, i = r.selected), "value" in r && l(2, d = r.value);
  }, [n, i, d, s, b, o];
}
class Xe extends Re {
  constructor(t) {
    super(), Ne(this, t, qe, Ve, Ae, { type: 0, selected: 1, value: 2 });
  }
}
export {
  Xe as default
};
